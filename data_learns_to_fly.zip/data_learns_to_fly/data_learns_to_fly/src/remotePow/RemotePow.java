package remotePow;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import org.iota.jota.pow.IotaLocalPoW;
import org.json.JSONObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Class handles the remote PoW that is done on the FPGA hardware accelerator

public class RemotePow implements IotaLocalPoW {

	private int mmw, security, index;
	private String ipAddress, seed, signature;

	public RemotePow(String inIP) {
		this.ipAddress = inIP;
	}

	// Method delivers the PoW request to the server that runs on the FPGA
	// Method returns the FPGA's answer (nonce) of the PoW request
	
	public String performPoW(String inSignature, int inMmw) {
		
		// inSignature are the transaction trytes, where the nonce should be found for.
		
		DataInputStream inputStream;
		DataOutputStream outputStream;
		String nonce = "";
		double time0 = System.currentTimeMillis();
		try {
			@SuppressWarnings("resource")
			Socket socket = new Socket(InetAddress.getByName(this.ipAddress), 5000); 	// Server on FPGA listens on port 5000.
			this.mmw = inMmw;
			this.signature = inSignature;

			// JSON Repr. for PoW request.
			String stringPoW = "{\"method\":\"doPoW\",\"params\":[\"" + this.signature + "\", \"" + this.mmw + "\"]}";
			inputStream = new DataInputStream(socket.getInputStream());
			outputStream = new DataOutputStream(socket.getOutputStream());
			PrintWriter outputWriter = new PrintWriter(outputStream);
			outputWriter.println(stringPoW);
			outputWriter.flush();

			BufferedReader inputReader = new BufferedReader(new InputStreamReader(inputStream));
			@SuppressWarnings("unused")
			String line = "";
			boolean run = true;

			// Wait for answer an return none.
			while ((line = inputReader.readLine()) != null && run == true) {
				JSONObject json = new JSONObject(inputReader.readLine());
				if (json.get("method").equals("doPoW")) {
					String returnNonce = json.get("answer").toString();
					returnNonce = returnNonce.replace("\"", "");
					returnNonce = returnNonce.replace("[", "");
					returnNonce = returnNonce.replace("]", "");
					inputStream.close();
					outputStream.close();
					nonce = returnNonce;
				}
			}
		} catch (Exception e) {
		}
		double time1 = System.currentTimeMillis();
		
		// Print time it took to perform PoW.
		System.out.println("Performing accelerated PoW, took: " + (time1 - time0) + " ms.");
		this.signature = this.signature.substring(0, (this.signature.length() - 27));
		String convertedTrits = this.signature + nonce;
		return convertedTrits;
	}

	// Method delivers getNextAddress request to the server that runs on the FPGA
	// Method returns the FPGA's answer of the getNextAddress request
	public String performGnA(String inSeed, int inIndex, int inSecurity) {
		DataInputStream inputStream;
		DataOutputStream outputStream;

		try {
			@SuppressWarnings("resource")
			Socket socket = new Socket(InetAddress.getByName(this.ipAddress), 5000);
			this.security = inSecurity;
			this.index = inIndex;
			this.seed = inSeed;

			// JSON description of the GetNextAddress request.
			String stringGnA = "{\"method\":\"doGnA\",\"params\":[\"" + this.seed + "\", \"" + this.index + "\", \""
					+ this.security + "\"]}";

			inputStream = new DataInputStream(socket.getInputStream());
			outputStream = new DataOutputStream(socket.getOutputStream());
			PrintWriter outputWriter = new PrintWriter(outputStream);
			outputWriter.println(stringGnA);
			outputWriter.flush();

			BufferedReader inputReader = new BufferedReader(new InputStreamReader(inputStream));
			String line = "";
			boolean run = true;

			// Wait for answer of GetNextAddress request and return answer.
			while ((line = inputReader.readLine()) != null && run == true) {
				if (line.contains("doGnA")) {
					String temp = line;
					String returnAddress = temp.substring(temp.indexOf("[") + 2, temp.indexOf("]") - 1);
					inputStream.close();
					outputStream.close();
					return returnAddress;

				}
			}

		} catch (Exception e) {
		}
		return "NA";
	}
}
