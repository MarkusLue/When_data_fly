package multiTransaction;

import java.util.LinkedList;
import java.util.List;

import org.iota.jota.IotaAPI;
import org.iota.jota.dto.response.GetInclusionStateResponse;
import org.iota.jota.error.ArgumentException;
import org.iota.jota.model.Bundle;
import org.iota.jota.model.Transaction;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.Converter;
import org.iota.jota.utils.Multisig;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

public class MultiSignAddressStatus {

	// This class handles features around the multi-signature address (create
	// address by digest,
	// check if inputs were sent to the address, check if inputs were confirmed)

	// This object will provide information on the incoming transactions of the
	// multi-sign address
	// State 1: no or only one of the needed inputs were broadcasted, but are not
	// confirmed
	// State 2: both inputs were broadcasted, but are both not confirmed
	// State 3: both inputs were confirmed

	// set via constructor
	private boolean isBuyer;
	private String ownDigest;
	private IotaAPI api;

	// used and set in methods
	private String partnerDigest;
	private Multisig multiSign;
	private boolean inputsAreThere;

	@SuppressWarnings("unused")
	private boolean inputsAreConfirmed;
	List<String> txHashStorgae;
	List<String> originatingValueAddress;
	List<Integer> bundleNumberStorage;

	public MultiSignAddressStatus(IotaAPI inApi, boolean inIsBuyer, String inOwnDigest) {
		this.inputsAreThere = false;
		this.api = inApi;
		this.inputsAreConfirmed = false;
		this.inputsAreThere = false;
		this.txHashStorgae = new LinkedList<String>();
		this.originatingValueAddress = new LinkedList<String>();
		this.bundleNumberStorage = new LinkedList<Integer>();
		this.isBuyer = inIsBuyer;
		this.ownDigest = inOwnDigest;
	}

	public String[] generateMultiSignAddress(String inPartnerDigests) {

		// This method generates the multi-signature address,
		// calculated with the received and own digests

		this.partnerDigest = inPartnerDigests;

		// The signature order is crucial, and described by the protocol, BUYER signs
		// first.
		String digestStringOwn = this.ownDigest;
		String digestStringPartner = this.partnerDigest;

		// SELLER signs secondly
		if (!this.isBuyer) {
			digestStringPartner = this.ownDigest;
			digestStringOwn = this.partnerDigest;
		}
		int tritsOwn[] = Converter.trits(digestStringOwn);
		int tritsPartner[] = Converter.trits(digestStringPartner);

		// Get inital Multisign Address-Part
		this.multiSign = new Multisig();
		String initiatedMultisigAddress = this.multiSign.addAddressDigest(digestStringOwn, "");
		String addressTemp1 = initiatedMultisigAddress;

		// add further Multisign Address-Part
		String addressTemp2 = multiSign.addAddressDigest(digestStringPartner, addressTemp1);

		String address = this.multiSign.finalizeAddress(addressTemp2);
		int[][] tritsArrayDigest = { tritsOwn, tritsPartner };

		String[] returner = { Checksum.addChecksum(address), "" + this.multiSign.validateAddress(address, tritsArrayDigest) };
		return returner;
	}

	@SuppressWarnings("static-access")
	public boolean checkIfInputsAreThere(String inMultiAddress, long inAmount1, long inAmount2) {

		// This method checks if enough inputs (based on incoming tokens)
		// were send to the multi-signature address (method input)

		Bundle[] bundleStorage = api.bundlesFromAddresses(false, inMultiAddress);

		// System.out.println("Got Bundles: " + bundleStorage.length);
		long combinedIncomingBalance = 0;


		// Get Hashes and Balances of all incoming TX on the MultiSignAddress
		for (int i = 0; i < bundleStorage.length; i++) {
			List<Transaction> txStorage = bundleStorage[i].getTransactions();

			for (int j = 0; j < txStorage.size(); j++) {
				if (new Checksum().addChecksum(txStorage.get(j).getAddress()).equals(inMultiAddress)) {
					combinedIncomingBalance = combinedIncomingBalance + txStorage.get(j).getValue();
					this.txHashStorgae.add(txStorage.get(j).getHash());
					this.bundleNumberStorage.add(i);
				}

			}
		}
		for (int k = 0; k < this.bundleNumberStorage.size(); k++) {
			List<Transaction> txStorageNegativeValue = bundleStorage[this.bundleNumberStorage.get(k)].getTransactions();
			for (int u = 0; u < txStorageNegativeValue.size(); u++) {
				if (txStorageNegativeValue.get(u).getValue() < 0) {
					this.originatingValueAddress.add(new Checksum().addChecksum(txStorageNegativeValue.get(u).getAddress()));
				}
			}

		}
		if ((inAmount1 + inAmount2) == combinedIncomingBalance) {
			this.inputsAreThere = true;
			return true;
		} else {
			this.inputsAreThere = false;
			return false;
		}

	}

	public boolean checkIfInputsAreConfirmed() {

		// Method checks if the inputs to the multi-signature address were confirmed by
		// the IOTA network/Coordinator.

		try {
			String[] addressToCheck = this.txHashStorgae.toArray(new String[0]);
			GetInclusionStateResponse gisr = this.api.getLatestInclusion((addressToCheck));
			boolean[] inclusionStates = gisr.getStates();

			for (int i = 0; i < inclusionStates.length; i++) {
				if (inclusionStates[i] == false) {
					this.inputsAreConfirmed = false;
					return false;
				}
			}
			this.inputsAreConfirmed = true;
			return true;
		} catch (ArgumentException e) {
			this.inputsAreConfirmed = false;
			return false;
		}
	}

	public boolean isInputsAreThere() {
		return this.inputsAreThere;
	}

	public boolean isInputsAreConfirmed() {
		return this.checkIfInputsAreConfirmed();
	}

}
