package multiTransaction.sign;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.iota.jota.IotaAPI;
import org.iota.jota.builder.AddressRequest;
import org.iota.jota.dto.response.GetBalancesResponse;
import org.iota.jota.dto.response.GetNewAddressResponse;
import org.iota.jota.model.Input;
import org.iota.jota.model.Transaction;
import org.iota.jota.model.Transfer;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.TrytesConverter;

import remotePow.RemotePow;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class is a wrapper to perform various tasks around a single-sign transfer. 
// build transfers, applied PoW, send and broadcast the single-sign transfers.
// instead of applieg PoW transfers can be converted to String Arrays, that can be 
// send to a partner that performs PoW and broadcasts them to the IOTA tangle.

public class SingleSign {

	// Set via constructor
	private IotaAPI api;
	private RemotePow rpc;
	private boolean outsourcedPow;

	// Set in methods
	private String seed,targetTO, remainderTO, tag, message, addressInput;
	private long value, balance;
	private int security, mwm, depth, keyIndex;
	private boolean accelerated;

	public SingleSign(IotaAPI inApi, RemotePow inRpc) {
		this.api = inApi;
		this.rpc = inRpc;
	}

	public String getNextUnspentAddress(String inSeed, int inSeedSec, int inSeedKey, boolean inAccelerated) {
		
		// This method is supposed to return the next address on the seed, 
		// that is not already spent from

		this.seed = inSeed;
		this.security = inSeedSec;
		this.keyIndex = inSeedKey;
		this.accelerated = inAccelerated;

		// if the PoW is not boosted, use the normal IOTA function to generate 
		// the next addresses
		
		if (!this.accelerated) {
			AddressRequest addressRequest = new AddressRequest.Builder(this.seed, this.security).index(this.keyIndex).checksum(true).amount(0).build();
			GetNewAddressResponse addressResp = this.api.generateNewAddresses(addressRequest);
			return addressResp.getAddresses().get(0);

		} else {
			
			// if PoW is boosted, performing the PoW on the hardware accelerator
			// Get the next 3 addresses from Pi Accelerator and put them into LinkedLists
			int intervall = 3;
			String[] addressFromPi = new String[intervall];
			boolean[] spentFrom = new boolean[intervall];

			LinkedList<String> adrList = new LinkedList<String>();
			int runIndex = this.keyIndex;
			boolean run = true;

			while (run) {
				for (int k = 0; k < intervall; k++) {
					addressFromPi[k] = Checksum.addChecksum(this.rpc.performGnA(this.seed, (k + runIndex), this.security));
					adrList.add(k, addressFromPi[k]);
				}
				spentFrom = api.checkWereAddressSpentFrom(addressFromPi);
				GetBalancesResponse gbr = api.getBalances(100, adrList);

				for (int h = 0; h < spentFrom.length; h++) {
					if (spentFrom[h] == false && run && Long.parseLong(gbr.getBalances()[h]) == 0) {
						run = false;
						return addressFromPi[h];
					}
				}
				if (run) {
					runIndex += intervall;
				}
			}
		}
		return null;
	}

	public HashMap<Integer, String[]> getInitialSetOfAddresses(String inSeed, int inSeedSec, boolean inAccelerated, int inKeyIndex, int inAmount) {

		// This method is supposed to return an initial set of addresses
		// -> check input and throw exception, if inAmount is to large
		
		if (inAmount > 50) {
			throw new ArrayIndexOutOfBoundsException();
		}

		this.seed = inSeed;
		this.security = inSeedSec;
		this.accelerated = inAccelerated;
		this.keyIndex = inKeyIndex;
		HashMap<Integer, String[]> returner = new HashMap<Integer, String[]>();
		long seenMax = 0;
		int positionMax = 0;

		// if the PoW is not boosted, use the normal IOTA function to generate the next
		// addresses
		if (!this.accelerated) {

			AddressRequest addressRequest = new AddressRequest.Builder(this.seed, this.security).index(this.keyIndex).checksum(true).amount(inAmount)
					.addSpendAddresses(true).build();

			GetNewAddressResponse addResp = this.api.generateNewAddresses(addressRequest);

			for (int i = 0; i < addResp.getAddresses().size(); i++) {
				long balance = this.api.getBalance(100, addResp.getAddresses().get(i));

				// Remeber the maximal balance
				if (balance > seenMax) {
					seenMax = balance;
					positionMax = i;
				}

				String[] tempArray = { addResp.getAddresses().get(i), "" + balance };
				returner.put(this.keyIndex + i, tempArray);
			}
			String[] saveMax = { "" + (positionMax + this.keyIndex), "" + seenMax };
			returner.put(9999, saveMax);
			return returner;

		} else {
			// if PoW is boosted, performing the PoW on the hardware accelerator
			for (int k = 0; k < inAmount; k++) {
				String addressGeneratedRemotely = Checksum.addChecksum(this.rpc.performGnA(this.seed, (this.keyIndex + k), this.security));
				long balanceOnAddress = this.api.getBalance(100, addressGeneratedRemotely);

				// Remember the maximal balance
				if (balanceOnAddress > seenMax) {
					seenMax = balanceOnAddress;
					positionMax = k;
				}

				String[] tempArray = { addressGeneratedRemotely, "" + balanceOnAddress };
				returner.put(this.keyIndex + k, tempArray);
			}
			String[] saveMax = { "" + (positionMax + this.keyIndex), "" + seenMax };
			returner.put(9999, saveMax);
			return returner;
		}
	}

	public String[] performSingleTransaction(String inSeed, String inTargetAddress, String inRemainderAddress, long inTxValue, String inTxMessage,
			String inTxTag, int inMWM, int inDepth, int inSecurity, long inAddressInputBalance, String inAddressInput, int inKeyAddressInput) {

		// This function performs the single-transfer transactions, that are prepared and broadcasted
		// at the beginning of a full ad-hoc data trade cycle.
		
		// Transfers are prepared and either sent and broadcasted to the IOTA node, or the - if
		// outsourced PoW is used - transfers are returned in the form of a String Array with trytes
		// where to PoW can be applied to
		
		this.seed = inSeed;
		this.targetTO = inTargetAddress;
		this.remainderTO = inRemainderAddress;
		this.value = inTxValue;
		this.message = inTxMessage;
		this.tag = inTxTag;
		this.mwm = inMWM;
		this.depth = inDepth;
		this.security = inSecurity;
		this.balance = inAddressInputBalance;
		this.addressInput = inAddressInput;
		this.keyIndex = inKeyAddressInput;

		// Build Transfer and Inputs
		List<Transfer> transfers = new LinkedList<Transfer>();
		transfers.add(new Transfer(this.targetTO, this.value, TrytesConverter.asciiToTrytes(this.message), this.tag));

		List<Input> inputs = new LinkedList<Input>();
		inputs.add(new Input(this.addressInput, this.balance, this.keyIndex, this.security));

		// Prepare Transfers
		List<String> trytes = new AIC().prepareTransfers(this.seed, this.security, transfers, this.remainderTO, inputs, null, this.addressInput, this.balance);
		String[] returner = new String[trytes.size()];

		// if one device is using the hardware accelerator of the other, the trytes are
		// returned
		if (this.outsourcedPow) {
			
			returner = trytes.toArray(new String[0]);
			return returner;
		} else {
			List<Transaction> bundle = api.sendTrytes(trytes.toArray(new String[0]), this.depth, this.mwm, null);
			returner[0] = "success";
	
			// Get the transaction hash that is associated with the multisignaddress
			returner[1] = this.getTxHashMultiAddress(bundle);
			return returner;
		}

	}
	
	public String[] processOutsourcesPoW(String[] inTrytes) {
		
		// This function applies the PoW to a received tryte String Array representation of an IOTA transfer bundle
		// After applying the PoW, the transfer is broafcasted to the IOTA node
		
		String[] returner = new String[inTrytes.length];
		List<Transaction> bundle = api.sendTrytes(inTrytes, this.depth, this.mwm, null);
		returner[0] = "success";

		// Get the transaction hash that is associated with the multisignaddress
		returner[1] = this.getTxHashMultiAddress(bundle);
		return returner;
	}

	
	// Setter and Getter
	
	public void setOutsourcedPow(boolean outsourcedPow) {
		this.outsourcedPow = outsourcedPow;
	}

	public String getTxHashMultiAddress(List<Transaction> inBundle) {

		// Methods returns the TX hash of the transaction moving value to the target address
		String currentAddress = null;
		for (int i = 0; i < inBundle.size(); i++) {
			currentAddress = inBundle.get(i).getAddress().toString();
			if (currentAddress.equals(this.targetTO)) {
				return inBundle.get(i).getHash();
			}
		}
		return addressInput;
	}

}
