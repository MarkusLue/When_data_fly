package multiTransaction;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.iota.jota.model.Bundle;
import org.iota.jota.model.Transaction;
import org.iota.jota.model.Transfer;
import org.iota.jota.pow.SpongeFactory;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.Signing;
import org.iota.jota.utils.TrytesConverter;

import errors.NotEnoughBalanceError;
import multiTransaction.sign.AIC;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class implements the state representation of the Bi-Directional Payment Channel
// State can be converted into List of Transactions and trytes-String-Array representation to send to a partner
// Received states (as List of transactions or trytes-String-Arra) can be check to match the own state,
// additionally the IOTA signature can be checked with this class.

public class MultiSignState {

	// initial variables that are set via constructor
	private boolean isBuyer;
	private String name, namePartner, multiSignAddress, ownMultiSignResolveAddress, partnerMultiSignResolveAddress, ownRandomSeed, txTag, txMsg;
	private long ownInitialBalance, partnerInitialBalance;
	private int seedSec;
	private AlteredIotaMultisig multiSign;

	// variables that keep track of the current state
	private long ownClearPayoutAmount, partnerClearPayoutAmount, ownAmountLockedinState, partnerAmountLockedinState;
	private boolean consenusWithPartnerOverState, validSignature;
	
	private String bundleHash;

	// Constructor
	public MultiSignState(boolean inIsBuyer, String inName, String inNamePartner, String inMuliSignAddress, long inOwnInitialBalance,
			long inPartnerInitialBalance, String inOwnMultiSignResolveAddress, String inPartnerMultiSignResolveAddress,
			String inOwnSeed, String inOwnRandomSeed, String inTxTag, int inSeedSec) {
		
		this.isBuyer = inIsBuyer;
		this.name = inName;
		this.namePartner = inNamePartner;
		this.multiSignAddress = inMuliSignAddress;
		this.ownInitialBalance = inOwnInitialBalance;
		this.partnerInitialBalance = inPartnerInitialBalance;
		this.ownMultiSignResolveAddress = inOwnMultiSignResolveAddress;
		this.partnerMultiSignResolveAddress = inPartnerMultiSignResolveAddress;
		
		this.ownRandomSeed = inOwnRandomSeed;
		this.txTag = inTxTag;
		this.multiSign = new AlteredIotaMultisig();
		this.seedSec = inSeedSec;

		this.ownClearPayoutAmount = 0;
		this.partnerClearPayoutAmount = 0;
		this.ownAmountLockedinState = this.ownInitialBalance;
		this.partnerAmountLockedinState = this.partnerInitialBalance;
		this.consenusWithPartnerOverState = false;
		this.validSignature = false;
		this.bundleHash = null;
	}
	
	public boolean getsPayed (long inAmount) throws NotEnoughBalanceError {
		
		// function alters the state if the user gets paid by another 
		// member of the bi-directional payment channel
		
		// check if partner has enough balance to pay me
		if (this.partnerAmountLockedinState > inAmount) {
			
			// recalculate states depending on payment
			this.partnerAmountLockedinState = this.partnerAmountLockedinState - inAmount;
			this.ownClearPayoutAmount = this.ownClearPayoutAmount + inAmount;
			
			// free up own collateral
			this.ownClearPayoutAmount = this.ownClearPayoutAmount + inAmount;
			this.ownAmountLockedinState = this.ownAmountLockedinState - inAmount; 
			
			return true;
		} else {
			throw new NotEnoughBalanceError("\n\n" + this.name + " can't get payed, because partner does not have enough balance." + "\n");
		}
	}
	
	public boolean paysPartner(long inAmount) throws NotEnoughBalanceError {
		
		// function alters the state if the user pays another 
		// member of the bi-directional payment channel
		
		// check if own has enough balance to pay partner
		if (this.ownAmountLockedinState > inAmount) {
			
			// recalculate states depending on payment
			this.ownAmountLockedinState = this.ownAmountLockedinState - inAmount;
			this.partnerClearPayoutAmount = this.partnerClearPayoutAmount + inAmount;
			
			// free up partner collateral
			this.partnerAmountLockedinState = this.partnerAmountLockedinState - inAmount;
			this.partnerClearPayoutAmount = this.partnerClearPayoutAmount + inAmount;
			
			return true;
		} else {
			throw new NotEnoughBalanceError("\n\n" + this.name + " can't pay partner, because I do not have enough balance." + "\n");
		}
	}
	
	public boolean reversePaysPartner(long inAmount) throws NotEnoughBalanceError {
		
		// function reverses the state if the user tried to pay another 
		// member of the bi-directional payment channel and has to reverse the payment
		// e.g., because the offer of payment was declined (when offner not high enough)
		
		// if partner rejects transaction, the state is reversed
		if (this.ownAmountLockedinState > inAmount) {
			
			// recalculate states depending on payment
			this.ownAmountLockedinState = this.ownAmountLockedinState + inAmount;
			this.partnerClearPayoutAmount = this.partnerClearPayoutAmount - inAmount;
			
			// free up partner collateral
			this.partnerAmountLockedinState = this.partnerAmountLockedinState + inAmount;
			this.partnerClearPayoutAmount = this.partnerClearPayoutAmount - inAmount;
			
			return true;
		} else {
			throw new NotEnoughBalanceError("\n\n" + this.name + " can't pay partner, because I do not have enough balance." + "\n");
		}
	}

	public void resolveLockedAmounts() {
		
		// This function resolves the locked tokens in the state by moving everyone's still untouched
		// collateral to the payout address of the respective user
		
		// clean own Payout and Locked State
		this.ownClearPayoutAmount = this.ownClearPayoutAmount + this.ownAmountLockedinState;
		this.ownAmountLockedinState = 0;
		
		this.partnerClearPayoutAmount = this.partnerClearPayoutAmount + this.partnerAmountLockedinState;		
		this.partnerAmountLockedinState = 0;
	}
	
	
	private List<Transaction> getTransactionsCurrentState(){
		
		// this function converts the state into a List of Transactions
		// Transfers are set so that the current state's representation of payouts is carried out
		
		// Set payout address and balances depending on Buyer/Seller Configuration
		String[] addressOutputs = { this.ownMultiSignResolveAddress, this.partnerMultiSignResolveAddress };
		long[] values = { this.ownClearPayoutAmount, this.partnerClearPayoutAmount };

		if (this.isBuyer) {
			addressOutputs[0] = this.partnerMultiSignResolveAddress;
			addressOutputs[1] = this.ownMultiSignResolveAddress;
			values[0] = this.partnerClearPayoutAmount;
			values[1] = this.ownClearPayoutAmount;
		}

		List<Transfer> transfers = new ArrayList<Transfer>();
		for (int i = 0; i < addressOutputs.length; i++) {
			
			//Customize Payout Message
			this.txMsg = "Payout for ";
			if (addressOutputs[i].equals(this.ownMultiSignResolveAddress)) {
				this.txMsg += this.name;
			} else {
				this.txMsg += this.namePartner;
			}
			
			Transfer t = new Transfer(addressOutputs[i], values[i], TrytesConverter.asciiToTrytes(this.txMsg), this.txTag);
			transfers.add(t);
		}

		int combinedSeedSec = 2 * this.seedSec;
		List<Transaction> transFinal = new ArrayList<Transaction>();
		transFinal = new AIC().initiateTransfer(combinedSeedSec, this.multiSignAddress, null, transfers, null, true, values[0] + values[1]);
		
		return transFinal;
	}
	
	public String[] getSignedCurrentState() {
		
		// this function converts the state into a List of Transactions, the transactions are signed and return in the 
		// trytes-String-Array representation. To convert into List of Transaction, function getTransactionsCurrentState() is called.
		// Transfers are set so that the current state's representation of payouts is carried out.
		
		List<Transaction> finalTransactions = this.getTransactionsCurrentState();
		String addressInputWithoutCheckSum = Checksum.removeChecksum(this.multiSignAddress);
		Bundle initialBundle = new Bundle(finalTransactions, finalTransactions.size());
		
		// Build Bundle
		initialBundle = this.multiSign.addSignature(initialBundle, addressInputWithoutCheckSum, this.multiSign.getKey(this.ownRandomSeed, 0, this.seedSec));	
		this.bundleHash = initialBundle.getBundleHash();
		
		// Reverse transactions, so that resulting trytes could be broadcasted.
		String[] trytesToBeSend = new String[initialBundle.getTransactions().size()];
		for (int t = 0; t < initialBundle.getLength(); t++) {
			trytesToBeSend[initialBundle.getLength() - t - 1] = initialBundle.getTransactions().get(t).toTrytes();
		}
		return trytesToBeSend;
	}
	
	
	public String[] checkAndCoSignReceivedState(String[] inTrytes) {
		
		// this function checks if a received String Array of Transactions match the user's state (expressed as Array of Transactions).
		// E.g. if a user receives a signed version of the state, the user must check, if both users are considering the same state.
		// To do so - the received trytes are turned into Transactions, which are then compared with the
		// own transaction representation of the own state.
		
		List<Transaction> transOwnCalculation = this.getTransactionsCurrentState();
		String addressInputWithoutCheckSum = Checksum.removeChecksum(this.multiSignAddress);
		Signing sign = new Signing(SpongeFactory.create(SpongeFactory.Mode.KERL));

		// Build List of Transactions based on incoming trytes
		List<Transaction> transPartnerCalculation = new LinkedList<Transaction>();
		for (int i = 0; i < inTrytes.length; i++) {
			Transaction tempTrans = new Transaction(inTrytes[inTrytes.length - i - 1]);
			transPartnerCalculation.add(tempTrans);
		}
		
		// compare transOwnCalculation and transPartnerCalculation
		this.consenusWithPartnerOverState = true;		
		for (int k = 0; k < transPartnerCalculation.size(); k++) {		
			boolean addressMatch = transOwnCalculation.get(k).getAddress().equals(transPartnerCalculation.get(k).getAddress());
			boolean valueMatch = (transOwnCalculation.get(k).getValue() == transPartnerCalculation.get(k).getValue());			
			if (!addressMatch || !valueMatch) {
				this.consenusWithPartnerOverState = false;
			}
		}

		// build bundle with list of incoming transaction trytes from partner and sign
		Bundle generateBundle = new Bundle(transPartnerCalculation, transPartnerCalculation.size());
		generateBundle = this.multiSign.addSignature(generateBundle, addressInputWithoutCheckSum, this.multiSign.getKey(this.ownRandomSeed, 0, this.seedSec));

		this.validSignature = sign.validateSignatures(generateBundle, addressInputWithoutCheckSum);
		
		// pack bundle as string[] of trytes and return them as an object that can be sent to the tangle
		String[] sendTrytes = new String[generateBundle.getTransactions().size()];
		for (int t = 0; t < generateBundle.getLength(); t++) {
			sendTrytes[generateBundle.getLength() - t - 1] = generateBundle.getTransactions().get(t).toTrytes();
		}
		
		return sendTrytes;
	}
	
	public boolean checkPartnerSignature(String[] inTrytes) {
		
		// this function checks if a received String Array of Transactions match the user's state (expressed as Array of Transactions).
		// AND if the IOTA signature that was applied to the transactions is valid.
		
		List<Transaction> transOwnCalculation = this.getTransactionsCurrentState();
		String addressInputWithoutCheckSum = Checksum.removeChecksum(this.multiSignAddress);
		Signing sign = new Signing(SpongeFactory.create(SpongeFactory.Mode.KERL));

		// Build List of Transactions based on incoming trytes
		List<Transaction> transPartnerCalculation = new LinkedList<Transaction>();
		for (int i = 0; i < inTrytes.length; i++) {
			Transaction tempTrans = new Transaction(inTrytes[inTrytes.length - i - 1]);
			transPartnerCalculation.add(tempTrans);
		}
		
		// compare transOwnCalculation and transPartnerCalculation
		this.consenusWithPartnerOverState = true;		
		for (int k = 0; k < transPartnerCalculation.size(); k++) {		
			boolean addressMatch = transOwnCalculation.get(k).getAddress().equals(transPartnerCalculation.get(k).getAddress());
			boolean valueMatch = (transOwnCalculation.get(k).getValue() == transPartnerCalculation.get(k).getValue());			
			if (!addressMatch || !valueMatch) {
				this.consenusWithPartnerOverState = false;
			}
		}

		// build bundle with list of incoming transaction trytes from partner and sign
		Bundle generateBundle = new Bundle(transPartnerCalculation, transPartnerCalculation.size());

		this.validSignature = sign.validateSignatures(generateBundle, addressInputWithoutCheckSum);
			
		return (this.validSignature && this.consenusWithPartnerOverState);
	}
	
	// Getters and Setters
	public boolean isConsenusWithPartnerOverState() {
		return this.consenusWithPartnerOverState;
	}

	public boolean isValidSignature() {
		return this.validSignature;
	}

	public String getBundleHash() {
		return this.bundleHash;
	}
}