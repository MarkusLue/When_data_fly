package preloaderAndLogger;

import java.util.HashMap;

import org.iota.jota.IotaAPI;
import org.iota.jota.pow.pearldiver.PearlDiverLocalPoW;
import org.iota.jota.utils.Multisig;
import org.iota.jota.utils.SeedRandomGenerator;

import errors.SeedWithoutBalanceError;
import multiTransaction.sign.SingleSign;
import remotePow.RemotePow;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Class that enables the Preload/Prefetching routine. In this class the following is done:

// Set local, or outsourced PoW, set boosted PoW (FPGA)
// Find key index, where addresses have balance
// Precalculate multi-signature digests.

public class IotaPreload {

	// Handed during Generation
	private IotaAPI iotaAPI;
	private boolean localPOW, boostedPOW;
	private String mainSeed, name, randomSeed, multiSignDigests, addressWithBalanceMainSeed, nextUnspentAddressMainSeed, nextUnspentAddressRandomSeed;
	private int depth, mwm, seedSec, searchLength, seedSecMulti, keyWithBalanceMainSeed;
	private long balanceAddressMainSeed;
	private SingleSign SinSig;

	// If user does not have an initial seed, an error is thrown later
	@SuppressWarnings("static-access")
	public IotaPreload(String inName, IotaAPI inIotaAPI, boolean inLocalPOW, boolean inBoostedPOW, int inDepth, int inMwm, int inSeedSec, int inSearchLength,
			int inSeedSecMulti) throws SeedWithoutBalanceError {
		
		this(inName, inIotaAPI, inLocalPOW, inBoostedPOW, 0, new SeedRandomGenerator().generateNewSeed(), inDepth, inMwm, inSeedSec, inSearchLength,
				inSeedSecMulti);
	}

	// Constructor, that is usually used
	@SuppressWarnings("static-access")
	public IotaPreload(String inName, IotaAPI inIotaAPI, boolean inLocalPOW, boolean inBoostedPOW, int inInitialKey, String inSeed, int inDepth, int inMwm,
			int inSeedSec, int inSearchLength, int inSeedSecMulti) throws SeedWithoutBalanceError {

		this.name = inName;
		this.iotaAPI = inIotaAPI;
		this.localPOW = inLocalPOW;
		this.boostedPOW = inBoostedPOW;
		this.mainSeed = inSeed;
		this.randomSeed = new SeedRandomGenerator().generateNewSeed();
		this.keyWithBalanceMainSeed = inInitialKey;
		this.depth = inDepth;
		this.mwm = inMwm;
		this.searchLength = inSearchLength;
		this.seedSec = inSeedSec;
		this.seedSecMulti = inSeedSecMulti;

		// Configure local PoW either boosted or on device
	//To Do -> get IP from Connection Helper	
		RemotePow remotePoW = new RemotePow("192.168.1.138");
		if (this.localPOW && this.boostedPOW) {
			this.iotaAPI.setLocalPoW(remotePoW);
		} else if (this.localPOW && !this.boostedPOW) {
			this.iotaAPI.setLocalPoW(new PearlDiverLocalPoW());
		}

		// Get next unspent balance on seed with balance and random seed
		this.SinSig = new SingleSign(this.iotaAPI, remotePoW);
		this.nextUnspentAddressMainSeed = SinSig.getNextUnspentAddress(this.mainSeed, this.seedSec, this.keyWithBalanceMainSeed, this.boostedPOW);
		this.nextUnspentAddressRandomSeed = SinSig.getNextUnspentAddress(this.randomSeed, this.seedSec, this.keyWithBalanceMainSeed, this.boostedPOW);

		System.out.println(this.name + ": Next unspend address on main seed: " + this.nextUnspentAddressMainSeed);

		// On seed with balance get the "only" address that has balance on it, 
		// save balance and key (code written in a way, that only one address on the seed should have balance)
		HashMap<Integer, String[]> mapInAddrMainSeed = SinSig.getInitialSetOfAddresses(this.mainSeed, this.seedSec, this.boostedPOW,
				this.keyWithBalanceMainSeed, this.searchLength);

		this.checkIfSeedHasBalance(mapInAddrMainSeed);
		this.getDigest();

	}

	private void checkIfSeedHasBalance(HashMap<Integer, String[]> inMapInAddrMainSeed) throws SeedWithoutBalanceError {

		// This class checks whether the main seed has balance on the addresses 
		// with index in between the defined key areas

		long balance = Long.parseLong(inMapInAddrMainSeed.get(9999)[1]);
		int addressNumber = Integer.parseInt(inMapInAddrMainSeed.get(9999)[0]);
		if (balance == 0) {

			for (int i = 0; i < inMapInAddrMainSeed.size() - 1; i++) {
				System.out
						.println("Address: (" + i + ") " + inMapInAddrMainSeed.get(i)[0].substring(0, 20) + "... , Balance: " + inMapInAddrMainSeed.get(i)[1]);
			}

			throw new SeedWithoutBalanceError("\n\n" + this.name + ": Please make sure that there is balance on seed: " + this.mainSeed + "\nBetween key "
					+ (this.keyWithBalanceMainSeed) + " and " + (this.keyWithBalanceMainSeed + this.searchLength) + "\n");
		} else {
			// set necessary markers on address on the seed with highest balance.
			this.balanceAddressMainSeed = balance;
			this.keyWithBalanceMainSeed = addressNumber;
			this.addressWithBalanceMainSeed = inMapInAddrMainSeed.get(addressNumber)[0];
			System.out.println(this.name + ": Preload found most balance (" + this.balanceAddressMainSeed + "i) on address (Key: "
					+ (this.keyWithBalanceMainSeed) + "), " + this.addressWithBalanceMainSeed);
		}

	}

	private String getDigest() {
		// Method returns the Digest for multi-sign operations later.
		// multi-sign digest can have any key-index: convention is 0.
		this.multiSignDigests = new Multisig().getDigest(this.randomSeed, this.seedSecMulti, 0);
		return this.multiSignDigests;
	}

	// Getters and Setters:
	
	public int getSeedSec() {
		return seedSec;
	}

	public String getMainSeed() {
		return mainSeed;
	}

	public String getRandomSeed() {
		return randomSeed;
	}

	public String getMultiSignDigests() {
		return multiSignDigests;
	}

	public String getAddressWithBalanceMainSeed() {
		return addressWithBalanceMainSeed;
	}

	public int getKeyWithBalanceMainSeed() {
		return keyWithBalanceMainSeed;
	}

	public long getBalanceAddressMainSeed() {
		return balanceAddressMainSeed;
	}

	public String getNextUnspentAddressMainSeed() {
		return nextUnspentAddressMainSeed;
	}

	public String getNextUnspentAddressRandomSeed() {
		return nextUnspentAddressRandomSeed;
	}

	public SingleSign getSinSig() {
		return SinSig;
	}

	public int getDepth() {
		return depth;
	}

	public int getMwm() {
		return mwm;
	}

	public IotaAPI getIotaAPI() {
		return iotaAPI;
	}

}
