package preloaderAndLogger;

import java.net.InetAddress;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// ConnectionHelper checks the connection to two hardware devices: FPGA PoW accelerator, 802.11p enabled router.
// If the connection can be established the variables routerReachable, powReachable are set accordingly.

public class ConnectionHelper {

	// Set via constructor
	private int port;
	private String targetUrl, powURL;

	// Set in operations
	private boolean routerReachable, powReachable;

	public ConnectionHelper(int inPort, String inTargetUrl, String inPowURL) {

		this.port = inPort;
		this.targetUrl = inTargetUrl;
		this.powURL = inPowURL;
		this.routerReachable = false;
		this.powReachable = false;
		this.checkConnections();
	}
	
	// Method that checks the connections to the two hardware devices:
	
	private void checkConnections() {

		// Check connection to Router
		this.routerReachable = false;
		try {
			InetAddress addressRouter = InetAddress.getByName(this.targetUrl);
			if (addressRouter.isReachable(1500)) {
				this.routerReachable = true;
			} else {
				this.routerReachable = false;
			}
		} catch (Exception e) {
			System.out.println("Can't precheck the connections( " + this.targetUrl + "): " + e.getMessage());
		}
		
		// Check the connection to PoW accalerator
		try {
			InetAddress addressFpgaAccelerator = InetAddress.getByName(this.powURL);
			if (addressFpgaAccelerator.isReachable(1500)) {
				this.powReachable = true;
			} else {
				this.powReachable = false;
			}
		} catch (Exception e) {
			System.out.println("Can't precheck the connections( " + this.powURL + "): " + e.getMessage());
		}
	}

	// Setters and Getters:
	public int getPort() {
		return port;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public String getPowURL() {
		return powURL;
	}

	public boolean isRouterReachable() {
		return routerReachable;
	}

	public boolean isPowReachable() {
		return powReachable;
	}

}
