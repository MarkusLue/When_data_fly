package preloaderAndLogger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.json.JSONObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Class handles the writing and reading related tasks:
// read a locally stored object to get initially needed data to run (e.g. the seed, seedIndex, etc.)
// Updated this data during operations (e.g., new key index where addresses have balance)
// Wirte file to hard-drive, that contains the bought vehicle data received by the RSU

public class ReaderWriteFile {


	// initially handed data
	private String path;

	// data read from file and wrote to file
	private String name, seed, messageRSAKey, ownRepLink, targetUrlNode, routerUrl, boostedPowUrl;
	private int seedIndex, minWeightMagnitude, routerPort;
	private boolean powLocal;
	private JSONObject boughtToWrite;

	public ReaderWriteFile(String inPath, String inName) {
		this.path = inPath;
		this.name = inName;
		this.boughtToWrite = new JSONObject();

		this.readInitialData();
	}
	
	public ReaderWriteFile(String inPath, String inName, String inSeed, int inSeedIndex, String inMessageRSAKey, String inOwnRepLink, int inMinWeightMagnitude,
			boolean inPowLocal, String inTargetUrlNode, String inRouterUrl, int inRouterPort, String inBoostedPowUrl) {

		// this constructor is only used to once generate the file 
		// on the hard drive that stores the initially needed data
		this.path = inPath;
		this.name = inName;
		this.seed = inSeed;
		this.seedIndex = inSeedIndex;
		this.messageRSAKey = inMessageRSAKey;
		this.ownRepLink = inOwnRepLink;
		this.minWeightMagnitude = inMinWeightMagnitude;
		this.powLocal = inPowLocal;
		this.targetUrlNode = inTargetUrlNode;
		this.routerUrl = inRouterUrl;
		this.routerPort = inRouterPort;
		this.boostedPowUrl = inBoostedPowUrl;
		this.boughtToWrite = new JSONObject();
	}

	public void writeInitialData() throws IOException {

		// if the initially received data changes, this function 
		// updates the file containing that data on the hard drive
		
		JSONObject toWrite = new JSONObject();
		toWrite.put("name", this.name);
		toWrite.put("seed", this.seed);
		toWrite.put("seedIndex", this.seedIndex);
		toWrite.put("messageRSAKey", this.messageRSAKey);
		toWrite.put("ownRepLink", this.ownRepLink);
		toWrite.put("minWeightMagnitude", this.minWeightMagnitude);
		toWrite.put("powLocal", this.powLocal);
		toWrite.put("targetUrlNode", this.targetUrlNode);
		toWrite.put("routerUrl", this.routerUrl);
		toWrite.put("routerPort", this.routerPort);
		toWrite.put("boostedPowUrl", this.boostedPowUrl);
		toWrite.put("dateAndTime", LocalDateTime.now().toString());
		
		String outLocation = this.path + "/initialData_" + this.name + ".txt";
		
		File targetFile = new File(outLocation);
		targetFile.createNewFile();
		FileOutputStream fileOutputStream = new FileOutputStream(targetFile, false); 
		
	    try {
			byte[] contentInBytes = toWrite.toString().getBytes();
			fileOutputStream.write(contentInBytes);
			fileOutputStream.flush();
			fileOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readInitialData() {
		
		// while startup (during preloading) initially needed data is read and made accessible
		// Method reads data stored in file as JSON-representation
		
		String outLocation = this.path + "/initialData_" + this.name + ".txt";
		String lineInput = null;
		
		try {
			FileReader input = new FileReader(outLocation);
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(input);
			String nextLine = null;
			while ((nextLine = reader.readLine()) != null) {
				lineInput = nextLine;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		JSONObject toRead = new JSONObject(lineInput);
		this.name = (String) toRead.get("name");
		this.seed = (String) toRead.get("seed");
		this.seedIndex = (int) toRead.get("seedIndex");
		this.messageRSAKey = (String) toRead.get("messageRSAKey");
		this.ownRepLink = (String) toRead.get("ownRepLink");
		this.minWeightMagnitude = (int) toRead.get("minWeightMagnitude");
		this.powLocal = (boolean) toRead.get("powLocal");
		this.targetUrlNode = (String) toRead.get("targetUrlNode");
		this.routerUrl = (String) toRead.get("routerUrl");
		this.routerPort = (int) toRead.get("routerPort");
		this.boostedPowUrl = (String) toRead.get("boostedPowUrl");

	}

	public void addBoughtData(String inValue, String inPID, String inName, String inUnit) {
		
		// function is called, every time a single datapoint is received. 
		// Functions collects data points until this.writeBoughtData() is called, 
		// which write all data to hard-drive.
		
		JSONObject jTemp = new JSONObject();
		jTemp.put("Name", inName);
		jTemp.put("Unit", inUnit);
		jTemp.put("Value", inValue);
		this.boughtToWrite.put(inPID, jTemp);
		
	}
	
	public void writeBoughtData(String inNamePartner) throws IOException {
	
		// function is called, after all bought data was received, 
		// function then writes data combined to hard drive
		
		// Date is part of filename
		LocalDateTime now = LocalDateTime.now();
		JSONObject jTempALL = new JSONObject();

		JSONObject jTemp1 = new JSONObject();
		jTemp1.put("dateAndTime", now.toString());
		jTemp1.put("UserID", inNamePartner);
		
		jTempALL.put("Meta_Data", jTemp1);
		jTempALL.put("Transactions", this.boughtToWrite);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMMyyyy_");
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH");
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("mm");
		DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("ss");
		String outputFileName = dtf.format(now) + dtf1.format(now) + "h" + dtf2.format(now) + "m" + dtf3.format(now) + "s";
		
		String namePartner = inNamePartner;
		
		if (namePartner.length() > 20) {
			namePartner = namePartner.substring(0, 20);
		}
		
		String pathToWrite = this.path + "/bought/" + namePartner + "_" + outputFileName + ".txt";
		
		File targetFile = new File(pathToWrite);
		targetFile.createNewFile();
		FileOutputStream fileOutStream = new FileOutputStream(targetFile, false); 
		
	    try {
			byte[] contentInBytes = jTempALL.toString().getBytes();
			fileOutStream.write(contentInBytes);
			fileOutStream.flush();
			fileOutStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.boughtToWrite = new JSONObject();
	}
	
	
	// Getters and Setters
	
	public String getName() {
		return name;
	}

	public void setName(String name) throws IOException {
		this.name = name;
		this.writeInitialData();
	}

	public String getSeed() {
		return seed;
	}

	public void setSeed(String seed) throws IOException {
		this.seed = seed;
		this.writeInitialData();
	}

	public int getSeedIndex() {
		return seedIndex;
	}

	public void setSeedIndex(int seedIndex) throws IOException {
		this.seedIndex = seedIndex;
		this.writeInitialData();
	}

	public String getMessageRSAKey() {
		return messageRSAKey;
	}

	public void setMessageRSAKey(String messageRSAKey) throws IOException {
		this.messageRSAKey = messageRSAKey;
		this.writeInitialData();
	}

	public String getOwnRepLink() {
		return ownRepLink;
	}

	public void setOwnRepLink(String ownRepLink) throws IOException {
		this.ownRepLink = ownRepLink;
		this.writeInitialData();
	}

	public int getMinWeightMagnitude() {
		return minWeightMagnitude;
	}

	public void setMinWeightMagnitude(int minWeightMagnitude) throws IOException {
		this.minWeightMagnitude = minWeightMagnitude;
		this.writeInitialData();
	}

	public boolean isPowLocal() {
		return powLocal;
	}

	public void setPowLocal(boolean powLocal) throws IOException {
		this.powLocal = powLocal;
		this.writeInitialData();
	}

	public String getTargetUrlNode() {
		return targetUrlNode;
	}

	public void setTargetUrlNode(String targetUrlNode) throws IOException {
		this.targetUrlNode = targetUrlNode;
		this.writeInitialData();
	}

	public String getRouterUrl() {
		return routerUrl;
	}

	public void setRouterUrl(String routerUrl) throws IOException {
		this.routerUrl = routerUrl;
		this.writeInitialData();
	}

	public int getRouterPort() {
		return routerPort;
	}

	public void setRouterPort(int routerPort) throws IOException {
		this.routerPort = routerPort;
		this.writeInitialData();
	}

	public String getBoostedPowUrl() {
		return boostedPowUrl;
	}

	public void setBoostedPowUrl(String boostedPowUrl) throws IOException {
		this.boostedPowUrl = boostedPowUrl;
		this.writeInitialData();
	}

	public String getPath() {
		return path;
	}
}
