package preloaderAndLogger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Hashtable;
import org.json.JSONObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The aim of this object is to encapsulate all logging functions during one
// session. Vehicle Data, Prices, Timing, Sent Data Amount are logged.

// Additionally, this file helps to check, if a timeOut was reached while waiting on 
// the partners response

public class TimeAndDataLogger {

	public static long timeOutValue = 20000;

	@SuppressWarnings("unused")
	private boolean isBuyer, localPoW, boostedPoW, fullCycle;
	private long sessionStarted, midTime, endTime, mwm, preloadingTime;
	private String path, multiSignatureAddress;
	private double[] ratingBeforeTrade, ratedTrade;

	// Storage Variables for PoW Timing
	private long powSingleTxTransfer, powSingleTxTransferOutsourced, powMultiTxTransfer, powRatingTxTransfer, timeAdHocMSG;

	// Storage Variables for Node Query Timing
	private long nodeQueryGetRating, nodeQuerySingleTxTransfer, nodeQueryMultiTxTransfer;

	// Storage for Data
	private JSONObject boughtToWrite;

	// Storage logging the first unix timestamp, when a MSG Type was first received
	private HashMap<Integer, Long> receivedMsgTimeXXX, firstTimeMsgSent, byteSumMsgSent;
	private HashMap<Integer, Integer> amountMsgSent;
	private JSONObject jsonRaw;

	public TimeAndDataLogger(boolean inIsBuyer, String inPath) {

		// Initialize Time Keepers
		this.powSingleTxTransfer = 0;
		this.powSingleTxTransferOutsourced = 0;
		this.powMultiTxTransfer = 0;
		this.powRatingTxTransfer = 0;
		this.nodeQueryGetRating = 0;
		this.nodeQuerySingleTxTransfer = 0;
		this.nodeQueryMultiTxTransfer = 0;
		this.endTime = 0;
		this.midTime = 0;
		this.path = inPath;
		this.multiSignatureAddress = "null";
		this.fullCycle = false;
		this.timeAdHocMSG = 0;
		this.preloadingTime = 0;
		this.jsonRaw = new JSONObject();
		
		this.isBuyer = inIsBuyer;
		this.sessionStarted = 0;
		this.receivedMsgTimeXXX = new HashMap<Integer, Long>();

		this.firstTimeMsgSent = new HashMap<Integer, Long>();
		this.amountMsgSent = new HashMap<Integer, Integer>();
		this.byteSumMsgSent = new HashMap<Integer, Long>();
		this.boughtToWrite = new JSONObject();

	}

	public void triggerWrite(String inNamePartner, Hashtable<String, Hashtable<Integer, Integer>> inTable) {

		// Method writes all data stored to hard-drive

		this.endTime = System.currentTimeMillis();
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMMyyyy_");
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH");
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("mm");
		DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("ss");
		String outputFileName = dtf.format(now) + dtf1.format(now) + "h" + dtf2.format(now) + "m" + dtf3.format(now) + "s";

		// Write Evaluation Part
		JSONObject jsonComplete = new JSONObject();
		JSONObject jsonMetaData = new JSONObject();
		JSONObject jsonDuration = new JSONObject();
		JSONObject jsonPow = new JSONObject();
		JSONObject jsonNodeQuery = new JSONObject();
		JSONObject jsonEvaluation = new JSONObject();
		JSONObject jsonRating = new JSONObject();

		// Set Meta Data of Evaluation
		jsonMetaData.put("dateAndTime", now.toString());
		jsonMetaData.put("UserID_TradeWith", inNamePartner);
		jsonMetaData.put("StartTime", this.sessionStarted);
		jsonMetaData.put("MidTime", this.midTime);
		jsonMetaData.put("EndTime", this.endTime);
		jsonMetaData.put("MWM", this.mwm);
		jsonMetaData.put("BoostedPoW", this.boostedPoW);
		jsonComplete.put("Meta_Data", jsonMetaData);

		// Set Timing Related Data
		jsonDuration.put("Duration_Preloading", this.preloadingTime);
		jsonDuration.put("Duration_AdHocTrade", (this.midTime - this.timeAdHocMSG));
		jsonDuration.put("Duration_PostCritical", (this.endTime- this.midTime));
		jsonDuration.put("Duration_Critical", (this.midTime - this.sessionStarted));
		jsonDuration.put("Duration_OverAll", (this.endTime - this.sessionStarted + this.preloadingTime));
		jsonComplete.put("Duration_Data", jsonDuration);

		// Set PoW data
		jsonPow.put("powPartCritical", (this.powSingleTxTransfer + this.powSingleTxTransferOutsourced));
		jsonPow.put("powSingleTxTransfer", this.powSingleTxTransfer);
		jsonPow.put("powSingleTxTransferOutsourced", this.powSingleTxTransferOutsourced);
		jsonPow.put("powMultiTxTransfer", this.powMultiTxTransfer);
		jsonPow.put("powRatingTxTransfer", this.powRatingTxTransfer);
		jsonComplete.put("pow_Data", jsonPow);

		// Set node query data
		jsonNodeQuery.put("nodeQueryPartCritical", (this.nodeQueryGetRating + this.nodeQuerySingleTxTransfer));
		jsonNodeQuery.put("nodeQueryGetRating", this.nodeQueryGetRating);
		jsonNodeQuery.put("nodeQuerySingleTxTransfer", this.nodeQuerySingleTxTransfer);
		jsonNodeQuery.put("nodeQueryMultiTxTransfer", this.nodeQueryMultiTxTransfer);
		jsonComplete.put("nodeQuery_Data", jsonNodeQuery);

		// Amount Messages Sent and Received
		jsonEvaluation.put("AmountMSGSent", this.amountMsgSent);
		jsonEvaluation.put("BytesSent", this.byteSumMsgSent);
		jsonEvaluation.put("FullCycle", this.fullCycle);
		jsonEvaluation.put("ReceivedMessagesByType", inTable.get(inNamePartner));
		
		jsonEvaluation.put("NumberAllMSGSent", this.getHashMapSum(this.amountMsgSent));
		jsonEvaluation.put("NumberAllMSGReceived", this.getHashTableSum(inTable.get(inNamePartner)));

		jsonComplete.put("RawDataJSON", this.jsonRaw);
		
		for (int k = 0; k < this.ratedTrade.length; k++) {
			jsonRating.put(("RatingBefore_" + k), this.ratingBeforeTrade[k]);
		}
		for (int k = 0; k < this.ratedTrade.length; k++) {
			jsonRating.put(("RatingAfter_" + k), this.ratedTrade[k]);
		}
		jsonEvaluation.put("RatingData", jsonRating);
		jsonComplete.put("Evaluation_Data", jsonEvaluation);

		// Generate Path and File Name
		String characterizer = "VEHICLE";
		if (this.isBuyer) {
			characterizer = "RSU";
		}
		String pathToWrite = this.path + "/evaluation/" + "evaluation_of_" + characterizer + "_" + outputFileName + ".txt";
		File targetFile = new File(pathToWrite);

		// Write Data
		try {
			targetFile.createNewFile();
			FileOutputStream fileOutputStream = new FileOutputStream(targetFile, false);
			byte[] outputAsBytes = jsonComplete.toString().getBytes();
			fileOutputStream.write(outputAsBytes);
			fileOutputStream.flush();
			fileOutputStream.close();
		} catch (IOException exception) {
			exception.printStackTrace();
		}

		// this part of the method writes data received combined to hard drive
		if (this.isBuyer) {

			String namePartner = inNamePartner;
			if (namePartner.length() > 20) {
				namePartner = namePartner.substring(0, 20);
			}

			jsonComplete = new JSONObject();
			jsonMetaData = new JSONObject();
			jsonMetaData.put("dateAndTime", now.toString());
			jsonMetaData.put("UserID", inNamePartner);

			jsonComplete.put("Meta_Data", jsonMetaData);
			jsonComplete.put("Transactions", this.boughtToWrite);

			pathToWrite = this.path + "/bought/" + "tradeData_from_" + namePartner + "_" + outputFileName + ".txt";
			targetFile = new File(pathToWrite);

			try {
				targetFile.createNewFile();
				FileOutputStream fileOutputStream = new FileOutputStream(targetFile, false);
				byte[] outputAsBytes = jsonComplete.toString().getBytes();
				fileOutputStream.write(outputAsBytes);
				fileOutputStream.flush();
				fileOutputStream.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}
	}
	
	
	private int getHashMapSum(HashMap<Integer, Integer> inMap) {
		
		// Method that returns the sum of a Integer-Value HashMap	
		int returnSum = 0;
		for (int f : inMap.values()) {
			returnSum += f;
		}
		return returnSum;
	}
	
	private int getHashTableSum(Hashtable<Integer, Integer> inTable) {
		
		// Method that returns the sum of a Integer-Value HashTable
		int returnSum = 0;
		for (int f : inTable.values()) {
			returnSum += f;
		}
		return returnSum;
	}


	public void addBoughtData(String inValue, String inPID, String inName, String inUnit) {

		// function is called, every time a single datapoint is received. Functions
		// collects data points until this.writeBoughtData() is called.

		JSONObject jTemp = new JSONObject();
		jTemp.put("Name", inName);
		jTemp.put("Unit", inUnit);
		jTemp.put("Value", inValue);
		this.boughtToWrite.put(inPID, jTemp);

	}

	public boolean setReceivedMSG(int i) {

		// Method tests, if a message with this type descriptor was already added.
		// if yes -> return false, otherwise the timestamp is logged and true returned

		if (this.receivedMsgTimeXXX.containsKey(i)) {
			return false;
		} else {
			this.receivedMsgTimeXXX.put(i, System.currentTimeMillis());
			return true;
		}
	}

	public void sendMSGfromType(int i, String inMSG) {

		// Count the message sent, for logging purposes.
		
		long currentTime = System.currentTimeMillis();
		long byteSumCurrentMSG = inMSG.getBytes().length;

		// 1st step, check if HashMap already has this key
		if (this.firstTimeMsgSent.containsKey(i) && this.amountMsgSent.containsKey(i) && this.byteSumMsgSent.containsKey(i)) {

			// Increase the stored number the MSG was sent.
			int alreadySentAmount = this.amountMsgSent.get(i);
			this.amountMsgSent.put(i, (alreadySentAmount + 1));

			// Add the number of Bytes sent via router
			long alreadyByteSumSent = this.byteSumMsgSent.get(i);
			this.byteSumMsgSent.put(i, (alreadyByteSumSent + byteSumCurrentMSG));

		} else {

			// Set first time values for all storage objects.
			this.firstTimeMsgSent.put(i, currentTime);
			this.amountMsgSent.put(i, 1);
			this.byteSumMsgSent.put(i, byteSumCurrentMSG);
		}
	}
	
	public void addRawData(String inString) {
		
		if (!this.jsonRaw.has(inString)) {
			this.jsonRaw.put(inString, System.currentTimeMillis());
		} else {
			// Do not re-enter String, since only first entry should count (login in while statements)
		}
	}

	public boolean timeOut(int i, String inMSG) {

		// Check if timeOut was reached, and store send message analog to previous method.

		long currentTime = System.currentTimeMillis();

		// 1st step, check if HashMap already has this key
		if (this.firstTimeMsgSent.containsKey(i)) {

			// Check for Timeout and return boolean if already in timeout
			long timeDiff = currentTime - this.firstTimeMsgSent.get(i);
			if (timeDiff < timeOutValue) {
				return false;
			} else {

				// if i = 1, never throw TimeOut
				if (i == 1) {
					return false;
				} else {
					System.out.println("TimeOut with MSG Key: " + i);
					return true;
				}
			}
		} else {

			// Set first time values for all storage objects.
			this.firstTimeMsgSent.put(i, currentTime);
			return false;
		}
	}

	// Setters and Getters:
	
	public long getSessionStarted() {
		return sessionStarted;
	}

	public void setSessionStarted(long sessionStarted) {
		this.sessionStarted = sessionStarted;
	}

	public long getPowSingleTxTransfer() {
		return powSingleTxTransfer;
	}

	public void setPowSingleTxTransfer(long powSingleTxTransfer) {
		this.powSingleTxTransfer = powSingleTxTransfer;
	}

	public long getPowSingleTxTransferOutsourced() {
		return powSingleTxTransferOutsourced;
	}

	public void setPowSingleTxTransferOutsourced(long powSingleTxTransferOutsourced) {
		this.powSingleTxTransferOutsourced = powSingleTxTransferOutsourced;
	}

	public long getPowMultiTxTransfer() {
		return powMultiTxTransfer;
	}

	public void setPowMultiTxTransfer(long powMultiTxTransfer) {
		this.powMultiTxTransfer = powMultiTxTransfer;
	}

	public long getPowRatingTxTransfer() {
		return powRatingTxTransfer;
	}

	public void setPowRatingTxTransfer(long powRatingTxTransfer) {
		this.powRatingTxTransfer = powRatingTxTransfer;
	}

	public long getNodeQueryGetRating() {
		return nodeQueryGetRating;
	}

	public void setNodeQueryGetRating(long nodeQueryGetRating) {
		this.nodeQueryGetRating = nodeQueryGetRating;
	}

	public long getNodeQuerySingleTxTransfer() {
		return nodeQuerySingleTxTransfer;
	}

	public void setNodeQuerySingleTxTransfer(long nodeQuerySingleTxTransfer) {
		this.nodeQuerySingleTxTransfer = nodeQuerySingleTxTransfer;
	}

	public long getNodeQueryMultiTxTransfer() {
		return nodeQueryMultiTxTransfer;
	}

	public void setNodeQueryMultiTxTransfer(long nodeQueryMultiTxTransfer) {
		this.nodeQueryMultiTxTransfer = nodeQueryMultiTxTransfer;
	}

	public HashMap<Integer, Long> getReceivedMsgTimeXXX() {
		return receivedMsgTimeXXX;
	}

	public void setReceivedMsgTimeXXX(HashMap<Integer, Long> receivedMsgTimeXXX) {
		this.receivedMsgTimeXXX = receivedMsgTimeXXX;
	}

	public HashMap<Integer, Long> getFirstTimeMsgSent() {
		return firstTimeMsgSent;
	}

	public void setFirstTimeMsgSent(HashMap<Integer, Long> firstTimeMsgSent) {
		this.firstTimeMsgSent = firstTimeMsgSent;
	}

	public HashMap<Integer, Integer> getAmountMsgSent() {
		return amountMsgSent;
	}

	public void setAmountMsgSent(HashMap<Integer, Integer> amountMsgSent) {
		this.amountMsgSent = amountMsgSent;
	}

	public HashMap<Integer, Long> getByteSumMsgSent() {
		return byteSumMsgSent;
	}

	public void setByteSumMsgSent(HashMap<Integer, Long> byteSumMsgSent) {
		this.byteSumMsgSent = byteSumMsgSent;
	}

	public long getMidTime() {
		return midTime;
	}

	public void setMidTime(long midTime) {
		this.midTime = midTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public String getMultiSignatureAddress() {
		return multiSignatureAddress;
	}

	public void setMultiSignatureAddress(String multiSignatureAddress) {
		this.multiSignatureAddress = multiSignatureAddress;
	}

	public void setLocalPoW(boolean inLocalPoW) {
		this.localPoW = inLocalPoW;
	}

	public void setBoostedPoW(boolean inBoostedPow) {
		this.boostedPoW = inBoostedPow;
	}

	public void setMwm(long mwm) {
		this.mwm = mwm;
	}

	public double[] getRatingBeforeTrade() {
		return ratingBeforeTrade;
	}

	public void setRatingBeforeTrade(double[] ratingBeforeTrade) {
		this.ratingBeforeTrade = ratingBeforeTrade;
	}

	public double[] getRatedTrade() {
		return ratedTrade;
	}

	public void setRatedTrade(double[] ratedTrade) {
		this.ratedTrade = ratedTrade;
	}

	public void setFullCycle(boolean fullCycle) {
		this.fullCycle = fullCycle;
	}

	public void setTimeAdHocMSG(long timeAdHocMSG) {
		this.timeAdHocMSG = timeAdHocMSG;
	}

	public void setPreloadingTime(long preloadingTime) {
		this.preloadingTime = preloadingTime;
	}
	
}
