package runWithRouter;

import java.io.IOException;
import java.util.Locale;

import org.iota.jota.IotaAPI;

import enums.MainProps.IsBuyer;
import enums.MainProps.OutsourcedPow;
import enums.MainProps.QueryForObd2Data;
import errors.SeedWithoutBalanceError;
import preloaderAndLogger.ConnectionHelper;
import preloaderAndLogger.IotaPreload;
import preloaderAndLogger.ReaderWriteFile;
import reputationAndIdentity.TrustConfiguration_VEHICLE;
import routerCommunication.EncryptionObject;
import routerCommunication.ThreadCommunicator;
import vehicleData.VehicleDataThread;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This file is the Thread that configures and carries out the ad-hoc data exchange on the VEHICLE side.

public class VehicleThread implements Runnable {

	private static int depth = 3; 					// default for comnet and mainnet
	private static int seedSecSingleTx = 1; 		// security for single TX, can be 1-3 -> 1 needs least amout of time
	private static int seedSecMultiTx = 1; 			// security for single TX, can be 1
	private static int searchLength = 3;			// Batch number of indices of the seed, that are to be queried for tokens
	
	// Path where output files are to be stored. Folder must already exist.
	private static String path = "INSERT_PATH";
	
	private ReaderWriteFile rwfVEHICLE;
	private IotaAPI api_Vehicle;
	private ConnectionHelper conHelpVEHICLE;
	private IotaPreload preloadVehicle;
	private EncryptionObject encryptionVehicle;
	private VehicleDataThread vehiDataThread;
	private ThreadCommunicator tRSU;
	private ThreadCommunicator tVehicle;
	private TrustConfiguration_VEHICLE tcVEHICLE;
	
	public VehicleThread() throws SeedWithoutBalanceError, IOException {
		
		// Generalize program context
		Locale.setDefault(Locale.US);
		long preloadingStartDate = System.currentTimeMillis();
		boolean powLocal = true;

		// Read Initial Data
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nSetting up the API:");
		this.rwfVEHICLE = new ReaderWriteFile(path, "VEHICLE");
		this.api_Vehicle = new IotaAPI.Builder().protocol("http").host(this.rwfVEHICLE.getTargetUrlNode()).port(14265).build(); 
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nChecking Connections:");

		// Connection Helper checks if 802.11p router and FPGA PoW Accelerator are available via Ethernet
		this.conHelpVEHICLE = new ConnectionHelper(5555, rwfVEHICLE.getRouterUrl(), rwfVEHICLE.getBoostedPowUrl());
		System.out.println(rwfVEHICLE.getName() + " checked router: " + conHelpVEHICLE.isRouterReachable() + " and boosted pow: " + conHelpVEHICLE.isPowReachable());
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nStart Preloading:");
		
		// Preloading is started:
		this.preloadVehicle = new IotaPreload(rwfVEHICLE.getName(), api_Vehicle, powLocal, conHelpVEHICLE.isPowReachable(), rwfVEHICLE.getSeedIndex(),rwfVEHICLE.getSeed(), depth, rwfVEHICLE.getMinWeightMagnitude(), seedSecSingleTx, searchLength, seedSecMultiTx);
		rwfVEHICLE.setSeedIndex(preloadVehicle.getKeyWithBalanceMainSeed());
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

		// Initialize encryption object with predetermined private and public keys
		this.encryptionVehicle = new EncryptionObject(rwfVEHICLE.getMessageRSAKey(), "SELLER");

		// Initialize Random Vehicle Data
		System.out.println("Trying to set up the bluetooth connection with vehicle via OBD2.");
		this.vehiDataThread = new VehicleDataThread(QueryForObd2Data.NO);   
		vehiDataThread.start();
		
		// Preload the IOTA and ConnectionHelper Object
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nChecking Trust:");
		this.tcVEHICLE = new TrustConfiguration_VEHICLE(preloadVehicle.getIotaAPI(), depth, rwfVEHICLE.getMinWeightMagnitude(), rwfVEHICLE.getMessageRSAKey());
		System.out.println("Finsihed setting up the trust configuration.");
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
	
		// Start CommunicatorThread
		long preloadingEndDate = System.currentTimeMillis();
		long preloadingTime = (preloadingEndDate - preloadingStartDate);

		this.tVehicle = new ThreadCommunicator(encryptionVehicle, rwfVEHICLE, conHelpVEHICLE, "VEHICLE", "RSU", IsBuyer.NO,
				rwfVEHICLE.getOwnRepLink(), vehiDataThread, preloadVehicle, OutsourcedPow.NO, seedSecSingleTx, seedSecMultiTx, tcVEHICLE, preloadingTime);
	}
	
	@Override
	public void run() {

		// Simulation of Messaging Objects done without Router
		System.out.println("Vehicle has: " + this.tRSU);
		this.tVehicle.start();

		// RSU: Wait until Thread is done, then wait for confirmation
		while (!(this.tVehicle.isEndedCycle())) {
			try {Thread.sleep(10000);} catch (InterruptedException e) {}
		}

		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		System.out.println("Final bundle confirmed, Overall Cycle ends");
		System.exit(0);
		
	}
	
	public ThreadCommunicator gettVehicle() {
		return this.tVehicle;
	}

	public void settRSU(ThreadCommunicator tRSU) {
		this.tRSU = tRSU;
	}

}
