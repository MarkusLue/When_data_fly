
package runWithRouter;

import java.util.Collections;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONException;
import org.zeromq.ZMQ;

import routerCommunication.EncryptionObject;
import routerCommunication.messages.RouterParentMessage;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This thread connects to the 802.11p enabled router. On the router at a specified
// port, the incoming messages are reported. The thread checks all incoming messages
// and processes them. It checks if a message form a new user arrived, and later if new
// messages of a certain type by this user did arrive. The Thread can be asked for these 
// properties.

public class ThreadListenerRouter extends Thread {

	private EncryptionObject enReciever;
	private Hashtable<String, Hashtable<Integer, String>> userIdMessageIdTable;
	private Hashtable<String, Boolean> userIdHasNews;
	private Hashtable<String, Hashtable<Integer, Boolean>> userIdHasMessageType;
	private Hashtable<String, Hashtable<Integer, Hashtable<Integer, String>>> userMultiPartSave;
	private Hashtable<String, Hashtable<Integer, Integer>> userIdMessageIdCount;
	private boolean runner;

	private int port;
	private String target;

	public ThreadListenerRouter(int inPort, String inTargetURL, EncryptionObject inEnReciever) {

		this.enReciever = inEnReciever;
		this.userIdMessageIdTable = new Hashtable<String, Hashtable<Integer, String>>();
		this.userIdHasNews = new Hashtable<String, Boolean>();
		this.userIdHasMessageType = new Hashtable<String, Hashtable<Integer, Boolean>>();
		this.userMultiPartSave = new Hashtable<String, Hashtable<Integer, Hashtable<Integer, String>>>();
		this.userIdMessageIdCount = new Hashtable<String, Hashtable<Integer, Integer>>();
		this.runner = true;
		this.port = inPort;
		this.target = inTargetURL;
		this.userIdMessageIdTable = new Hashtable<String, Hashtable<Integer, String>>();
	}

	public void run() {

		// Initialize ZMQ Socket
		ZMQ.Context contextRequest = ZMQ.context(2);

		// Subscribe to incoming messages on router
		@SuppressWarnings("deprecation")
		ZMQ.Socket socketRequest = contextRequest.socket(ZMQ.SUB);
		String stringTarget = "tcp://" + this.target + ":" + this.port;
		socketRequest.connect(stringTarget);
		socketRequest.subscribe("");

		while (this.runner) {
			byte[] reply = socketRequest.recv(0);
			String replyAsMessageString = new String(reply);

			try {
				if (!replyAsMessageString.contains("CAM")) {

					RouterParentMessage incomingMessage = new RouterParentMessage(replyAsMessageString, this.enReciever);
					String userID = incomingMessage.getUserID();
					int messageID = incomingMessage.getTypeNumber();

					boolean isMultiPart = incomingMessage.isMultipart();
					int lengthMultiPart = incomingMessage.getMultiPartLength();
					int indexMultiPart = incomingMessage.getMultipartIndex();

					if (this.userIdMessageIdTable.containsKey(userID)) {

						// Was the message already received?
						if (this.userIdMessageIdTable.get(userID).containsKey(messageID)) {
							if (isMultiPart) {
								this.userMultiPartSave.get(userID).get(messageID).put(indexMultiPart, incomingMessage.getPayload());
								int increaseCount = this.userIdMessageIdCount.get(userID).get(messageID) + 1;
								this.userIdMessageIdCount.get(userID).put(messageID, increaseCount);
								
								// Check if multipart is completely there
								boolean allPartsThere = true;
								String newPayload = "";
								boolean[] saveIsThere = new boolean[lengthMultiPart];

								for (int i = 1; i <= lengthMultiPart; i++) {
									if (this.userMultiPartSave.get(userID).get(messageID).containsKey(i)) {
										saveIsThere[i - 1] = true;
										newPayload = newPayload + this.userMultiPartSave.get(userID).get(messageID).get(i);
									} else {
										saveIsThere[i - 1] = false;
										allPartsThere = false;
									}
								}

								// this.printIsThere(saveIsThere);

								if (allPartsThere) {

									incomingMessage.setPayload(newPayload);

									// message is new and saved.
									this.userIdMessageIdTable.get(userID).put(messageID, incomingMessage.calcJSON(0).toString());

									// Save message that userID has news;
									this.userIdHasNews.put(userID, true);
									// System.out.println("New message received and saved.");

									// Save message type in userIdHasMessageType
									this.userIdHasMessageType.get(userID).put(messageID, true);
								}

							} else {
								// message was already received and is ignored, but count increased
								int increaseCount = this.userIdMessageIdCount.get(userID).get(messageID) + 1;
								this.userIdMessageIdCount.get(userID).put(messageID, increaseCount);
							}
						} else {

							// message is new and saved.
							this.userIdMessageIdTable.get(userID).put(messageID, replyAsMessageString);
							this.userIdMessageIdCount.get(userID).put(messageID, 1);

							// only if the message is no multisign the message is set as completely
							// delivered
							if (!isMultiPart) {

								// Save message that userID has news;
								this.userIdHasNews.put(userID, true);
								// System.out.println("New message received and saved.");

								// Save message type in userIdHasMessageType
								this.userIdHasMessageType.get(userID).put(messageID, true);
							}

							this.userMultiPartSave.get(userID).put(messageID, new Hashtable<Integer, String>());
							this.userMultiPartSave.get(userID).get(messageID).put(indexMultiPart, incomingMessage.getPayload());

						}

					} else {

						// New message from counterpart was received, initialize Hashtable and
						// userIdMessageIdTable
						Hashtable<Integer, String> userTable = new Hashtable<Integer, String>();
						userTable.put(messageID, replyAsMessageString);
						this.userIdMessageIdTable.put(userID, userTable);

						if (!isMultiPart) {

							// Save message that user id has news
							this.userIdHasNews.put(userID, true);
							// System.out.println("New message received and saved.");

							// Save message type in userIdHasMessageType
							Hashtable<Integer, Boolean> idTable = new Hashtable<Integer, Boolean>();
							idTable.put(messageID, true);
							this.userIdHasMessageType.put(userID, idTable);
						}

						// Store new User Message
						this.userIdMessageIdCount.put(userID, new Hashtable<Integer, Integer>());
						this.userIdMessageIdCount.get(userID).put(messageID, 1);
						
						this.userMultiPartSave.put(userID, new Hashtable<Integer, Hashtable<Integer, String>>());
						this.userMultiPartSave.get(userID).put(messageID, new Hashtable<Integer, String>());
						this.userMultiPartSave.get(userID).get(messageID).put(indexMultiPart, incomingMessage.getPayload());
					}

				}
			} catch (JSONException e) {
				System.out.println("error: " + e.getMessage());
			}
		}
	}

	public String getLatestsMessage(String UserID) {
		// Method returns the last message sent by a defined user (see ID)
		Hashtable<Integer, String> tempHastTable = this.userIdMessageIdTable.get(UserID);

		this.userIdHasNews.put(UserID, false);

		// find maximum message-index (key) of HashTable
		if (tempHastTable.size() > 0) {
			Set<Integer> keys = tempHastTable.keySet();
			Integer i = Collections.max(keys);
			return this.userIdMessageIdTable.get(UserID).get(i);
		} else {
			return "UserID has no messages.";
		}

	}

	public String getMessagAtIndex(String UserID, int messageIndex) {

		// Method returns the message with a certain message index.
		String returnValue = "error, either UserID or messageIndex invalid";
		try {
			returnValue = this.userIdMessageIdTable.get(UserID).get(messageIndex);
		} catch (Exception e) {
			System.out.println("error, either UserID or messageIndex invalid");
		}
		return returnValue;
	}

	public boolean userHasMessageUpdate(String UserID) {
		// Returns whether there is a new message for a UserID
		return this.userIdHasNews.get(UserID);
	}

	public boolean userHasMessageUpdateByType(String UserID, int inType) {
		
		// Return whether there is a message of type inType for User UserID
		if (this.userIdHasMessageType.get(UserID).get(inType) == null) {
			return false;
		} else if (this.userIdHasMessageType.get(UserID).get(inType)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean hasReceivedInitalMessage() {
		
		// Method returns if a message by a new user was received.
		if (this.userIdMessageIdTable.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public String getInitialMessageUserID() {

		// If a new message from a user arrives, this method return its user ID
		return this.userIdMessageIdTable.keySet().toArray()[0].toString();
	}

	public void setRunner(boolean runner) {
		this.runner = runner;
	}

	public Hashtable<String, Hashtable<Integer, Integer>> getUserIdMessageIdCount() {
		return userIdMessageIdCount;
	}
	
	
}
