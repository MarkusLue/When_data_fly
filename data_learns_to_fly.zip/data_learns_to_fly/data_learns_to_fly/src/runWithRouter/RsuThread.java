package runWithRouter;

import java.io.IOException;
import java.util.Locale;

import org.iota.jota.IotaAPI;

import enums.MainProps.IsBuyer;
import enums.MainProps.OutsourcedPow;
import enums.MainProps.QueryForObd2Data;
import errors.SeedWithoutBalanceError;
import preloaderAndLogger.ConnectionHelper;
import preloaderAndLogger.IotaPreload;
import preloaderAndLogger.ReaderWriteFile;
import reputationAndIdentity.TrustConfiguration_RSU;
import routerCommunication.EncryptionObject;
import routerCommunication.ThreadCommunicator;
import vehicleData.VehicleDataThread;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This file is the Thread that configures and carries out the ad-hoc data exchange on the VEHICLE side.


public class RsuThread implements Runnable {

	private static int depth = 3; 					// default for comnet and mainnet
	private static int seedSecSingleTx = 1; 		// security for single TX, can be 1-3 -> 1 needs least amout of time
	private static int seedSecMultiTx = 1; 			// security for single TX, can be 1
	private static int searchLength = 3;			// Batch number of indices of the seed, that are to be queried for tokens

	// Path where output files are to be stored. Folder must already exist.
	private static String path = "INSERT_PATH";		// Path on RSU = Raspberry Pi.

	private ReaderWriteFile rwfRSU;
	private IotaAPI api_RSU;
	private ConnectionHelper conHelpRSU;
	private IotaPreload preloadRSU;
	private EncryptionObject encryptionRSU;
	private VehicleDataThread rsuDataThread;
	private ThreadCommunicator tRSU;
	private ThreadCommunicator tVehicle;
	private TrustConfiguration_RSU tcRSU;

	public RsuThread() throws SeedWithoutBalanceError, IOException {

		// Generalize program context
		Locale.setDefault(Locale.US);
		long preloadingStartDate = System.currentTimeMillis();
		boolean powLocal = true;

		// Read Initial Data
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nSetting up the API:");
		this.rwfRSU = new ReaderWriteFile(path, "RSU");
		this.api_RSU = new IotaAPI.Builder().protocol("http").host(this.rwfRSU.getTargetUrlNode()).port(14265).build();

		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nChecking Connections:");
		// Connection Helper checks if 802.11p router and FPGA PoW Accelerator are available via Ethernet
		this.conHelpRSU = new ConnectionHelper(5555, rwfRSU.getRouterUrl(), rwfRSU.getBoostedPowUrl());
		System.out.println(rwfRSU.getName() + " checked router: " + conHelpRSU.isRouterReachable() + " and boosted pow: " + conHelpRSU.isPowReachable());

		if (!conHelpRSU.isRouterReachable()) {
			System.exit(0);
		}
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nStart Preloading:");

		// Preloading is started:
		this.preloadRSU = new IotaPreload(rwfRSU.getName(), api_RSU, powLocal, conHelpRSU.isPowReachable(), rwfRSU.getSeedIndex(), rwfRSU.getSeed(),
				depth, rwfRSU.getMinWeightMagnitude(), seedSecSingleTx, searchLength, seedSecMultiTx);
		this.rwfRSU.setSeedIndex(preloadRSU.getKeyWithBalanceMainSeed());

		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

		// Initialize encryption object with predetermined private and public keys
		this.encryptionRSU = new EncryptionObject(rwfRSU.getMessageRSAKey(), "BUYER");

		// Initialize Random Vehicle Data
		System.out.println("Trying to set up the bluetooth connection with vehicle via OBD2.");
		this.rsuDataThread = new VehicleDataThread(QueryForObd2Data.NO);
		this.rsuDataThread.start();

		// Preload the IOTA and ConnectionHelper Object
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\nChecking Trust SetUp:");
		this.tcRSU = new TrustConfiguration_RSU(preloadRSU.getIotaAPI(), depth, rwfRSU.getMinWeightMagnitude(), rwfRSU.getMessageRSAKey());
		System.out.println("Finsihed setting up the trust configuration.");
		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

		// Start CommunicatorThread
		long preloadingEndDate = System.currentTimeMillis();
		long preloadingTime = (preloadingEndDate - preloadingStartDate);
		this.tRSU = new ThreadCommunicator(encryptionRSU, rwfRSU, conHelpRSU, "RSU", "VEHICLE", IsBuyer.YES, rwfRSU.getOwnRepLink(), rsuDataThread, preloadRSU, OutsourcedPow.YES, seedSecSingleTx, seedSecMultiTx, tcRSU, preloadingTime);

	}

	@Override
	public void run() {

		// Simulation of Messaging Objects done without Router
		System.out.println("Vehicle has: " + this.tVehicle);
		this.tRSU.start();

		// RSU: Wait until Thread is done, then wait for confirmation
		while (!(tRSU.isEndedCycle())) {
			try {Thread.sleep(10000);} catch (InterruptedException e) {}
		}

		System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
		System.out.println("Final bundle confirmed, Overall Cycle ends");
		System.exit(0);
	}

	public ThreadCommunicator gettRSU() {
		return tRSU;
	}

	public void settVehicle(ThreadCommunicator tVehicle) {
		this.tVehicle = tVehicle;
	}

}
