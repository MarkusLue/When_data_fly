package runWithRouter;

import java.io.IOException;

import errors.SeedWithoutBalanceError;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class is the starting point to generate a working jar, 
// that communicates and uses the 802-11p enbaled router.

public class runConfiguration {

	public static void main(String[] args) throws SeedWithoutBalanceError, IOException {

		// Change if real-life application is to be run as RSU or Vehicle.
		boolean runAsRsu = false;

			if (runAsRsu) {
				RsuThread threadRsu = new RsuThread();
				threadRsu.run();
			} else {
				VehicleThread threadVehicle = new VehicleThread();
				threadVehicle.run();
			}
	}

}
