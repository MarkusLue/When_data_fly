package reputationAndIdentity;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;

import org.iota.jota.IotaAPI;
import org.iota.jota.error.ArgumentException;
import org.iota.jota.model.Bundle;
import org.iota.jota.model.Transaction;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.TrytesConverter;
import org.json.JSONObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This object encapsulates the calculation of the attestation value of the
// desired claims, for the inquirer

public class GetAttestationsOfPeer {

	private double[] ratingClaimType;
	
	public GetAttestationsOfPeer(IotaAPI inAPI, String[] ClaimTypes, String targetID, HashMap<String, String> idsTrusted) throws ArgumentException, Exception {

		// Storage for rating
		this.ratingClaimType = new double[ClaimTypes.length];
		for (int j = 0; j < ClaimTypes.length; j++) {
			this.ratingClaimType[j] = 0;
		}
		
		// User querys an IOTA node for all transactions on the Claim and target ID based address
		String[] addresses_2 = getClaimsAddressesArray(targetID, ClaimTypes, true);
		Bundle[] bundleStore = inAPI.bundlesFromAddresses(false, addresses_2);
	
		inAPI = null;
		System.gc();

		@SuppressWarnings("unchecked")
		LinkedList<Transaction>[] arrayClaims = new LinkedList[addresses_2.length];

		// arrayClaims is an Array that owns a LinkedList (with all transactions) for
		// every relevant claim of target Identity

		// In the following transactions (attestations) are sorted out, that are
		// a) not sent by someone who SAYS he/she is a trusted indentity (via the IOTA Tag)
		// b) SAYS he/she is a trusted identity (via tag), but is not (via invalid signature in JSON)
		// c) multiple transactions by the same identity, but no the newst tx (representing an updated attestation)

		// a) Look for Transactions (attestations) with known tags (people saying they are a trusted identity) for each claim
		for (int k = 0; k < bundleStore.length; k++) {
			if (idsTrusted.containsKey(bundleStore[k].getTransactions().get(0).getTag())) {

				String signatureFragments = bundleStore[k].getTransactions().get(0).getSignatureFragments();

				// Correct length of signature fragements (must be even to be parsed to ASCII)
				if (signatureFragments.length() % 2 != 0) {
					signatureFragments += "9";
				}

				String asciiMSG = TrytesConverter.trytesToAscii(signatureFragments);
				JSONObject jParse = new JSONObject(asciiMSG);

				// b) check if signature of people saying they are trustworthy is valid
				if (verifyJSON(jParse)) {
					Transaction temp = bundleStore[k].getTransactions().get(0);

					for (int h = 0; h < addresses_2.length; h++) {
						String tempAddress = Checksum.addChecksum(temp.getAddress());
						if (tempAddress.equals(addresses_2[h])) {
							if (arrayClaims[h] == null) {
								arrayClaims[h] = new LinkedList<Transaction>();
								arrayClaims[h].add(temp);
							} else {

								// Tx was not the first in the list, always check if the tx is by a identity that has already attested
								long currentTimeStamp = temp.getTimestamp();
								String tag = temp.getTag();
								boolean inserted = false;

								for (int f = 0; f < arrayClaims[h].size(); f++) {
									if (arrayClaims[h].get(f).getTag().equals(tag)) {
										// this user already rated
										if (arrayClaims[h].get(f).getTimestamp() < currentTimeStamp) {
											// current tx is newer, substitute.
											arrayClaims[h].remove(f);
											arrayClaims[h].add(temp);
											inserted = true;
										}
									}
								}

								// List was filled but not by this user.
								if (!inserted) {
									arrayClaims[h].add(temp);
								}
							}
						}
					}
				}
			}
		}

		// c) for each Claim -> only count the newest tx (multiple tx by the same person are updated attestations)
		// Additionally calculate the (average) attestation value.

		boolean foundValidAttestations = true;
		for (int g = 0; g < arrayClaims.length; g++) {

			// Check if there are valid (a+b) attestations on this claim
			try {
				arrayClaims[g].size();
			} catch (NullPointerException e) {
				foundValidAttestations = false;
			}

			// Check if there are valid (a+b) attestations on this claim
			if (foundValidAttestations) {
				//System.out.print("Claim " + ClaimTypes[g] + ", has " + arrayClaims[g].size() + " (updated) attestations. ");

				// Start calculation averg. attestation value for each claim
				long ratingOfThisClaim = 0;
				for (int z = 0; z < arrayClaims[g].size(); z++) {

					String signatureFragments = arrayClaims[g].get(z).getSignatureFragments();

					// Correct length of signature fragements (must be even to be parsed to ASCII)
					if (signatureFragments.length() % 2 != 0) {
						signatureFragments += "9";
					}

					String asciiMSG = TrytesConverter.trytesToAscii(signatureFragments);
					JSONObject jParse = new JSONObject(asciiMSG);
					ratingOfThisClaim += Long.parseLong((String) jParse.get("%"));
				}
				double rating = (double) ratingOfThisClaim / (double) arrayClaims[g].size();
				//NumberFormat formatter = new DecimalFormat("#0.0");

				// print (average) attestation value.
				this.ratingClaimType[g] = rating;
			} else {
			}
		}

	}

	private String getClaimAddress(String IdTarget, String Type, boolean checksum) throws NoSuchAlgorithmException {

		// Method that build the claim's address as a function of the identity's ID
		// (public Key) and claim type.
		// Applying the SHA-256 hash algorithm. Hash gets reduced (by loosing
		// information) and turned into IOTA Trytes

		String identifierClaim = IdTarget + Type;
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(identifierClaim.getBytes(StandardCharsets.UTF_8));

		// SHA-256 produces a 256-bit (32 bytes) hash value, this is mapped to trytes
		// (resulting in an 88 char String)
		String IotaAddress = TrytesConverter.asciiToTrytes(Base64.getEncoder().encodeToString(hash));

		// By loosing information or adding information, the Tryte representation of the
		// hash is brought to a 81 char String (Iota address format)

		if (IotaAddress.length() > 81) {
			IotaAddress = IotaAddress.substring(0, 81);
		} else {
			int missingChars = 81 - IotaAddress.length();
			for (int i = 0; i < missingChars; i++) {
				IotaAddress = IotaAddress + "A";
			}
		}

		// The checksum of the address gets added, if requested (input)
		if (checksum) {
			return Checksum.addChecksum(IotaAddress);
		} else {
			return IotaAddress;
		}
	}

	private String[] getClaimsAddressesArray(String ID, String[] claimTypes, boolean checksum) throws NoSuchAlgorithmException {

		// Method returns a String Array of Claim addresses, if more than one claim is
		// to be attested
		String[] returner = new String[claimTypes.length];
		for (int i = 0; i < claimTypes.length; i++) {
			returner[i] = getClaimAddress(ID, claimTypes[i], checksum);
		}
		return returner;
	}

	public boolean verify(String plainText, String signature, PublicKey publicKey) throws Exception {

		// Method returns the (bool) analysis result of the 512-RSA signature
		// verification.
		// Inputs plainText, signature and publicKey.

		Signature publicSignature = Signature.getInstance("SHA256withRSA");
		publicSignature.initVerify(publicKey);
		publicSignature.update(plainText.getBytes(StandardCharsets.UTF_8));

		byte[] signatureBytes = Base64.getDecoder().decode(signature);

		return publicSignature.verify(signatureBytes);
	}

	public boolean verifyJSON(JSONObject jIn) throws Exception {

		// Method returns the (bool) analysis result of the 512-RSA signature
		// verification.
		// The necessary information to call public boolean verify(String plainText,
		// String signature, PublicKey publicKey)
		// is packed into an JSON (handed as input)

		String sign = jIn.getString("sig");
		String id = jIn.getString("ID");
		jIn.remove("sig");

		KeyFactory keyfactory = KeyFactory.getInstance("RSA");
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(id));
		PublicKey pubKey = keyfactory.generatePublic(keySpec);

		return verify(jIn.toString(), sign, pubKey);
	}

	public double[] getRatingClaimType() {
		return ratingClaimType;
	}
	
}
