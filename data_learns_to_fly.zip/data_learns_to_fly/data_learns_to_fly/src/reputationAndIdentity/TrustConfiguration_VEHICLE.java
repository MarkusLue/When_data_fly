package reputationAndIdentity;

import org.iota.jota.IotaAPI;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

public class TrustConfiguration_VEHICLE extends TrustConfiguration {

	// This file is the Vehicle's initial trust configuration
	// The file contains information about the Vehicle's trusted Identities (public
	// RSA 512 keys)
	// The constructor checks if sufficient rating data is available in the tangle
	// if they are broadcasted by replayBundle()

	private String userDummy1_PrivKey = "INSERT_KEY_1";
	private String userDummy3_PrivKey = "INSERT_KEY_3";

	public TrustConfiguration_VEHICLE(IotaAPI inApi, int inDepth, int inMwm, String inOwnPrivateKey) {
		super(inApi, inDepth, inMwm, inOwnPrivateKey);

		// For the Vehicle claims that rate a rates are relevant
		String[] relevantClaims = { "FZI_VEH-rates-RSU_A", "FZI_VEH-rates-RSU_B" };
		super.setRelevantClaims(relevantClaims);

		// Get Public Keys from Private Keys
		addTrustedPrivateKeyString(this.ownPrivateKey);
		addTrustedPrivateKeyString(userDummy1_PrivKey);
		addTrustedPrivateKeyString(userDummy3_PrivKey);

		// Replay valid signed trust data about one-self, if data is cut by local node
		// snapshot
		this.replayBundle();
	}

	public void replayBundle() {

		// Due to the node's local snapshot feature, the zero-value tx that contain
		// the trust data might get lost. This method checks that and in case replays
		// old but validly signed data about the user (Vehicle's in this case).

		// Predefined ratings for this user, all one bundle tx.
		String address1 = "INSERT_ADD_1";
		String address2 = "INSERT_ADD_2";
		String address3 = "INSERT_ADD_3";
		String address4 = "INSERT_ADD_4";

		int txOnAddressSaver_RsuIdent = super.api.findTransactionObjectsByAddresses(new String[] {address1}).size();
		int txOnAddressSaver_RsuClaim = super.api.findTransactionObjectsByAddresses(new String[] {address2}).size();
		int txOnAddressSaver_VehIdent = super.api.findTransactionObjectsByAddresses(new String[] {address3}).size();
		int txOnAddressSaver_VehClaim = super.api.findTransactionObjectsByAddresses(new String[] {address4}).size();

		System.out.println("Found " + txOnAddressSaver_RsuIdent + " tx for RsuIdent (" + address1 + ").");
		System.out.println("Found " + txOnAddressSaver_RsuClaim + " tx for RsuClaim (" + address2 + ").");
		System.out.println("Found " + txOnAddressSaver_VehIdent + " tx for VehIdent (" + address3 + ").");
		System.out.println("Found " + txOnAddressSaver_VehClaim + " tx for VehClaim (" + address4 + ").");

		int txOnTargetAddresses = txOnAddressSaver_RsuIdent + txOnAddressSaver_RsuClaim + txOnAddressSaver_VehIdent + txOnAddressSaver_VehClaim;
		
		if (txOnTargetAddresses < 70) {
			System.out.println("Reputation Tx rebroadcasted...");
			
			// Implementation to rebroadcast attestations removed for publication.
			
		} else {
			System.out.println(txOnTargetAddresses + " Reputation Tx were found.");
		}
	}
}
