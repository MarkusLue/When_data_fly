package reputationAndIdentity;

import org.iota.jota.IotaAPI;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

public class TrustConfiguration_RSU extends TrustConfiguration{

	// This file is the RSU's initial trust configuration
	// The file contains information about the RSU's trusted Identities (public RSA 512 keys)
	// The constructor checks if sufficient rating data is available in the tangle
	// if they are broadcasted by replayBundle()
	
	public TrustConfiguration_RSU(IotaAPI inApi, int inDepth, int inMwm, String inOwnPrivateKey) {
		super(inApi, inDepth, inMwm, inOwnPrivateKey);
		
		// For the RSU claims that rate a vehicle are relevant
		String[] relevantClaims = {"FZI_RSU-rates-Veh_A", "FZI_RSU-rates-Veh_B"};
		super.setRelevantClaims(relevantClaims);
		
		// Hard Coded Default
		String userDummy1_PrivKey = "INSERT_KEY_1";
		String userDummy2_PrivKey = "INSERT_KEY_2";

		// Get Public Keys from Private Keys
		addTrustedPrivateKeyString(this.ownPrivateKey);
		addTrustedPrivateKeyString(userDummy1_PrivKey);
		addTrustedPrivateKeyString(userDummy2_PrivKey);
		
	}
}
