package reputationAndIdentity;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedList;

import javax.xml.bind.DatatypeConverter;

import org.iota.jota.IotaAPI;
import org.iota.jota.pow.pearldiver.PearlDiverLocalPoW;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.TrytesConverter;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Parent class of TrustConfiguration_RSU and TrustConfiguration_VEHICLE
// Class defines share characteristics of each personals trust configuration

public class TrustConfiguration {

	protected String ownPrivateKey;
	private LinkedList<String> trustedPrivateKeys;
	private LinkedList<String> trustedPublicKeys;
	private HashMap<String, String> user_trusts;
	private String[] relevantClaims;
	protected int depth;
	protected int mwm;
	IotaAPI api;

	// Constructor
	public TrustConfiguration(IotaAPI inApi, int inDepth, int inMwm, String inOwnPrivateKey) {

		this.ownPrivateKey = inOwnPrivateKey;
		this.trustedPrivateKeys = new LinkedList<String>();
		this.trustedPublicKeys = new LinkedList<String>();
		this.user_trusts = new HashMap<String, String>();
		this.api = inApi;
		this.depth = inDepth;
		this.mwm = inMwm;

	}

	public void setRelevantClaims(String[] inClaims){
		this.relevantClaims = inClaims;
	}
	
	public void replayBundle() {

	}

	// Function that handles attestiong the claims of a target.
	public void giveAttestation(String targetID, long[] rating) {

		// PoW is done locally, might be changed
		this.api.setLocalPoW(new PearlDiverLocalPoW());
		try {
			new GiveAttestation(this.api, relevantClaims, targetID, this.trustedPublicKeys.get(0), rating,
					getKeyPairByPrivate(this.ownPrivateKey).getPrivate());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Function that handles getting the Attestations of the claims of a target.
	public double[] getPeersAttestation(String inPublicKeyTarget) {

		// Returns the Rating Array of the inPublicKeyTarget
		try {
			return new GetAttestationsOfPeer(this.api, this.relevantClaims, inPublicKeyTarget, this.user_trusts).getRatingClaimType();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// Function that handles adds an public key to the list of trusted public keys.
	public void addTrustedPublicKey(String inPublicKeyString) {
		this.trustedPublicKeys.add(inPublicKeyString);
		try {
			this.user_trusts.put(this.getTagForUser(inPublicKeyString), inPublicKeyString);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	// Function that handles adds to add an private key to the list of trusted public keys.
	// This function is needed internally, private keys are usually not added to the list of trusted identities.
	protected void addTrustedPrivateKeyString(String inKeyString) {
		this.trustedPrivateKeys.add(inKeyString);
		KeyPair tempKey;
		try {
			tempKey = getKeyPairByPrivate(inKeyString);
			this.addTrustedPublicKey(new String(Base64.getEncoder().encode(tempKey.getPublic().getEncoded())));
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	// Methods constructs and return 512-RSA Key Pair form String representation of
	// 512-RSA Private Keys
	protected static KeyPair getKeyPairByPrivate(String inPrivateKey) throws InvalidKeySpecException, NoSuchAlgorithmException {

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(inPrivateKey));
		PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

		RSAPrivateCrtKey privateKeyRSA = (RSAPrivateCrtKey) privateKey;
		RSAPublicKeySpec publicKeySpec = new java.security.spec.RSAPublicKeySpec(privateKeyRSA.getModulus(), privateKeyRSA.getPublicExponent());
		PublicKey pubKey = keyFactory.generatePublic(publicKeySpec);

		return new KeyPair(pubKey, privateKey);
	}

	// Method maps the UserID (RSA 512 public key) to a 27 char Trytes
	// representation (IOTA Tag format)
	private String getTagForUser(String publicKey) throws NoSuchAlgorithmException {

		// To do so, the RSA 512 public key gets hashed by MD5
		MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		messageDigest.update(publicKey.getBytes());
		byte[] digest = messageDigest.digest();

		// The MD5 hash is converted to Trytes (A-Z and 9, IOTA Tag format)
		String hash = DatatypeConverter.printHexBinary(digest).toUpperCase();
		String tag = TrytesConverter.asciiToTrytes(hash);

		// Map to 27 length string, by loosing information
		int interval = Math.floorDiv(tag.length(), 27) + 1;

		StringBuffer stringBuffer = new StringBuffer();

		// Use every interval String
		int runner = 0;
		while ((runner * interval) < tag.length()) {
			stringBuffer.append(tag.charAt(runner * interval));
			runner += 1;
		}

		// Fill up to 27 with 999
		int fillUpNeed = (27 - stringBuffer.toString().length());
		for (int j = 0; j < fillUpNeed; j++) {
			stringBuffer.append("9");
		}

		return stringBuffer.toString();
	}

	protected String getClaimAddress(String IdTarget, String Type, boolean checksum) throws NoSuchAlgorithmException {

		// Method that build the claim's address as a function of the identity's ID
		// (public Key) and claim type.
		// Applying the SHA-256 hash algorithm. Hash gets reduced (by loosing
		// information) and turned into IOTA Trytes
		
		String identifierClaim = IdTarget + Type;
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(identifierClaim.getBytes(StandardCharsets.UTF_8));

		// SHA-256 produces a 256-bit (32 bytes) hash value, this is mapped to trytes
		// (resulting in an 88 char String)
		String IotaAddress = TrytesConverter.asciiToTrytes(Base64.getEncoder().encodeToString(hash));

		// By loosing information or adding information, the Tryte representation of the
		// hash is brought to a 81 char String (Iota address format)

		if (IotaAddress.length() > 81) {
			IotaAddress = IotaAddress.substring(0, 81);
		} else {
			int missingChars = 81 - IotaAddress.length();
			for (int i = 0; i < missingChars; i++) {
				IotaAddress = IotaAddress + "A";
			}
		}

		// The checksum of the address gets added, if requested (input)
		if (checksum) {
			return Checksum.addChecksum(IotaAddress);
		} else {
			return IotaAddress;
		}
	}
}
