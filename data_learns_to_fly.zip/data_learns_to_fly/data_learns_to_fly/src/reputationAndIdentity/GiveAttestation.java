package reputationAndIdentity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Base64;

import javax.xml.bind.DatatypeConverter;

import org.iota.jota.IotaAPI;
import org.iota.jota.error.ArgumentException;
import org.iota.jota.model.Transfer;
import org.iota.jota.utils.Checksum;
import org.iota.jota.utils.SeedRandomGenerator;
import org.iota.jota.utils.TrytesConverter;
import org.json.JSONException;
import org.json.JSONObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Object that encapsulates how attestations are give.

public class GiveAttestation {
	

	// MWM defining the difficulty of the PoW. 14 for confirmations on the MainNet.
	// Since attestations do not need to be confirmed, less might be applicable?
	public final int MWM = 11;
	
	public GiveAttestation(IotaAPI inAPI, String[] ClaimTypes, String targetID, String ownID, long[] inAttestations, PrivateKey ownPrivateKey)
			throws JSONException, Exception {

		// Generate new random seed (irrelevant to the application, but needed by IOTA
		// Java Node Wrapper).
		String seed = SeedRandomGenerator.generateNewSeed();

		// Calculate (hash) the Addresses that belong to the individual claim of the
		// target ID
		String[] addresses = getClaimsAddressesArray(targetID, ClaimTypes, true);

		// Pack ID of the attestant, and his/her attestation rating into a JSON
		for (int o = 0; o < ClaimTypes.length; o++) {
			JSONObject jsonRateTarget = new JSONObject();
			jsonRateTarget.put("ID", ownID);
			jsonRateTarget.put("%", "" + inAttestations[o]);

			// Add the siagnture of the attestant to the JSON
			jsonRateTarget.put("sig", sign(jsonRateTarget.toString(), ownPrivateKey));

			// Send attestation transaction to all claims, that are attested
			System.out.println(jsonRateTarget.toString());
			sendTx(inAPI, seed, jsonRateTarget.toString(), addresses[o], getTagForUser(ownID));
			//System.out.println("User sent message to address: " + addresses[o]);
		}

	}

	private void sendTx(IotaAPI api1, String seed, String inMessage, String inAddress, String tag) {

		// Method that packs the attestation JSON into the IOTA zero value Transfer
		// format,
		// performs PoW and broadcasts the attestation to the defined claim address

		Transfer zeroValueTransaction = new Transfer(inAddress, 0, TrytesConverter.asciiToTrytes(inMessage), tag);
		ArrayList<Transfer> transfers = new ArrayList<Transfer>();
		transfers.add(zeroValueTransaction);
		try {
			api1.sendTransfer(seed, 1, 3, MWM, transfers, null, null, false, false, null);
		} catch (ArgumentException e) {
			e.printStackTrace();
		}
	}

	private String sign(String plainText, PrivateKey privateKey) throws Exception {

		// Method that returns the signature of a handed text (input), applying a
		// private key (input)

		Signature privateSignature = Signature.getInstance("SHA256withRSA");
		privateSignature.initSign(privateKey);
		privateSignature.update(plainText.getBytes(StandardCharsets.UTF_8));
		byte[] signature = privateSignature.sign();

		return Base64.getEncoder().encodeToString(signature);
	}

	private String getClaimAddress(String IdTarget, String Type, boolean checksum) throws NoSuchAlgorithmException {

		// Method that build the claim's address as a function of the identity's ID
		// (public Key) and claim type.
		// Applying the SHA-256 hash algorithm. Hash gets reduced (by loosing
		// information) and turned into IOTA Trytes

		String identifierClaim = IdTarget + Type;
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(identifierClaim.getBytes(StandardCharsets.UTF_8));

		// SHA-256 produces a 256-bit (32 bytes) hash value, this is mapped to trytes
		// (resulting in an 88 char String)
		String IotaAddress = TrytesConverter.asciiToTrytes(Base64.getEncoder().encodeToString(hash));

		// By loosing information or adding information, the Tryte representation of the
		// hash is brought to a 81 char String (Iota address format)
		
		if (IotaAddress.length() > 81) {
			IotaAddress = IotaAddress.substring(0, 81);
		} else {
			int missingChars = 81 - IotaAddress.length();
			for (int i = 0; i < missingChars; i++) {
				IotaAddress = IotaAddress + "A";
			}
		}

		// The checksum of the address gets added, if requested (input)
		if (checksum) {
			return Checksum.addChecksum(IotaAddress);
		} else {
			return IotaAddress;
		}
	}

	
	private String[] getClaimsAddressesArray(String ID, String[] claimTypes, boolean checksum) throws NoSuchAlgorithmException {

		// Method returns a String Array of Claim addresses, if more than one claim is to be attested
		String[] returner = new String[claimTypes.length];
		for (int i = 0; i < claimTypes.length; i++) {
			returner[i] = getClaimAddress(ID, claimTypes[i], checksum);
		}
		return returner;
	}

	private String getTagForUser(String pubKey) throws NoSuchAlgorithmException {

		// Method maps the UserID (RSA 512 public key) to a 27 char Trytes representation (IOTA Tag format)
		
		// To do so, the RSA 512 public key gets hashed by MD5
		MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		messageDigest.update(pubKey.getBytes());
		byte[] digest = messageDigest.digest();

		// The MD5 hash gets converted to Trytes (A-Z and 9, IOTA Tag format)
		String hash = DatatypeConverter.printHexBinary(digest).toUpperCase();
		String tag = TrytesConverter.asciiToTrytes(hash);

		// Map to 27 length string, by loosing information
		int interval = Math.floorDiv(tag.length(), 27) + 1;

		StringBuffer stringBuffer = new StringBuffer();

		// Use every interval String
		int runner = 0;
		while ((runner * interval) < tag.length()) {
			stringBuffer.append(tag.charAt(runner * interval));
			runner += 1;
		}

		// Fill up to 27 with 999
		int fillUpNeed = (27 - stringBuffer.toString().length());
		for (int j = 0; j < fillUpNeed; j++) {
			stringBuffer.append("9");
		}

		return stringBuffer.toString();
	}
}
