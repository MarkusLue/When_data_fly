package vehicleData;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Class enables FuelLevelInput Objects

public class FuelLevelInput extends VehicleDataObject{

	public FuelLevelInput(double inLowerLimit, double inUpperLimit, String inPID, boolean inInteger, int inPrecision, String inUnit, String inName, long inPriceLow, long inPriceHigh) {
		super(inLowerLimit, inUpperLimit, inPID, inInteger, inPrecision, inUnit, inName, inPriceLow, inPriceHigh);
	}

	public void calcValueByHex(String inHex) {
		String hex = this.getValueHex();
		hex = hex.replace(" ", "");
		int decimal = Integer.parseInt(hex, 16);
		this.setHexToDouble("" + ((decimal - Math.abs(this.getLowerLimit())) * (100.0/255.0)));
	}
	
}
