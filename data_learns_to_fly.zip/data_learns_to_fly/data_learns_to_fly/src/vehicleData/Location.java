package vehicleData;
import java.text.DecimalFormat;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class enables the (custom not OBD-2 PID) location objects.
// in randomization mode: this object will provide a random location 
// within a virtual rectangle around Karlsruhe, Germany 

public class Location extends VehicleDataObject{

	private double latitude, longitude, leftUpperCornerLatitude, leftUpperCornerLongitude, rightLowerCornerLatitude, rightLowerCornerLongitude;
	private String name, PID, unit;
	
	public Location(String inPID, String inName, long inPriceLow, long inPriceHigh){
		super(inPID,inName, inPriceLow, inPriceHigh);
		this.name = inName;
		this.PID = inPID;
		this.unit = "";
				
		// corner coordinates of the rectangle over Karlsruhe
		this.leftUpperCornerLatitude = 49.038262;
		this.leftUpperCornerLongitude = 8.367290;
		this.rightLowerCornerLatitude = 48.995537;
		this.rightLowerCornerLongitude = 8.449860;
		
		this.latitude = 49.0068901;
		this.longitude = 8.4036527;
		
	}
	
	@SuppressWarnings("unused")
	public void calcValueByHex(String inHex) {
		// Location is not part of PID OBD-2 definition.
		// To comply with parental class, this method is still implemented.
		
		String hex = this.getValueHex();
		hex = hex.replace(" ", "");
		int decimal = Integer.parseInt(hex, 16);
		this.setHexToDouble(this.getValueString());
		
	}
	
	// returns location as formatted string
	public String getValueString() {
		
		//Format Double for String  with 6 Fraction Digits
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(6);
		String returner = df.format(this.getLatitude()) + ", " + df.format(this.getLongitude());
		
		return returner;
	}
	
	// Method randomizes location and returns location as formatted string
	public String getNewRandomString() {

		//Get new values for lat. and long. and then the accordingly defined String
		this.getNewLatitude();
		this.getNewLongitude();
		
		return this.getValueString();
	}

	// Getters and Setters:
	
	public double getLatitude() {
		this.getNewLatitude();
		return this.latitude;
	}
	
	public double getLongitude() {
		this.getNewLongitude();
		return this.longitude;
	}
	
	
	private double getNewLatitude() {
		
		double workingRange = this.leftUpperCornerLatitude - this.rightLowerCornerLatitude;
		this.latitude = this.rightLowerCornerLatitude + Math.random() * workingRange;	
		return this.latitude;
	}

	private double getNewLongitude() {
		
		double workingRange = this.leftUpperCornerLongitude - this.rightLowerCornerLongitude;
		this.longitude = this.rightLowerCornerLongitude + Math.random() * workingRange;
		return this.longitude;
	}

	public String getName() {
		return name;
	}

	public String getPID() {
		return PID;
	}
	
	public String getUnit() {
		return unit;
	}
	
}
