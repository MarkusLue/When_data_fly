package vehicleData;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// this class describes the OBD-2 Vehicle Data Objects, it is their parental class

public class VehicleDataObject {

	private double lowerLimit, upperLimit, randomValue;
	private String name, PID, unit, randomString, valueHex, hexToDouble, formattedString;
	private boolean isInteger;
	private int precision;
	private long price, priceLowBound, priceHighBound;


	public VehicleDataObject(String inPID, String inName, long inPriceLow, long inPriceHigh) {
		this.PID = inPID;
		this.name = inName;
		this.priceLowBound = inPriceLow;
		this.priceHighBound = inPriceHigh;
	}

	public VehicleDataObject(double inLowerLimit, double inUpperLimit, String inPID, boolean inInteger, int inPrecision, String inUnit, String inName,
			long inLowBound, long inHighBound) {
		this.lowerLimit = inLowerLimit;
		this.upperLimit = inUpperLimit;
		this.isInteger = inInteger;
		this.precision = inPrecision;
		this.unit = inUnit;
		this.name = inName;
		this.PID = inPID;
		this.priceLowBound = inLowBound;
		this.priceHighBound = inHighBound;

		this.price = (long) Math.floor((this.priceLowBound + (this.priceHighBound - this.priceLowBound) / 2));

	}

	public void randomizePriceBounds(double inLow, double inHigh, double inDeviation, int inScale) {

		// Method Generates a Random set of boundaries based on a Gaussian distribution, with
		// mean and standard deviation
		
		Random randomValue = new Random();
		BigDecimal lowBoundDec = new BigDecimal(randomValue.nextGaussian() * inDeviation + inLow);
		BigDecimal highBoundDec = new BigDecimal(randomValue.nextGaussian() * inDeviation + inHigh);

		this.priceLowBound = (long) lowBoundDec.setScale(inScale, BigDecimal.ROUND_HALF_DOWN).doubleValue();
		this.priceHighBound = (long) highBoundDec.setScale(inScale, BigDecimal.ROUND_HALF_DOWN).doubleValue();

		if (this.priceLowBound <= 0) {
			this.priceLowBound = 1;
		}

		this.price = (long) Math.floor((this.priceLowBound + (this.priceHighBound - this.priceLowBound) / 2));
	}


	// Getters and Setters
	public String getPID() {
		return this.PID;
	}

	public String getName() {
		return this.name;
	}

	public double getPriceLowBound() {
		return priceLowBound;
	}

	public double getPriceHighBound() {
		return priceHighBound;
	}

	public long getPrice() {
		return price;
	}

	public String getUnit() {
		return unit;
	}

	public String getValueHex() {
		return valueHex;
	}

	public double getLowerLimit() {
		return lowerLimit;
	}

	public String getHexToDouble() {
		return hexToDouble;
	}

	public void setHexToDouble(String hexToDouble) {
		this.hexToDouble = hexToDouble;
	}

	public String getFormattedString() {
		if (this.unit == null) {
			this.unit = "";
		}		
		String pattern = "#####.##";
		DecimalFormat decimalFormat = new DecimalFormat(pattern);
		
		if (!this.hexToDouble.equals("no data")) {
			this.formattedString = this.PID + " (" + this.getName() + "): " + decimalFormat.format(Double.parseDouble(this.getHexToDouble())) + this.getUnit();
		} else {
			this.formattedString = this.PID + " (" + this.getName() + "): " + this.getHexToDouble();
		}
		
		return formattedString;
	}

	public double getValue() {
		return this.randomValue;
	}

	public String getValueString() {
		return this.randomString;
	}

	public double getNewRandomValue() {

		double randomNum = ThreadLocalRandom.current().nextDouble(this.lowerLimit, this.upperLimit + 1);
		int temp = (int) randomNum;

		this.randomValue = (double) temp;
		return (double) temp;
	}
	
	public void setPrice(long price) {
		this.price = price;
	}

	public String getNewRandomString() {
		this.getNewRandomValue();
		DecimalFormat decimalFormat = new DecimalFormat();

		// if Integer, set Maximum Fraction Digits to 0, else to "precision"
		if (this.isInteger) {
			decimalFormat.setMaximumFractionDigits(0);
		} else {
			decimalFormat.setMaximumFractionDigits(this.precision);
		}
		
		// clear this.unit
		if (this.unit == null) {
			this.unit = "";
		}

		this.randomString = decimalFormat.format(this.randomValue);
		return decimalFormat.format(this.randomValue) + this.unit;
	}

}
