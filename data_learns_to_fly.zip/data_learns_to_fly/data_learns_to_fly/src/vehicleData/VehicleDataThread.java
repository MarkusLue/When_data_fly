package vehicleData;

import java.io.IOException;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class describes the VehicleDataThread, that tries to read vehicle data from the OBD-2 adapter
// If no data can be read, the random values of the OBD-2 are not overwritten

public class VehicleDataThread extends Thread {

	public VehicleData vehData;
	public String connectionURL;
	public boolean runner;
	public boolean canReadFromCar;
	private boolean initializationOver;
	private static int readInterval = 15000; // e.g. every 5 seconds new data is received.
	private double firstTime;
	private double secondTime;

	// Constructor, that checks if the OBD-2 Adapter can be accessed.
	public VehicleDataThread(boolean inIsRSU) throws IOException {
		
		vehData = new VehicleData();
		this.connectionURL = "";
		this.runner = true;
		this.vehData = new VehicleData();
		this.canReadFromCar = false;
		this.firstTime = System.currentTimeMillis() - readInterval;
		this.secondTime = firstTime;
		
		// no fitting URL (meaning OBD-2 bluetooth adapter) found: use random data
		System.out.println("Could not connect to OBD2 via bluetooth, using random data.");
		this.canReadFromCar = false;
		this.initializationOver = true;
	}
	
	
	public void run() {

		// if the device can't read from the car, new random values are generated.
		while (!canReadFromCar) {
			this.secondTime = System.currentTimeMillis();
			if ((this.secondTime - this.firstTime) < (readInterval / 5)) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} else {
				try {
					this.firstTime = this.secondTime;
					int size = this.vehData.getStorageObdObjects().size();
					for (int i = 0; i < size; i++) {
						this.vehData.getStorageObdObjects().get(i).getNewRandomString();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	
	}

	// Getters and Setters:	
	public boolean isInitializationOver() {
		return initializationOver;
	}

	public VehicleData getVehData() {
		return vehData;
	}

}
