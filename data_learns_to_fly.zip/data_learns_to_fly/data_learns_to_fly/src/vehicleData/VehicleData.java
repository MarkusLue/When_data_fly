package vehicleData;

import java.util.HashMap;
import java.util.LinkedList;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

public class VehicleData {

	public EngineCoolantTemperature engiCoolTemp;
	public FuelPressure fuelPres;
	public EngineRPM engiRPM;
	public VehicleSpeed vehiSpee;
	public IntakeAirTemperature intaAirTemp;
	public ThrottlePosition throPosi;
	public RunTimeSinceEngineStart timeSinEnSta;
	public EthanolFuelPercentage ethaFuelPerc;
	public FuelType fueltype;
	public FuelLevelInput fuelLevel;
	public LinkedList<VehicleDataObject> storageObdObjects;
	public LinkedList<VehicleDataObject> sortedStorageObdObjects;
	public Location locaVehi;
	public HashMap<String, VehicleDataObject> storageOBDbyPID;

	public VehicleData() {

		// The price estimations are build generating a random (deviation) price (within predetermined boundaries)
		long inPriceLow = 25;
		long inPriceHigh = 45;
		long deviation = 8;
		
		// Initalize Objects, derived from OBD2, with random value-generation
		// If numbers can be read from Vehicle, the random values get overwritten.
		this.engiCoolTemp = new EngineCoolantTemperature(-40, 215, "05", false, 2, "°C", "EngineCoolantTemperature", inPriceLow, inPriceHigh);
		this.fuelPres = new FuelPressure(0,765,"0A",false, 2, "kPa", "FuelPressure", inPriceLow, inPriceHigh);
		this.engiRPM = new EngineRPM(0, 16383.75, "0C", false, 2, "rpm", "EngineRPM", inPriceLow, inPriceHigh);
		this.vehiSpee = new VehicleSpeed(0, 255, "0D", false, 2, "km/h", "VehicleSpeed", inPriceLow, inPriceHigh);
		this.intaAirTemp = new IntakeAirTemperature(-40, 215, "0F", false, 2, "°C", "IntakeAirTemperature", inPriceLow, inPriceHigh);
		this.throPosi = new ThrottlePosition(0,100, "11", false, 2, "%", "ThrottlePosition", inPriceLow, inPriceHigh);
		this.timeSinEnSta = new RunTimeSinceEngineStart(0, 65535, "1F", true, 0, "s", "RunTimeSinceEngineStart", inPriceLow, inPriceHigh);
		this.ethaFuelPerc = new EthanolFuelPercentage(0, 100, "52", false, 2, "%", "EthanolFuelPercentage", inPriceLow, inPriceHigh);
		this.fuelLevel = new FuelLevelInput(0, 100, "2F", false, 2, "%", "FuelLevelInput", inPriceLow, inPriceHigh);
		this.fueltype = new FuelType("51", "FuelType", inPriceLow, inPriceHigh);
		this.locaVehi = new Location("LO", "Location", inPriceLow, inPriceHigh);
		
		// Add object to a List and Hashmap to make accessing the objetcs easier.
		this.storageOBDbyPID = new  HashMap<String, VehicleDataObject>();
		this.storageObdObjects = new LinkedList<VehicleDataObject>();
		
		this.storageObdObjects.add(vehiSpee);
		this.storageObdObjects.add(fuelLevel);
		this.storageObdObjects.add(engiCoolTemp);
		this.storageObdObjects.add(engiRPM);
		this.storageObdObjects.add(ethaFuelPerc);
		this.storageObdObjects.add(fuelPres);
		this.storageObdObjects.add(intaAirTemp);
		this.storageObdObjects.add(timeSinEnSta);
		this.storageObdObjects.add(vehiSpee);
		this.storageObdObjects.add(throPosi);
		this.storageObdObjects.add(fueltype);
		this.storageObdObjects.add(locaVehi);
		
		// Randomize Price Boundaries and put OBD2 Objects to HashMap, easier to find object by PID
		for (int i = 0; i < this.storageObdObjects.size(); i++) {
			this.storageObdObjects.get(i).randomizePriceBounds(inPriceLow, inPriceHigh, deviation, 0);
			this.storageOBDbyPID.put(this.storageObdObjects.get(i).getPID().toString(), this.storageObdObjects.get(i));
		}	
	}
	
	// Getters and Setters:
	public LinkedList<VehicleDataObject> getStorageObdObjects() {
		return storageObdObjects;
	}

	public HashMap<String, VehicleDataObject> getStorageOBDbyPID() {
		return storageOBDbyPID;
	}	
	
}
