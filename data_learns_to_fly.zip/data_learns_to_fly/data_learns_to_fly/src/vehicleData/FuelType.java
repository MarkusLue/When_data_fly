package vehicleData;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Class enables FuelType Objects

public class FuelType extends VehicleDataObject{

	private String fuelValueString, PID, unit, name;
	private double fuelValueInt;

	public FuelType(String inPID, String inName, long inPriceLow, long inPriceHigh) {
		super(inPID, inName, inPriceLow, inPriceHigh);
		this.name = inName;
		this.PID = inPID;
		this.unit = "";
	}
	
	// this method returns the String value of the fuel type, if a hex-representation of the fuel-type is presented
	public void calcValueByHex(String inHex) {
		String hex = this.getValueHex();
		hex = hex.replace(" ", "");
		int decimal = Integer.parseInt(hex, 16);
		
		String[] fuelTypeText = { "Not available", "Gasoline", "Methanol", "Ethanol", "Diesel", "LPG", "CNG", "Propane",
				"Electric", "Bifuel running Gasoline", "Bifuel running Methanol", "Bifuel running Ethanol",
				"Bifuel running LPG", "Bifuel running CNG", "Bifuel running Propane", "Bifuel running Electricity",
				"Bifuel running electric and combustion engine", "Hybrid gasoline", "Hybrid Ethanol", "Hybrid Diesel",
				"Hybrid Electric", "Hybrid running electric and combustion engine", "Hybrid Regenerative",
				"Bifuel running diesel" };
		
		this.setHexToDouble(fuelTypeText[decimal]);
		
	}
	
	// Setters and Getters:

	public double getValue() {
		return this.fuelValueInt;
	}

	public String getValueString() {
		return this.fuelValueString;
	}

	public String getName() {
		return this.name;
	}

	public String getPID() {
		return this.PID;
	}
	
	public String getUnit() {
		return unit;
	}

}
