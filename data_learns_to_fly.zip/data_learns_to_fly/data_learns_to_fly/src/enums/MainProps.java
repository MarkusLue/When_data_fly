package enums;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class specifies enums that are used within the code.

public final class MainProps {

	public MainProps() {}

	public enum OutsourcedPow {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum IsBuyer {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum IsSensitive {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum ContinueService {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum ReattachOrPromotion {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum LocalPoW {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum BoostedPoW {
		;
		public static final boolean YES = true;
		public static final boolean NO = false;
	}
	
	public enum QueryForObd2Data {
		;
		public static final boolean YES = false;
		public static final boolean NO = true;
	}

}
