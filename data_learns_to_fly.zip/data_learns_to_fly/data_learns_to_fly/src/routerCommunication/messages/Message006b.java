package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The scope of the message pair 006a/b is for the buyer to offer a deal for one
// PID with Price
// the offer includes the changed state, signed by the buyer.
// The message can also be a response by the seller. The seller either accepts
// the deal (replys with his 2ndly signed state)
// or offers a change to the deal.


public class Message006b extends RouterParentMessage {

	private boolean selfContinueService, partnerContinuesService, selfConsidersStateValid, partnerConsidersStateValid, sellerAcceptsProposal;
	private long sellerCountersPIPPrice, amountOfTxSignParts;
	private String sellerCountersPIDNumber, soldData;
	private String[] txSignParts;
	private JSONObject Payload006;
	private MessageHelper messageHelp;

	// Constructor for the seller, answering the buyers proposal
	public Message006b(EncryptionObject ownEncryptionObject, int inTypeNumber,
			boolean inIsSensitive, boolean inSelfContinueService, boolean inSelfConsidersStateValid, boolean inSellerAcceptsProposal,
			String inSellerCountersPIDNumber, long inSellerCountersPIPPrice, String[] inTxSignParts, String inSoldData) {
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);

		// super constructor and further variables, that are characteristic for 006b
		this.selfContinueService = inSelfContinueService;
		this.selfConsidersStateValid = inSelfConsidersStateValid;
		this.sellerAcceptsProposal = inSellerAcceptsProposal;
		this.sellerCountersPIDNumber = inSellerCountersPIDNumber;
		this.sellerCountersPIPPrice = inSellerCountersPIPPrice;
		this.txSignParts = inTxSignParts;
		this.amountOfTxSignParts = this.txSignParts.length;
		this.soldData = inSoldData;
		this.messageHelp = new MessageHelper();

		// set payload and add payload to object
		this.Payload006 = new JSONObject();
		this.Payload006.put("SelfContinueService", this.selfContinueService);
		this.Payload006.put("SelfConsidersStateValid",this.selfConsidersStateValid);
		this.Payload006.put("SellerAcceptsProposal",this.sellerAcceptsProposal);
		this.Payload006.put("SellerCountersPIDNumber",this.sellerCountersPIDNumber);
		this.Payload006.put("SellerCountersPIPPrice",this.sellerCountersPIPPrice);
		this.Payload006.put("Data",this.soldData);

		// Save an indicator and the trytes content to payload object		
		String[] shorterTrytes = this.messageHelp.shortenTrytesWith9ers(this.txSignParts);

		// Return
		this.Payload006.put("AmountTrytes", this.amountOfTxSignParts);
		for (int i = 0; i < this.amountOfTxSignParts; i++) {
			this.Payload006.put("Trytes_" + i, shorterTrytes[i]);
		}
		this.setPayload(this.Payload006.toString());

	}

	// Constructor that turns the received message from buyer into an message object
	public Message006b(String inJsonAsString, EncryptionObject inEncryptionObject, String[] TrytesPreviouslySent) {
		super(inJsonAsString, inEncryptionObject);
		// Set object variables depending on JSON
		this.Payload006 = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload006.get("SelfContinueService");
		this.partnerConsidersStateValid = (boolean) this.Payload006.get("SelfConsidersStateValid");
		this.sellerAcceptsProposal = (boolean) this.Payload006.get("SellerAcceptsProposal");
		this.sellerCountersPIDNumber = (String) this.Payload006.get("SellerCountersPIDNumber");
		this.sellerCountersPIPPrice = ((Number) this.Payload006.get("SellerCountersPIPPrice")).longValue();
		this.soldData = (String) this.Payload006.get("Data");
		this.messageHelp = new MessageHelper();

		int amountTrytesPackages = (int) this.Payload006.get("AmountTrytes");
		this.txSignParts = new String[amountTrytesPackages];
		for (int j = 0; j < amountTrytesPackages; j++) {
			this.txSignParts[j] = (String) this.Payload006.get("Trytes_" + j);
		}
		this.txSignParts = this.messageHelp.buildOriginalTrytes(this.txSignParts);
		
		if (this.txSignParts.length == 1) {
			String storage = this.txSignParts[0];
			this.txSignParts = new String[TrytesPreviouslySent.length];
			for (int k = 0; k < TrytesPreviouslySent.length; k++) {
				this.txSignParts[k] = TrytesPreviouslySent[k];
			}
			this.txSignParts[0] = storage;
		}
	}

	public boolean isSelfContinueService() {
		return selfContinueService;
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public boolean isSelfConsidersStateValid() {
		return selfConsidersStateValid;
	}

	public boolean isPartnerConsidersStateValid() {
		return partnerConsidersStateValid;
	}

	public boolean isSellerAcceptsProposal() {
		return sellerAcceptsProposal;
	}

	public String getSellerCountersPIDNumber() {
		return sellerCountersPIDNumber;
	}

	public long getSellerCountersPIPPrice() {
		return sellerCountersPIPPrice;
	}

	public String[] getTxSignParts() {
		return txSignParts;
	}

	public String getSoldData() {
		return soldData;
	}
}
