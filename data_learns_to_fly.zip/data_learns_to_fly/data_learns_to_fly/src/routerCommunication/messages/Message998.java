package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Type 998 - security message to make sure, that partner was able to generate
// shared secret and handshake was successful

public class Message998 extends RouterParentMessage {


	private boolean selfContinueService, partnerContinuesService;
	private EncryptionObject encryptionObject;
	private JSONObject Payload998;
	private boolean selfHandshakeCorrect, partnerHandshakeCorrect;

	public Message998(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService,
			boolean inHandshakeCorrect) {

		// super constructor and further variables, that are characteristic for 998
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);
		this.encryptionObject = ownEncryptionObject;

		this.Payload998 = new JSONObject();
		this.Payload998.put("SelfContinueService", inSelfContinueService);
		this.Payload998.put("SelfHandshakeCorrect", inHandshakeCorrect);

		// Encode Payload with Partner's Public RSA Key to protect digests and AES
		// keyFragements
		String JSONwithoutRSA = this.Payload998.toString();
		String JSONwithRSA = this.encryptionObject.encodeByForeignPublicKeyRSA(JSONwithoutRSA);
		this.setPayload(JSONwithRSA);
	}

	public Message998(String inJsonAsString, EncryptionObject ownEncryptionObject) {
		super(inJsonAsString, ownEncryptionObject);

		// Decode String with own private key and build JSON
		this.encryptionObject = ownEncryptionObject;
		String messageDecoded = this.encryptionObject.decodeRSA(this.getPayload());
		this.Payload998 = new JSONObject(messageDecoded);

		// Set object variables depending on JSON
		this.partnerContinuesService = (boolean) this.Payload998.get("SelfContinueService");
		this.partnerHandshakeCorrect = (boolean) this.Payload998.get("SelfHandshakeCorrect");

	}

	public boolean isSelfContinueService() {
		return selfContinueService;
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public boolean isSelfHandshakeCorrect() {
		return selfHandshakeCorrect;
	}

	public boolean isPartnerHandshakeCorrect() {
		return partnerHandshakeCorrect;
	}

	public EncryptionObject getEncryptionObject() {
		return encryptionObject;
	}

	public void reEncodePayload() {
		// Re-Encode Payload with Partner's Public RSA Key to protect digests and AES
		// keyFragements
		String JSONwithoutRSA = this.Payload998.toString();
		String JSONwithRSA = this.encryptionObject.encodeByForeignPublicKeyRSA(JSONwithoutRSA);
		this.setPayload(JSONwithRSA);
	}

}
