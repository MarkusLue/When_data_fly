package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
 * Part of the paper: "When data fly: a wireless data trading system in
 * vehicular ad-hoc networks", last date modified: 11th of January 2021
 **/

// The scope of this message is to deliver the newly build multisignaddress
// to each other and check whether both parties came up with the same multisign
// address
// additionally the overall value of the transaction is established.

public class Message005 extends RouterParentMessage {

	private boolean ownBundleHashSet, selfContinueService, partnerContinuesService, selfUsesOutsourcedPow, partnerUsesOutsourcedPow, ownTrytesSet;
	private String[] ownTrytesForOutsourcedPow, partnerTrytesForOutsourcedPow;
	private String ownTxBundleHash, partnerTxBundleHash;

	private JSONObject Payload005;
	private MessageHelper messageHelp;

	public Message005(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService,
			boolean inSelfUsesOutsourcedPow) {
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);

		// super constructor and further variables, that are characteristic for 005
		this.selfContinueService = inSelfContinueService;
		this.selfUsesOutsourcedPow = inSelfUsesOutsourcedPow;
		this.ownTrytesSet = false;
		this.ownBundleHashSet = false;
		this.messageHelp = new MessageHelper();
		this.buildMessage();
	}

	public Message005(String inJsonAsString, EncryptionObject inEncryptionObject) {
		super(inJsonAsString, inEncryptionObject);

		// Set object variables depending on JSON
		this.Payload005 = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload005.get("SelfContinueService");
		this.partnerUsesOutsourcedPow = (boolean) this.Payload005.getBoolean("SelfUsesOutsourcedPow");
		this.messageHelp = new MessageHelper();

		// Submit either the bundle hash of the submitted transaction or the trytes that
		// are outsourced
		if (this.partnerUsesOutsourcedPow) {
			int trytesAmount = (int) this.Payload005.get("TrytesAmount");
			String[] trytesSaver = new String[trytesAmount];
			for (int i = 0; i < trytesAmount; i++) {
				trytesSaver[i] = (String) this.Payload005.get("Trytes_" + i);
			}
			this.partnerTrytesForOutsourcedPow = this.messageHelp.buildOriginalTrytes(trytesSaver);
		} else {
			this.partnerTxBundleHash = (String) this.Payload005.get("OwnTxBundleHash");
		}
	}

	public void buildMessage() {

		this.Payload005 = new JSONObject();
		this.Payload005.put("SelfContinueService", this.selfContinueService);
		this.Payload005.put("SelfUsesOutsourcedPow", this.selfUsesOutsourcedPow);

		if (this.ownTrytesSet) {

			this.Payload005.put("TrytesAmount", this.ownTrytesForOutsourcedPow.length);
			String[] shorterTrytes = messageHelp.shortenTrytesWith9ers(this.ownTrytesForOutsourcedPow);

			for (int i = 0; i < shorterTrytes.length; i++) {
				String Key = "Trytes_" + i;
				this.Payload005.put(Key, shorterTrytes[i]);
			}
		}

		if (this.ownBundleHashSet) {
			this.Payload005.put("OwnTxBundleHash", this.ownTxBundleHash);
		}

		this.setPayload(this.Payload005.toString());
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public boolean isPartnerUsesOutsourcedPow() {
		return partnerUsesOutsourcedPow;
	}

	public String[] getPartnerTrytesForOutsourcedPow() {
		return partnerTrytesForOutsourcedPow;
	}

	public boolean isOwnBundleHashSet() {
		return ownBundleHashSet;
	}

	public String getPartnerTxBundleHash() {
		return partnerTxBundleHash;
	}

	public void setSelfContinueService(boolean selfContinueService) {
		this.selfContinueService = selfContinueService;
	}

	public void setSelfUsesOutsourcedPow(boolean selfUsesOutsourcedPow) {
		this.selfUsesOutsourcedPow = selfUsesOutsourcedPow;
	}

	public void setOwnTrytesForOutsourcedPow(String[] ownTrytesForOutsourcedPow) {
		this.ownTrytesForOutsourcedPow = ownTrytesForOutsourcedPow;
		this.ownTrytesSet = true;
		this.buildMessage();
	}

	public void setOwnTxBundleHash(String ownTxBundleHash) {
		this.ownTxBundleHash = ownTxBundleHash;
		this.ownBundleHashSet = true;
		this.buildMessage();
	}

}
