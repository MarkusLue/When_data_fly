package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

//The scope of this message is to deliver the the deal value and address digests
// to each other and check whether both parties came up with the same multisign address
// additionally the overall value of the transaction is established.

public class Message003 extends RouterParentMessage{
	
	
	private boolean partnerContinuesService;
	private double partnerMaxDealValue;
	private JSONObject Payload003;
	private String partnerMultiSignDigest;
	
	public Message003(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService, double inMaxDealValue, String inOwnMultiSignDigest){
		
		// super constructor and further variables
		super(ownEncryptionObject, inTypeNumber, inIsSensitive); 

		this.Payload003 = new JSONObject();
		this.Payload003.put("SelfContinueService", inSelfContinueService);
		this.Payload003.put("MaxDealValue", inMaxDealValue);
		this.Payload003.put("ownMultiSignDigest", inOwnMultiSignDigest);
		this.setPayload(this.Payload003.toString());
	}
	
	public Message003(String inJsonAsString, EncryptionObject inEncryptionObject) {
		super(inJsonAsString, inEncryptionObject);
						
		// Set object variables depending on JSON
		this.Payload003 = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload003.get("SelfContinueService");
		this.partnerMaxDealValue = (double) this.Payload003.getDouble("MaxDealValue");
		this.partnerMultiSignDigest = (String) this.Payload003.get("ownMultiSignDigest");
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}


	public double getPartnerMaxDealValue() {
		return partnerMaxDealValue;
	}

	public String getPartnerMultiSignDigest() {
		return partnerMultiSignDigest;
	}

}
