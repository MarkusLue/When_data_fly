package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The scope of this message is to deliver the signed trytes of a multisign state to the partner

public class Message999 extends RouterParentMessage{
		
	private boolean selfContinueService, partnerContinuesService;
	private String[] ownTrytes, partnerTrytes;	
	private JSONObject Payload999;
	private MessageHelper messageHelp;

	public Message999(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService, String[] inOwnTrytes){
		super(ownEncryptionObject, inTypeNumber, inIsSensitive); 
		
		// super constructor and further variables, that are characteristic for 999
		this.selfContinueService = inSelfContinueService;
		this.ownTrytes = inOwnTrytes;
		this.messageHelp = new MessageHelper();

		this.Payload999 = new JSONObject();
		this.Payload999.put("SelfContinueService", this.selfContinueService);
		
		// Save an indicator and the Trytes content to Payload object
		this.Payload999.put("AmountTrytes", this.ownTrytes.length);
		String[] shorterTrytes = this.messageHelp.shortenTrytesWith9ers(this.ownTrytes);

		for (int i = 0; i < this.ownTrytes.length; i++) {
			this.Payload999.put("Trytes_" + i, shorterTrytes[i]);
		}
		
		this.setPayload(this.Payload999.toString());
	}
	
	public Message999(String inJsonAsString, EncryptionObject inEncryptionObject) {
		super(inJsonAsString, inEncryptionObject);
						
		// Set object variables depending on JSON
		this.Payload999 = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload999.get("SelfContinueService");
		this.messageHelp = new MessageHelper();

		int amountTrytesPackages = (int) this.Payload999.get("AmountTrytes");
		this.partnerTrytes = new String[amountTrytesPackages];
		
		for (int j = 0; j < amountTrytesPackages; j++) {
			this.partnerTrytes[j] = (String) this.Payload999.get("Trytes_" + j);
		}
		this.partnerTrytes = this.messageHelp.buildOriginalTrytes(this.partnerTrytes);
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public String[] getPartnerTrytes() {
		return partnerTrytes;
	}
	
}
