package routerCommunication.messages;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The goal of this class it to make some message operations easier
// The class provides utility methods

public class MessageHelper {

	public MessageHelper() {}
	
	// This method implements the compression of trytes of IOTA transactions 
	public String[] shortenTrytesWith9ers(String[] inTrytes) {
		
		// basically run length encoding (RLE)
		String[] returner = new String[inTrytes.length];

		// Copy input Array into new Array
		for (int i = 0; i < inTrytes.length; i++) {
			if (inTrytes[i] == null || inTrytes[i].isEmpty()) {
				returner[i] = "";
				
			} else {
		
				// IOTA Trytes contain "9" which must be replace for RLE
				String tempReplace = inTrytes[i].replace("9", "a");
				StringBuilder stringBuilder = new StringBuilder();
				char[] charArray = tempReplace.toCharArray();
				

				StringBuilder stringBuilder = new StringBuilder();
			
				int counter = 1;
				char[] charArray = tempReplace.toCharArray();
				char storeCurrentChar = charArray[0];
			
				for (int i = 1; i < charArray.length; i++) {
					if (charArray[i] == storeCurrentChar) {
						counter++;
					} else {
						stringBuilder.append(storeCurrentChar);
						stringBuilder.append(counter);
						storeCurrentChar = charArray[i];
						counter = 1;
					}
				}
				// Append last RLE
				stringBuilder.append(storeCurrentChar);
				stringBuilder.append(counter);
				
				returner[i] = Base64.getEncoder().encodeToString(MessageHelper.compress(stringBuilder.toString()));
			}			
		}
		return returner;
	}

	// This method implements the decompression of compressed trytes of IOTA transactions (reverses: "shortenTrytesWith9ers(String[] inTrytes)" )
	public String[] buildOriginalTrytes(String[] inTrytes) {

		// basically run length decoding
		String[] returnerArray = new String[inTrytes.length];

		for (int i = 0; i < inTrytes.length; i++) {
			String decompressString = MessageHelper.decompress((Base64.getDecoder().decode(inTrytes[i])));
					
			if (decompressString.isEmpty() || decompressString == null) {
				returnerArray[i] = "";

			} else {
				StringBuilder stringBuilder = new StringBuilder();			
				char[] charArray = decompressString.toCharArray();
			
				for (int i = 1; i <= charArray.length; i++) {

					for (int k = 0; k < Integer.parseInt("" + charArray[i]); k++){
						stringBuilder.append(charArray[i - 1]);
					}
					
					i++;
				}

				returnerArray[i] = stringBuilder.toString().replace("a", "9");
			
			}
		}
		return returnerArray;
	}

	// This method compares trytes, to see if de/en compression works
	public boolean compareTrytes(String[] inTrytes1, String[] inTrytes2) {
		// checks if the two String arrays have the same content

		boolean areEqual = true;
		for (int i = 0; i < inTrytes1.length; i++) {
			if (!(inTrytes1[i].equals(inTrytes2[i]))) {
				areEqual = false;
			}
		}
		return areEqual;
	}

	// This method furhter compresses a String -> Byte
	public static byte[] compress(String text) {
		
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			OutputStream outputStream = new DeflaterOutputStream(byteArrayOutputStream);
			outputStream.write(text.getBytes("UTF-8"));
			outputStream.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return byteArrayOutputStream.toByteArray();
	}

	// This method decompresses Bytes -> String (reverses "compress(String text)" )
	public static String decompress(byte[] bytes) {
		InputStream inputStream = new InflaterInputStream(new ByteArrayInputStream(bytes));
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			// Sufficient length
			byte[] tempBytes = new byte[8100];
			int length;
			while ((length = inputStream.read(tempBytes)) > 0) {
				byteArrayOutputStream.write(tempBytes, 0, length);
			}
			return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
			
		}
	}
}
