package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// scope of the message pair 006a/b is for the buyer to offer a deal for one PID
// with Price
// the offer includes the changed state, signed by the buyer.
// The message can also be a response by the seller. The seller either accepts
// the deal (replys with his 2ndly signed state)
// or offers a change to the deal.

public class Message006a extends RouterParentMessage {

	private boolean selfContinueService, partnerContinuesService, buyerWantsFurtherTx;
	private String buyerWantsToDealPIDNumber;
	private long buyerWantsToDealPIDPrice;
	private int amountOfTxSignParts;
	private String[] txSignParts;
	private JSONObject Payload006;
	private MessageHelper messageHelp;

	// Constructor for the buyer, making a deal to the seller
	public Message006a(EncryptionObject ownEncryptionObject, int inTypeNumber,
			boolean inIsSensitive, boolean inSelfContinueService, boolean inBuyerWantsFurtherTx, String inBuyerWantsToDealPIDNumber,
			long inBuyerWantsToDealPIDPrice, String[] inTxSignParts) {
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);

		// super constructor and further variables, that are characteristic for 006a
		this.selfContinueService = inSelfContinueService;
		this.buyerWantsFurtherTx = inBuyerWantsFurtherTx;
		this.buyerWantsToDealPIDNumber = inBuyerWantsToDealPIDNumber;
		this.buyerWantsToDealPIDPrice = inBuyerWantsToDealPIDPrice;
		this.txSignParts = inTxSignParts;
		this.amountOfTxSignParts = this.txSignParts.length;
		this.messageHelp = new MessageHelper();

		// set payload and add payload to object
		this.Payload006 = new JSONObject();
		this.Payload006.put("SelfContinueService", this.selfContinueService);
		this.Payload006.put("buyerWantsFurtherTx", this.buyerWantsFurtherTx);
		this.Payload006.put("buyerWantsToDealPIDNumber", this.buyerWantsToDealPIDNumber);
		this.Payload006.put("buyerWantsToDealPIDPrice", this.buyerWantsToDealPIDPrice);

		// Save an indicator and the trytes content to payload object
		String[] shorterTrytes = this.messageHelp.shortenTrytesWith9ers(this.txSignParts);

		this.Payload006.put("AmountTrytes", this.amountOfTxSignParts);
		for (int i = 0; i < this.amountOfTxSignParts; i++) {
			String indicator = "Trytes_" + i;
			this.Payload006.put(indicator, shorterTrytes[i]);
			//System.out.println("ToGo (" + shorterTrytes[i].length() + "):" + shorterTrytes[i]);
		}
		this.setPayload(this.Payload006.toString());

	}

	// Constructor that turns the received message from seller into an message
	// object
	public Message006a(String inJsonAsString, EncryptionObject inEncryptionObject) {
		super(inJsonAsString, inEncryptionObject);

		// Set object variables depending on JSON
		this.Payload006 = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload006.get("SelfContinueService");
		this.buyerWantsFurtherTx = (boolean) this.Payload006.get("buyerWantsFurtherTx");
		this.buyerWantsToDealPIDNumber = (String) this.Payload006.get("buyerWantsToDealPIDNumber");
		this.buyerWantsToDealPIDPrice = ((Number) this.Payload006.get("buyerWantsToDealPIDPrice")).longValue();
		this.messageHelp = new MessageHelper();

		
		int amountTrytesPackages = (int) this.Payload006.get("AmountTrytes");
		this.txSignParts = new String[amountTrytesPackages];
		for (int j = 0; j < amountTrytesPackages; j++) {
			String indicator = "Trytes_" + j;
			this.txSignParts[j] = (String) this.Payload006.get(indicator);
		}
		this.txSignParts = this.messageHelp.buildOriginalTrytes(this.txSignParts);
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public boolean isBuyerWantsFurtherTx() {
		return buyerWantsFurtherTx;
	}

	public String getBuyerWantsToDealPIDNumber() {
		return buyerWantsToDealPIDNumber;
	}

	public long getBuyerWantsToDealPIDPrice() {
		return buyerWantsToDealPIDPrice;
	}

	public String[] getTxSignParts() {
		return txSignParts;
	}
}
