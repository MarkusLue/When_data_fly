package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The following message types are used either by the data-buyer (RSU) or
// data-seller (vehicle)
// Message Objects has: UserID/OwnPublicKey, TransactionNumber, Encrypted
// Payload (data + type, typeNumber), OverallSignatures

public class RouterParentMessage {

	private String UserID, DataPayload, Signature, MessageWithoutSignature;
	private EncryptionObject ownEncryptionObject;
	private int TypeNumber;
	private boolean signatureValid, isSensitive;
	private JSONObject savedJSON;
	
	// MultiPart Configuration
	private boolean isMultipart;
	private int multiPartLength, multipartIndex;

	// Formal Constructor to build object if object is send by user
	public RouterParentMessage(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive) {
		
		this.ownEncryptionObject = ownEncryptionObject;
		this.UserID = this.ownEncryptionObject.getFirst10DigitsofHashedPublicKey();
		this.TypeNumber = inTypeNumber;
		this.isSensitive = inIsSensitive;
	}

	// Formal Constructor to build object if object is received by user
	public RouterParentMessage(String inJsonAsString, EncryptionObject inEncryptionObject) {

		// Receiving message and parsing JSON to RouterParentMessage
		JSONObject inObject = new JSONObject(inJsonAsString);
		this.ownEncryptionObject = inEncryptionObject;
		
		// Building RouterParentMessage from parsing JSON
		try {
			this.isSensitive = (boolean) inObject.get("Encrypted");
			this.multipartIndex = (int) inObject.get("MultipartIndex");
			this.multiPartLength = (int) inObject.get("MultiPartLength");
			this.isMultipart = (boolean) inObject.get("IsMultiPart");

			// Signature is only available, if the object is not encrypted.
			if (this.isSensitive) {
				this.Signature = null;
			}else {
				this.Signature = (String) inObject.get("Signature");
			}
			
			this.UserID = (String) inObject.get("OwnUserID");
			this.TypeNumber = (int) inObject.get("TypeNumber");

			String payLoad = "";
			JSONObject sensitivPart = new JSONObject();
			
			if (this.isSensitive) {
				payLoad = (String) inObject.get("Payload");
				sensitivPart = new JSONObject(this.ownEncryptionObject.decodeAES(payLoad));
			} else {
				sensitivPart = inObject.getJSONObject("Payload");
			}

			this.DataPayload = (String) sensitivPart.get("DataPayload");

			// Check if Signature Matches
			inObject.remove("Signature");
			String inputWithSign = inObject.toString();
			this.MessageWithoutSignature = inputWithSign;
			this.signatureValid = this.isSignatureValid();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Incoming message could not be decoded.");
		}
	}

	public void setPayload(String inDataPayload) {
		this.DataPayload = inDataPayload;
	}
	
	public String getPayload() {
		return this.DataPayload;
	}
	
	// Build JSON Form Object without Signature
	private JSONObject getJsonWithoutSign() {
		return this.getJsonWithoutSign(1000000);
	}

	// Build JSON Form Object without Signature
	private JSONObject getJsonWithoutSign(int inMaxLength) {

		// Build general part of JSON Object
		JSONObject jsonWithoutSignature = new JSONObject();
		jsonWithoutSignature.put("OwnUserID", this.UserID);
		jsonWithoutSignature.put("TypeNumber", this.TypeNumber);
		jsonWithoutSignature.put("Encrypted", this.isSensitive);

		// Build part of JSON, that might need to be encrypted
		JSONObject jsonWithSensitveInfo = new JSONObject();
		jsonWithSensitveInfo.put("DataPayload", this.DataPayload);

		// Determine whether sensitive part should be encrypted
		String encryptedPayload = "";
		if (this.isSensitive) {
			encryptedPayload = this.ownEncryptionObject.encodeAES(jsonWithSensitveInfo.toString());
			jsonWithoutSignature.put("Payload", encryptedPayload);
		} else {
			jsonWithoutSignature.put("Payload", jsonWithSensitveInfo);
		}

		if (inMaxLength > 0) {
			if (jsonWithoutSignature.toString().length() > inMaxLength) {
				// 100 is arbitrary, to factor in the length of the added elements after mesauring (e.g. jsonWithoutSignature.put("MultipartIndex", this.multipartIndex))
				this.multiPartLength = (int) Math.ceil(((double) jsonWithoutSignature.toString().length() + 100) / (double) inMaxLength);
				this.multipartIndex = 1;
				this.isMultipart = true;
			} else {
				this.multipartIndex = 1;
				this.multiPartLength = 1;
				this.isMultipart = false;
			}
		} 

		jsonWithoutSignature.put("MultipartIndex", this.multipartIndex);
		jsonWithoutSignature.put("MultiPartLength", this.multiPartLength);
		jsonWithoutSignature.put("IsMultiPart", this.isMultipart);

		return jsonWithoutSignature;
	}

	// Signs the JSON Object
	private JSONObject calcJsonWithSign() {
		JSONObject jsonAddingSignature = this.getJsonWithoutSign();
		this.Signature = this.ownEncryptionObject.sign(jsonAddingSignature.toString());
		jsonAddingSignature.put("Signature", this.Signature);

		return jsonAddingSignature;
	}
	
	public JSONObject calcJSON(int inA) {
		if (this.isSensitive) {
			this.savedJSON = this.getJsonWithoutSign(inA);
			return this.savedJSON;
		} else {
			this.savedJSON = this.calcJsonWithSign();
			return this.savedJSON;
		}
	}
	
	public JSONObject getSavedJSON() {
		return this.savedJSON;
	}

	public boolean isSignatureValid() {
		//Recalculate Validity of Signature and Return boolean
		this.signatureValid = this.ownEncryptionObject.verifySignature(this.MessageWithoutSignature, this.Signature);
		return this.signatureValid;
	}

	public String getUserID() {
		return UserID;
	}

	public int getTypeNumber() {
		return TypeNumber;
	}

	public boolean isSensitive() {
		return isSensitive;
	}

	public EncryptionObject getOwnEncryptionObject() {
		return ownEncryptionObject;
	}

	public void setOwnEncryptionObject(EncryptionObject ownEncryptionObject) {
		this.ownEncryptionObject = ownEncryptionObject;
	}

	public int getMultiPartLength() {
		return multiPartLength;
	}

	public void setMultiPartLength(int multiPartLength) {
		this.multiPartLength = multiPartLength;
	}

	public int getMultipartIndex() {
		return multipartIndex;
	}

	public void setMultipartIndex(int multipartIndex) {
		this.multipartIndex = multipartIndex;
	}

	public boolean isMultipart() {
		return isMultipart;
	}
	
	
}