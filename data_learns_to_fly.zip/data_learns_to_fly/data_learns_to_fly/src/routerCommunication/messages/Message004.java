package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// The scope of this message is to deliver the newly build multisignaddress 
// to each other and check whether both parties came up with the same multisign address
// additionally the overall value of the transaction is established.

public class Message004 extends RouterParentMessage{
	

	private boolean selfContinueService, partnerContinuesService;
	private String ownMultiSignAddress, partnerMultiSignAddress, ownResolveAddress, partnerResolveAddress;
	private JSONObject Payload004a;
	
	public Message004(EncryptionObject ownEncryptionObject,int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService, String inOwnResolveAddress){
		super(ownEncryptionObject, inTypeNumber, inIsSensitive); 
		
		// super constructor and further variables, that are characteristic for 004
		this.selfContinueService = inSelfContinueService;
		this.ownResolveAddress = inOwnResolveAddress;

		this.Payload004a = new JSONObject();
		this.Payload004a.put("SelfContinueService", this.selfContinueService);
		this.Payload004a.put("ResolveAddress", this.ownResolveAddress);
		this.setPayload(this.Payload004a.toString());
	}
	
	public Message004(String inJsonAsString, EncryptionObject inEncryptionObject) {
		super(inJsonAsString, inEncryptionObject);
						
		// Set object variables depending on JSON
		this.Payload004a = new JSONObject(this.getPayload());
		this.partnerContinuesService = (boolean) this.Payload004a.get("SelfContinueService");
		this.partnerResolveAddress = (String) this.Payload004a.get("ResolveAddress");
		this.partnerMultiSignAddress = (String) this.Payload004a.get("OwnMultiSignAddress");
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}

	public String getOwnMultiSignAddress() {
		return ownMultiSignAddress;
	}

	public String getPartnerMultiSignAddress() {
		return partnerMultiSignAddress;
	}

	public void setOwnMultiSignAddress(String inOwnMultiSignAddress) {
		this.ownMultiSignAddress = inOwnMultiSignAddress;
		this.Payload004a.put("OwnMultiSignAddress", this.ownMultiSignAddress);
		this.setPayload(this.Payload004a.toString());
	}

	public String getPartnerResolveAddress() {
		return partnerResolveAddress;
	}
}
