package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// --- service advertisement message for buyer ---
// Type 000 - Buyer (RSU) looking to buy data
// - includes (type of data sold, public_key, link to reputation score)
// Type 000 - Seller (vehicle) looking to sell data
// - includes (type of data sought, public_key, link to reputation score)

public class Message000 extends RouterParentMessage {

	private boolean BUY, SELL;
	private String PublicKey, ReputationID, partnerPreMasterSecret;
	private long minTrustLevel, dealPrice;
	private String[] PID;
	private JSONObject Payload000;

	public Message000(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, String inReputationID, boolean inBuyer, long inTrustLevel,
			long inDealPrice, String[] inPidToTrade) {

		// Configuration
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);
		this.Payload000 = new JSONObject();
		this.BUY = inBuyer;
		this.SELL = !inBuyer;
		this.minTrustLevel = inTrustLevel;
		this.dealPrice = inDealPrice;
		this.PID = inPidToTrade;
		this.ReputationID = inReputationID;

		Payload000.put("BUY", this.BUY);
		Payload000.put("PID", this.arrayToString(this.PID));
		Payload000.put("RepID", this.ReputationID);
		Payload000.put("minTrustLvl", this.minTrustLevel);
		Payload000.put("dealPrice", this.dealPrice);
		Payload000.put("PubKey", ownEncryptionObject.getPublicKey());
		Payload000.put("PreMaSec", ownEncryptionObject.getOwnPreMasterSecret());
		this.setPayload(Payload000.toString());

	}

	public Message000(String inJsonAsString, EncryptionObject ownEncryptionObject) {
		super(inJsonAsString, ownEncryptionObject);

		Payload000 = new JSONObject(this.getPayload());
		this.BUY = (boolean) Payload000.get("BUY");
		this.SELL = !this.BUY;
		this.ReputationID = (String) Payload000.get("RepID");
		this.PublicKey = (String) Payload000.get("PubKey");
		this.partnerPreMasterSecret = (String) Payload000.get("PreMaSec");
		this.PID = this.stringToArray((String) Payload000.get("PID"));
		this.minTrustLevel = Long.parseLong("" + Payload000.get("minTrustLvl"));
		this.dealPrice = Long.parseLong("" + Payload000.get("dealPrice"));
	}

	private String arrayToString(String[] inArray) {

		String returner = "[";
		for (int i = 0; i < inArray.length; i++) {
			if (i < inArray.length - 1) {
				returner = returner + inArray[i] + ",";
			} else {
				returner = returner + inArray[i] + "]";
			}
		}
		return returner;
	}

	private String[] stringToArray(String inString) {
		String tempInString = inString.replace("[", "");
		tempInString = tempInString.replace("]", "");

		return tempInString.split(",");
	}

	public boolean isBUY() {
		return BUY;
	}

	public boolean isSELL() {
		return SELL;
	}

	public String[] getPID() {
		return PID;
	}

	public String getReputationID() {
		return ReputationID;
	}

	public String getPublicKey() {
		return this.PublicKey;
	}

	public String getPartnerPreMasterSecret() {
		return partnerPreMasterSecret;
	}

	public long getMinTrustLevel() {
		return minTrustLevel;
	}

	public long getDealPrice() {
		return dealPrice;
	}
}