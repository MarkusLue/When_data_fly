package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// --- handshake ---
// Type 002 - Buyer (RSU) and Seller (vehicle) agree/deny and
// - includes (continueService, keyFragement)


public class Message002 extends RouterParentMessage{

	private boolean selfContinueService, partnerContinuesService, partnerUsesOutsourcedPow;
	private String ownAesKeyFragement, partnerAesKeyFragement, previousPreMasterSecret;
	private EncryptionObject encryptionObject;
	private JSONObject Payload002;
	
	public Message002(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, boolean inSelfContinueService, boolean inOutsourcedPow, String inPreviousPreMasterSecret){
		
		// super constructor and further variables, that are characteristic for 002a
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);

		this.Payload002 = new JSONObject();
		this.ownAesKeyFragement = ownEncryptionObject.getOwnOwnSharedSecretPart();
		this.Payload002.put("conService", inSelfContinueService);
		this.Payload002.put("aesKeyFragement", this.ownAesKeyFragement);
		this.Payload002.put("outsourcedPow", inOutsourcedPow);
		this.Payload002.put("prevPMS", inPreviousPreMasterSecret);

		//Encode Payload with Partner's Public RSA Key to protect digests and AES keyFragements
		String JSONwithoutRSA = this.Payload002.toString();
		String JSONwithRSA = ownEncryptionObject.encodeByForeignPublicKeyRSA(JSONwithoutRSA);
		this.setPayload(JSONwithRSA);
	}
	
	public Message002(String inJsonAsString, EncryptionObject ownEncryptionObject) {
		super(inJsonAsString, ownEncryptionObject);
		
		// Decode String with own private key and build JSON
		String messageDecoded = ownEncryptionObject.decodeRSA(this.getPayload());
		this.Payload002 = new JSONObject(messageDecoded);
		this.encryptionObject = ownEncryptionObject;
		
		// Set object variables depending on JSON
		this.partnerContinuesService = (boolean) this.Payload002.get("conService");
		this.partnerAesKeyFragement = (String) this.Payload002.get("aesKeyFragement");
		this.partnerUsesOutsourcedPow = (boolean) this.Payload002.get("outsourcedPow");
		this.previousPreMasterSecret = (String) this.Payload002.get("prevPMS");

		// Pass partners AES Key Fragement part onto encryption object
		this.encryptionObject.setSharedSecret(this.partnerAesKeyFragement);	
	}

	public boolean isSelfContinueService() {
		return selfContinueService;
	}

	public boolean isPartnerContinuesService() {
		return partnerContinuesService;
	}
	

	public boolean isPartnerUsesOutsourcedPow() {
		return partnerUsesOutsourcedPow;
	}

	public String getPartnerAesKeyFragement() {
		return partnerAesKeyFragement;
	}

	public EncryptionObject getEncryptionObject() {
		return encryptionObject;
	}
	
	public String getPartnerPreMasterSecret() {
		return this.previousPreMasterSecret;
	}

	public void reEncodePayload () {
		//Re-Encode Payload with Partner's Public RSA Key to protect digests and AES keyFragements
		String JSONwithoutRSA = this.Payload002.toString();
		String JSONwithRSA = this.encryptionObject.encodeByForeignPublicKeyRSA(JSONwithoutRSA);
		this.setPayload(JSONwithRSA);
	}
	
}
