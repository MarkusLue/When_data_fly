package routerCommunication.messages;

import org.json.JSONObject;

import routerCommunication.EncryptionObject;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This message object enables the service discovery (no dutch auction)
// Type 001 - Buyer (RSU) looking to buy data
// - includes (type of data sold, public_key, link to reputation score)
// Type 001 - Seller (vehicle) looking to sell data
// - includes (type of data sought, public_key, link to reputation score)

public class Message001 extends RouterParentMessage {

	private boolean BUY, SELL;
	private String PublicKey, ReputationID, partnerPreMasterSecret;
	private String[] PID;
	private JSONObject Payload001;

	public Message001(EncryptionObject ownEncryptionObject, int inTypeNumber, boolean inIsSensitive, String inReputationID, boolean inBuyer) {

		// Configuration
		super(ownEncryptionObject, inTypeNumber, inIsSensitive);
		this.Payload001 = new JSONObject();
		this.BUY = inBuyer;
		this.SELL = !inBuyer;
		this.PID = new String[] { "05", "0C", "0D"};
		this.ReputationID = inReputationID;

		Payload001.put("BUY", this.BUY);
		Payload001.put("SELL", this.SELL);
		Payload001.put("PID", this.arrayToString(this.PID));
		Payload001.put("ReputationID", this.ReputationID);
		Payload001.put("OwnPublicKey", ownEncryptionObject.getPublicKey());
		Payload001.put("PreMasterSecret", ownEncryptionObject.getOwnPreMasterSecret());
		this.setPayload(Payload001.toString());

	}

	public Message001(String inJsonAsString, EncryptionObject ownEncryptionObject) {
		super(inJsonAsString, ownEncryptionObject);

		Payload001 = new JSONObject(this.getPayload());
		this.BUY = (boolean) Payload001.get("BUY");
		this.SELL = (boolean) Payload001.get("SELL");
		this.ReputationID = (String) Payload001.get("ReputationID");
		this.PublicKey = (String) Payload001.get("OwnPublicKey");
		this.partnerPreMasterSecret = (String) Payload001.get("PreMasterSecret");
		this.PID = this.stringToArray((String) Payload001.get("PID"));

	}

	private String arrayToString(String[] inArray) {

		String returner = "[";
		for (int i = 0; i < inArray.length; i++) {
			if (i < inArray.length - 1) {
				returner = returner + inArray[i] + ",";
			} else {
				returner = returner + inArray[i] + "]";
			}
		}
		return returner;
	}

	private String[] stringToArray(String inString) {
		String tempInString = inString.replace("[", "");
		tempInString = tempInString.replace("]", "");

		return tempInString.split(",");
	}

	public boolean isBUY() {
		return BUY;
	}

	public boolean isSELL() {
		return SELL;
	}

	public String[] getPID() {
		return PID;
	}

	public String getReputationID() {
		return ReputationID;
	}
	
	public String getPublicKey() {
		return this.PublicKey;
	}
	
	public String getPartnerPreMasterSecret() {
		return partnerPreMasterSecret;
	}
}