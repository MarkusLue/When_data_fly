package routerCommunication;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

// Use project with google protobuf and recreate dataPackage
import com.google.protobuf.ByteString;
import routerCommunication.protobuf.dataPackage.Data.DATA;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class describes the CAM composer, that infuses a custom message payload into a CAM message.
// To do so, valid CAM messages (shells) have to be build in order to make the message accepted by OpenC2X

public class CAMComposer {

	private int messageID;
	private String jsonAsString;
	private long validityInSeconds;
	private String targetURL;
	private String targetPort;
	private int sendingFrequency;

	public CAMComposer(String targetIp, String targetPort, int sendingFrequency, long inValidityInSeconds) {
		
		this.targetURL = targetIp;
		this.targetPort = targetPort;
		this.sendingFrequency = sendingFrequency;
		this.validityInSeconds = inValidityInSeconds;
	}

	public byte[] composeCAM(int inMessageID, String inString) {
		
		this.messageID = inMessageID;
		this.jsonAsString = inString;
		
		// Composing and encoding the message that is then send to and later by the
		// router

		// Build final parameters to be handed over to the Data object
		long creationTime = System.currentTimeMillis() * 1000000;
		long validity = (creationTime + 1000 * 1000 * 1000 * this.validityInSeconds);
		ByteString contentAsByteString = ByteString.copyFromUtf8(this.jsonAsString);

		// Build data object as specified by ProtoBuff in OpenC2X
		DATA dataTemp = DATA.newBuilder().setId(this.messageID).setContent(contentAsByteString).setValidUntil(validity)
				.setCreateTime(creationTime).setPriority(DATA.Priority.BE).setType(DATA.Type.CAM).build();

		// Form output as byte array and return it to be used by the router
		byte[] outputByte = dataTemp.toByteArray();
		return outputByte;

	}

	public boolean sendCamToRouter(byte[] targetMessage) {
		
		// Send CAM to 802.11p enabled router
		boolean success = false;
		try (ZContext context = new ZContext()) {
			
			// Socket to talk to server
			ZMQ.Socket socket = context.createSocket(SocketType.REQ);
			String targetAddress = "tcp://" + this.targetURL + ":" + this.targetPort;
			socket.connect(targetAddress);

			for (int interateRequests = 0; interateRequests != 1; interateRequests++) {
				String request = "CAM" + this.sendingFrequency;

				socket.sendMore(targetMessage);
				success = socket.send(request.getBytes(ZMQ.CHARSET), 0);

				@SuppressWarnings({ "unused"})
				byte[] reply = socket.recv(0);
			}
		}
		return success;
		
	}

	public String getTargetURL() {
		return targetURL;
	}

	public String getTargetPort() {
		return targetPort;
	}

}
