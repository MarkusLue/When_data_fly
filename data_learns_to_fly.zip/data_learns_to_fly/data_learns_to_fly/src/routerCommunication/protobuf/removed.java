package routerCommunication.protobuf;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

public class removed {
	
	// The protobuf sub-package includes the ITS-G5 protobuf JAVA representation.
	// See ReadMe to recreate this package
	
}
