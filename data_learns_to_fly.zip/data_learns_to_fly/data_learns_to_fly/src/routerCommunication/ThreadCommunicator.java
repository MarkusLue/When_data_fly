package routerCommunication;

import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import org.iota.jota.model.Transaction;

import enums.MainProps.*;
import errors.*;
import multiTransaction.*;
import multiTransaction.sign.*;
import preloaderAndLogger.*;
import reputationAndIdentity.TrustConfiguration;
import routerCommunication.messages.*;
import runWithRouter.ThreadListenerRouter;
import vehicleData.*;

/**
 * Part of the paper: "When data fly: a wireless data trading system in
 * vehicular ad-hoc networks", last date modified: 11th of January 2021
 **/

// This thread is the implementation of the ad-hoc data trade algorithm.

public class ThreadCommunicator extends Thread {

	// Properties
	private static int sendFrequency = 1; // Messages are sent one time by the router
	private static long validityInSeconds = INSERT_Validity; // Validity of message on the 802.11p router's DCC (see ITS-G5 Spec)
	private static String tag = "INSERT_TAG"; // IOTA Message Tag
	private static int routerMaxMessageLength = 1300; // Maximum length of 802.11p OpenC2X Message, limit

	// Variables
	@SuppressWarnings("unused")
	private String name, namePartner, incomingMessage, reputationID, partnerUserID, digest, ownMultiSignAddress, partnerMultiSignAddress;
	@SuppressWarnings("unused")
	private boolean communicationEnded, isBuyer, multiSignIsValid, useOutsourcedPow, partnerUsesOutsourcedPow, bothMultiSignInputsBroadcasted,
			bothMultiSignInputsConfirmed, hasReceivedSharedSecret;

	@SuppressWarnings("unused")
	private long maximalDealValue, msgCoutner, timeToPreload;
	private int seedSecSingleTx, seedSec, numberOfStateChanges;
	private String[] matchedPIDs, finalTrytesToSend;

	private EncryptionObject encryptionObj;
	private ThreadListenerRouter threadListener;
	private VehicleDataThread randVehiDataThread;
	private VehicleData vehData;
	private IotaPreload iotaPreLoad;
	private MultiSignState tmss;

	private ReaderWriteFile rwf;
	private MessageSlicer msgSlicer;

	private String targetIP;
	private CAMComposer camComp;
	private ConnectionHelper cHelp;

	// variables that are used to check whether the multisign address has all
	// (confirmed) inputs
	private MultiSignAddressStatus multiSignAddrStatus;
	private long partnerDealValue;
	@SuppressWarnings("unused")
	private String ownInputTxHash, partnerInputTxHash;

	// variables that are used to handle the multisign states
	private String ownMultiSignResolveAddress, partnerMultiSignResolveAddress;

	// store the last sent messages
	private Hashtable<Integer, RouterParentMessage> messageSaver;

	// Status variables
	private boolean endedCycle, timeOut;
	private String finalBundleHash, preMasterSecret;
	private TrustConfiguration trustConfig;
	private TimeAndDataLogger timeAndDataLogger;

	public ThreadCommunicator(EncryptionObject inEnOb, ReaderWriteFile inRwf, ConnectionHelper inConHelp, String inName, String inNamePartner, boolean inBuyer,
			String inRepID, VehicleDataThread inRandVehiDataThread, IotaPreload inIotaPreLoad, boolean inUseOutsourcedPow, int ineedSecSingleTx, int inSeedSec,
			TrustConfiguration inTrustConfig, long timeToPreload) {
		this.encryptionObj = inEnOb;
		this.cHelp = inConHelp;
		this.communicationEnded = false;
		this.isBuyer = inBuyer;
		this.reputationID = inRepID;
		this.name = inName;
		this.namePartner = inNamePartner;
		this.randVehiDataThread = inRandVehiDataThread;
		this.iotaPreLoad = inIotaPreLoad;
		this.digest = this.iotaPreLoad.getMultiSignDigests();
		this.useOutsourcedPow = inUseOutsourcedPow;
		this.bothMultiSignInputsBroadcasted = false;
		this.bothMultiSignInputsConfirmed = false;
		this.multiSignAddrStatus = new MultiSignAddressStatus(this.iotaPreLoad.getIotaAPI(), this.isBuyer, this.digest);
		this.ownMultiSignResolveAddress = this.iotaPreLoad.getNextUnspentAddressMainSeed();
		this.camComp = new CAMComposer(inConHelp.getTargetUrl(), "INSERT_Port", sendFrequency, validityInSeconds);
		this.rwf = inRwf;
		this.targetIP = this.cHelp.getTargetUrl();
		this.seedSecSingleTx = ineedSecSingleTx;
		this.vehData = this.randVehiDataThread.getVehData();
		this.hasReceivedSharedSecret = false;
		this.messageSaver = new Hashtable<Integer, RouterParentMessage>();
		this.msgCoutner = 0;
		this.seedSec = inSeedSec;
		this.endedCycle = false;
		this.trustConfig = inTrustConfig;
		this.timeOut = false;
		this.numberOfStateChanges = 6;
		this.timeToPreload = timeToPreload;
	}

	public void run() {

		// initial configuration
		System.out.println(this.getPrintWithIndent(" initialized, sending service discovery message to partner"));

		System.out.println(this.getPrintWithIndent(" listens on: " + this.targetIP + ":" + this.cHelp.getPort()));
		this.threadListener = new ThreadListenerRouter(this.cHelp.getPort(), this.targetIP, this.encryptionObj);
		this.threadListener.start();

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part I - RSU and Vehicle send Service Discovery Message (Beaconing)

		// Start Programm and Logger
		this.timeAndDataLogger = new TimeAndDataLogger(this.isBuyer, this.rwf.getPath());
		this.timeAndDataLogger.addRawData("000_ProgramStarted");
		this.msgSlicer = new MessageSlicer(this.timeAndDataLogger);
		this.timeAndDataLogger.setSessionStarted(System.currentTimeMillis());
		this.timeAndDataLogger.setBoostedPoW(this.cHelp.isPowReachable());
		this.timeAndDataLogger.setMwm(this.iotaPreLoad.getMwm());
		this.timeAndDataLogger.setPreloadingTime(this.timeToPreload);
		double initialBeforeSending;

		this.timeAndDataLogger.addRawData("001_StartSendingMSG001");
		Message001 m001ToSend = new Message001(this.encryptionObj, 1, IsSensitive.NO, this.reputationID, this.isBuyer);
		this.sendMSG(1, m001ToSend.calcJSON(routerMaxMessageLength).toString(), false);
		this.messageSaver.put(1, m001ToSend);

		this.timeAndDataLogger.addRawData("002_StartWaitForInitialMSGFromPartner");
		while (!this.hasReceivedInitalMessage()) {
			// wait for new message and rebroadcast older message
			this.sendMSG(1, m001ToSend.calcJSON(routerMaxMessageLength).toString(), false);
			this.timeAndDataLogger.timeOut(1, m001ToSend.calcJSON(routerMaxMessageLength).toString());

			// Send Advertisment every 100 ms
			try {
				Thread.sleep(100);
			} catch (Exception e) {
			}
		}
		this.timeAndDataLogger.addRawData("003_ReceivedInitialMSGFromPartner");

		// Incoming Initial Message is received
		this.partnerUserID = this.getInitialMessageUserID();
		System.out.println(this.getPrintWithIndent(" recived message, from " + this.partnerUserID));
		this.timeAndDataLogger.setReceivedMSG(1);

		this.timeAndDataLogger.addRawData("004_StartWaitForMSG001FromPartner");
		initialBeforeSending = System.currentTimeMillis();
		while (!this.userHasMessageUpdateByType(this.partnerUserID, 1) && !this.communicationEnded && !this.timeOut) {
			// wait for new message and rebroadcast older message
			this.sendMSG(1, m001ToSend.getSavedJSON().toString(), true, this.partnerUserID);
			this.broadcastLastMSG(1, this.messageSaver, initialBeforeSending, this.partnerUserID);
			this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(1, m001ToSend.getSavedJSON().toString());
		}
		this.timeAndDataLogger.addRawData("005_ReceivedMSG001FromPartner");

		// Process Response to Initial Message and send Handshake Message
		this.timeAndDataLogger.setSessionStarted(System.currentTimeMillis());
		Message001 m001Received = new Message001(this.getMessagAtIndex(this.partnerUserID, 1), this.encryptionObj);
		this.preMasterSecret = m001Received.getPartnerPreMasterSecret();
		System.out.println(this.getPrintWithIndent(" received partner's preMasterSecret: " + this.preMasterSecret));
		this.encryptionObj.setForeignPublicKey(m001Received.getPublicKey());

		// Perform ReputationLookUp and store time used for that within the TimeObjekt
		long timeTrustBefore = System.currentTimeMillis();
		double[] trustConfigResult = this.trustConfig.getPeersAttestation(m001Received.getPublicKey());
		this.timeAndDataLogger.setNodeQueryGetRating((System.currentTimeMillis() - timeTrustBefore));
		System.out.println(this.getPrintWithIndent(" parsed partners trust score, it is: " + trustConfigResult[0] + "%, and " + trustConfigResult[1] + "%."));
		this.timeAndDataLogger.setRatingBeforeTrade(trustConfigResult);

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part II - RSU and Vehicle check if signature match and communicate if they
		// want to continue their conversation

		Message002 m002ToSend = new Message002(this.encryptionObj, 2, IsSensitive.NO, ContinueService.YES, this.useOutsourcedPow, this.preMasterSecret);
		m001Received.setOwnEncryptionObject(this.encryptionObj);
		System.out.println(this.getPrintWithIndent(" recheived new message, signature: " + m001Received.isSignatureValid()));

		// Check whether Buy/Sell Configuration and PID matches -> then send new message
		if (this.initalSettingMatch(m001ToSend, m001Received)) {
			this.maximalDealValue = (long) this.getMaxValueMatchedPIDs(this.matchedPIDs(m001ToSend, m001Received));
			this.sendMSG(2, m002ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
			System.out.println(this.getPrintWithIndent(" send Handshake message."));
		} else if (!m001Received.isSignatureValid()) {
			System.out.println(this.getPrintWithIndent(" stoped negotitation, because the signature was broken."));
			this.communicationEnded = true;
		} else {
			System.out.println(this.getPrintWithIndent(" stoped negotitation, because there is no fit in Sell/Buy or PID configuration."));
			this.communicationEnded = true;
		}
		this.messageSaver.put(2, m002ToSend);

		// Wait for answer of Handshake message
		initialBeforeSending = System.currentTimeMillis();
		this.timeAndDataLogger.addRawData("006_StartWaitForMSG002FromPartner");
		while (!this.userHasMessageUpdateByType(this.partnerUserID, 2) && !this.communicationEnded && !this.timeOut) {
			// wait for new message and rebroadcast older message
			this.sendMSG(2, m002ToSend.getSavedJSON().toString(), true, this.partnerUserID);
			this.broadcastLastMSG(1, this.messageSaver, initialBeforeSending, this.partnerUserID);
			this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(2, m002ToSend.getSavedJSON().toString());
		}
		this.timeAndDataLogger.addRawData("007_ReceivedMSG002FromPartner");

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part II.B - RSU and Vehicle set various details

		// Answer of Handshake occurred
		if (this.userHasMessageUpdateByType(this.partnerUserID, 2)) {
			this.timeAndDataLogger.setReceivedMSG(2);
			Message002 m002Received = new Message002(this.getMessagAtIndex(this.partnerUserID, 2), this.encryptionObj);
			System.out.println(this.getPrintWithIndent(" received answer to Handshake."));

			// Update encryption object for same shared Secret
			this.encryptionObj = m002Received.getEncryptionObject();
			System.out.println(this.getPrintWithIndent("s Shared Secret is: " + this.encryptionObj.getSharedSecret()));
			this.partnerUsesOutsourcedPow = m002Received.isPartnerUsesOutsourcedPow();

			// Check if preMasterSecret was returned correctly
			if (!m002Received.getPartnerPreMasterSecret().equals(this.encryptionObj.getOwnPreMasterSecret())) {
				System.out.println(" received an wrong return of the PreMasterSecret, possible replay attack.");
				this.communicationEnded = true;
			} else {
				System.out.println(this.getPrintWithIndent(" received correct encrypted preMasterSecret."));
			}

			// Check if the shared secret was received properly
			if (this.encryptionObj.getSharedSecret() != null) {
				this.hasReceivedSharedSecret = true;
			}

			// Message partner to signal, that the shared secret was delivered properly.
			Message998 m998ToSend = new Message998(this.encryptionObj, 998, IsSensitive.NO, ContinueService.YES, this.hasReceivedSharedSecret);
			this.sendMSG(998, m998ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
			this.messageSaver.put(998, m998ToSend);
			this.hasReceivedSharedSecret = false;

			// Wait for answer of Message998
			initialBeforeSending = System.currentTimeMillis();

			this.timeAndDataLogger.addRawData("008_StartedForMSG998FromPartner");
			while (!this.userHasMessageUpdateByType(this.partnerUserID, 998) && !this.communicationEnded && !this.timeOut) {
				// wait for new message and rebroadcast older message
				this.sendMSG(998, m998ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.broadcastLastMSG(2, this.messageSaver, initialBeforeSending, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(998, m998ToSend.getSavedJSON().toString());
			}
			this.timeAndDataLogger.addRawData("009_ReceivedMSG998FromPartner");

			// If no timeout or other problem -> check for shared secret
			if (!this.communicationEnded || !this.timeOut) {
				Message998 m998Received = new Message998(this.getMessagAtIndex(this.partnerUserID, 998), this.encryptionObj);

				if (m998Received.isPartnerHandshakeCorrect() && m998Received.isSignatureValid()) {
					this.hasReceivedSharedSecret = true;
				}
				System.out.println(
						this.getPrintWithIndent(" recived *" + m998Received.isPartnerHandshakeCorrect() + "* form partner to continue, after handshake."));
				System.out.println(this.getPrintWithIndent(" recived this message with signature: " + m998Received.isSignatureValid()));
			}
		}

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part III - RSU and Vehicle set various details (MultiSignature Digests, and
		// Max Deal Value)

		if (this.hasReceivedSharedSecret) {
			this.timeAndDataLogger.setReceivedMSG(998);

			// Send message 003 to partner
			Message003 m003ToSend = new Message003(this.encryptionObj, 3, IsSensitive.YES, ContinueService.YES, this.maximalDealValue, this.digest);
			this.sendMSG(3, m003ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
			this.messageSaver.put(3, m003ToSend);

			// Wait for answer of Message003
			initialBeforeSending = System.currentTimeMillis();
			System.out.println(this.getPrintWithIndent(" sent Message003."));

			this.timeAndDataLogger.addRawData("010_StartForMSG003FromPartner");
			while (!this.userHasMessageUpdateByType(this.partnerUserID, 3) && !this.communicationEnded && !this.timeOut) {
				// wait for new message and rebroadcast older message
				this.broadcastLastMSG(998, this.messageSaver, initialBeforeSending, this.partnerUserID);
				this.sendMSG(3, m003ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(3, m003ToSend.getSavedJSON().toString());
			}
			this.timeAndDataLogger.addRawData("011_ReceivedMSG003FromPartner");
		}

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part IV - Exchange MultiSignature Address

		// Answer of Message 003 occurred
		if (this.userHasMessageUpdateByType(this.partnerUserID, 3)) {
			this.timeAndDataLogger.setReceivedMSG(3);

			// Prepare Message of Type 004
			Message004 m004ToSend = new Message004(this.encryptionObj, 4, IsSensitive.YES, ContinueService.YES, this.ownMultiSignResolveAddress);
			Message003 m003Received = new Message003(this.getMessagAtIndex(this.partnerUserID, 3), this.encryptionObj);
			this.partnerDealValue = (long) m003Received.getPartnerMaxDealValue();
			System.out.println(this.getPrintWithIndent(" received answer to Message003."));
			System.out.println(this.getPrintWithIndent(" received MultiSignDigests: " + m003Received.getPartnerMultiSignDigest().substring(0, 20) + "..."));
			System.out.println(this.getPrintWithIndent(" received maximal deal value of: " + m003Received.getPartnerMaxDealValue()));

			// Send message 004 to partner
			this.ownMultiSignAddress = this.multiSignAddrStatus.generateMultiSignAddress(m003Received.getPartnerMultiSignDigest())[0];
			this.multiSignIsValid = Boolean.parseBoolean(this.multiSignAddrStatus.generateMultiSignAddress(m003Received.getPartnerMultiSignDigest())[1]);

			m004ToSend.setOwnMultiSignAddress(this.ownMultiSignAddress);
			this.sendMSG(4, m004ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
			this.messageSaver.put(4, m004ToSend);
			System.out.println(this.getPrintWithIndent(" send Message004."));

			// Wait for answer of Message004
			initialBeforeSending = System.currentTimeMillis();
			this.timeAndDataLogger.addRawData("012_StartWaitMSG004FromPartner");
			while (!this.userHasMessageUpdateByType(this.partnerUserID, 4) && !this.communicationEnded && !this.timeOut) {
				// wait for new message and rebroadcast older message
				this.broadcastLastMSG(3, this.messageSaver, initialBeforeSending, this.partnerUserID);
				this.sendMSG(4, m004ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(4, m004ToSend.getSavedJSON().toString());
			}
			this.timeAndDataLogger.addRawData("013_ReceivedMSG004FromPartner");
		}

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part V - Parties perform Single Signature and Tx to move collateral to
		// MultiSign Address

		// Answer of Message 004 occurred
		if (this.userHasMessageUpdateByType(this.partnerUserID, 4)) {
			this.timeAndDataLogger.setReceivedMSG(4);

			// Prepare Message of Type 5
			Message005 m005ToSend = new Message005(this.encryptionObj, 5, IsSensitive.YES, ContinueService.YES, this.useOutsourcedPow);
			Message004 m004Received = new Message004(this.getMessagAtIndex(this.partnerUserID, 4), this.encryptionObj);
			System.out.println(this.getPrintWithIndent(" received answer to Message004."));
			this.partnerMultiSignAddress = m004Received.getPartnerMultiSignAddress();
			this.partnerMultiSignResolveAddress = m004Received.getPartnerResolveAddress();

			// Make Transaction to the Tangle and send hash to partner
			if (this.ownMultiSignAddress.equals(this.partnerMultiSignAddress) && this.multiSignIsValid) {
				this.timeAndDataLogger.setMultiSignatureAddress(this.ownMultiSignAddress);
				System.out.println(this.getPrintWithIndent(" received MultiAddress. Addresses match and are valid."));
				this.getPrintWithIndentSingle("Multisign Address is: " + this.partnerMultiSignAddress);
				System.out.println(this.getPrintWithIndent(" is using the outsourced PoW: " + this.useOutsourcedPow));

				// Prepare the Single Sign Transaction
				SingleSign SinSig = this.iotaPreLoad.getSinSig();
				SinSig.setOutsourcedPow(this.useOutsourcedPow);

				// Send Single Sign Transaction to the tangle.
				this.timeAndDataLogger.addRawData("014_StartSingleSign");
				long powSingleSignStart = System.currentTimeMillis();
				String[] response = SinSig.performSingleTransaction(this.iotaPreLoad.getMainSeed(), this.ownMultiSignAddress,
						this.iotaPreLoad.getNextUnspentAddressMainSeed(), this.maximalDealValue, "originated by: " + this.name, tag, this.iotaPreLoad.getMwm(),
						this.iotaPreLoad.getDepth(), this.seedSecSingleTx, this.iotaPreLoad.getBalanceAddressMainSeed(),
						this.iotaPreLoad.getAddressWithBalanceMainSeed(), this.iotaPreLoad.getKeyWithBalanceMainSeed());
				this.timeAndDataLogger.setPowSingleTxTransfer((System.currentTimeMillis() - powSingleSignStart));

				// Separate depending whether the outsourced PoW is used
				if (this.useOutsourcedPow) {
					m005ToSend.setOwnTrytesForOutsourcedPow(response);
					System.out.println(this.getPrintWithIndent(" sent work to partner, for outsourced PoW"));
				} else {
					this.ownInputTxHash = response[1];
					m005ToSend.setOwnTxBundleHash(response[1]);
					System.out.println(this.getPrintWithIndent(" submitted the SingleSign transaction: " + response[0]));
				}
				this.timeAndDataLogger.addRawData("015_EndSingleSign");

				this.sendMSG(5, m005ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
				this.messageSaver.put(5, m005ToSend);
				System.out.println(this.getPrintWithIndent(" send Message005."));

			} else {
				this.communicationEnded = true;
			}

			// Wait for answer of Message005
			initialBeforeSending = System.currentTimeMillis();
			this.timeAndDataLogger.addRawData("016_WaitForMSG005FromPartner");
			while (!this.userHasMessageUpdateByType(this.partnerUserID, 5) && !this.communicationEnded && !this.timeOut) {
				// wait for new message and rebroadcast older message
				this.broadcastLastMSG(4, this.messageSaver, initialBeforeSending, this.partnerUserID);
				this.sendMSG(5, m005ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(5, m005ToSend.getSavedJSON().toString());
			}
			this.timeAndDataLogger.addRawData("017_ReceivedMSG005FromPartner");
		}

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// - - - - - - - - - - - - - - - - - - - - -
		// Part VI - Receive SingleSign response from partner (either: performed well,
		// or please outsource)

		// Answer of Message 005 occurred
		if (this.userHasMessageUpdateByType(this.partnerUserID, 5)) {
			this.timeAndDataLogger.setReceivedMSG(5);

			// Prepare Message of Type 5
			Message005 m005Received = new Message005(this.getMessagAtIndex(this.partnerUserID, 5), this.encryptionObj);
			System.out.println(this.getPrintWithIndent(" received answer to Message005."));

			// Seperate if partner asks for outsourced PoW
			if (m005Received.isPartnerUsesOutsourcedPow()) {

				// If the partner asks for outsourced PoW perform this PoW
				this.timeAndDataLogger.addRawData("018_StartProcessOutsourcedPoW");
				long powSingleSignStart = System.currentTimeMillis();
				String[] processed = this.iotaPreLoad.getSinSig().processOutsourcesPoW(m005Received.getPartnerTrytesForOutsourcedPow());
				this.timeAndDataLogger.setPowSingleTxTransferOutsourced((System.currentTimeMillis() - powSingleSignStart));

				System.out.println(this.getPrintWithIndent(" received request to preform outsourced PoW."));
				System.out.println(this.getPrintWithIndent(" handled requests transaction: " + processed[0]));
				this.partnerInputTxHash = processed[1];
				this.timeAndDataLogger.addRawData("019_EndProcessOutsourcedPoW");

			} else {
				// Store the partners bundle hash
				this.partnerInputTxHash = m005Received.getPartnerTxBundleHash();
			}

			// both parties read from the tangle whether the transactions were performed,
			// and send enough
			// balance to the multisignaddress if the inputs are not there try to get the
			// status again

			this.timeAndDataLogger.addRawData("020_StartWaitInputsSingleSign");
			while (!this.multiSignAddrStatus.isInputsAreThere() && !this.timeOut) {

				// rebroadcast - just to make sure, that partner did not loose this messages
				this.sendMSG(4, this.messageSaver.get(4).getSavedJSON().toString(), false);
				this.sendMSG(5, this.messageSaver.get(5).getSavedJSON().toString(), false);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(4, this.messageSaver.get(4).getSavedJSON().toString());
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(5, this.messageSaver.get(5).getSavedJSON().toString());

				// give partner time to perform outsourced POW
				if (this.useOutsourcedPow) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
					}
				}

				// Check if inputs are there, write Node Query Time to timeAndDataKeeper
				long timeNodeQueryInputs = System.currentTimeMillis();
				this.multiSignAddrStatus.checkIfInputsAreThere(this.ownMultiSignAddress, this.maximalDealValue, this.partnerDealValue);
				long timeAlreadySpent = this.timeAndDataLogger.getNodeQuerySingleTxTransfer();
				this.timeAndDataLogger.setNodeQuerySingleTxTransfer((timeAlreadySpent + (System.currentTimeMillis() - timeNodeQueryInputs)));

				// Wait until new search for incoming transactions on the multiSign address
				int sleepTime = 100;
				if (this.multiSignAddrStatus.isInputsAreThere()) {
					sleepTime = 0;
				}
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
				}
			}
			this.timeAndDataLogger.addRawData("021_EndWaitInputsSingleSign");
			System.out.println(this.getPrintWithIndent(" checked the multisign address, both inputs were broadcastet."));
		}

		// |-------------------------------------------------------------------------------------------------------------------------------------
		// | All information to perform the deal were received
		// | Now the multisignpart starts with initializing the multisign state object
		// |-------------------------------------------------------------------------------------------------------------------------------------
		// -> Start to deal the individual PIDs

		if (!this.timeOut && !this.communicationEnded) {
			this.timeAndDataLogger.setTimeAdHocMSG(System.currentTimeMillis());

			this.timeAndDataLogger.addRawData("022_StartAdHocDataTrade");
			this.tmss = new MultiSignState(this.isBuyer, this.name, this.namePartner, this.ownMultiSignAddress, this.maximalDealValue, this.partnerDealValue,
					this.ownMultiSignResolveAddress, this.partnerMultiSignResolveAddress, this.iotaPreLoad.getMainSeed(), this.iotaPreLoad.getRandomSeed(), tag,
					this.seedSec);

			// buyer offers DEAL to Seller with PID number, price, wish to buy more, and
			// signed updated state (if deal would be accepted)
			int numberOfPIDsToBeTraded = this.matchedPIDs.length;
			boolean continueTrade = this.multiSignAddrStatus.isInputsAreThere();
			int indictingCurrentPidObject = 0;
			while (continueTrade) {

				continueTrade = false;
				this.vehData = this.randVehiDataThread.getVehData();

				// -------------------------------------------------------------------------------------------------------------------------------------
				// Part of the Buyer

				if (this.isBuyer) {

					// Gather data related to this PID trade
					String pidToDeal = this.matchedPIDs[indictingCurrentPidObject];
					long priceToDeal = this.vehData.getStorageOBDbyPID().get(pidToDeal).getPrice();

					try {
						tmss.paysPartner(priceToDeal);
					} catch (NotEnoughBalanceError e) {
						e.printStackTrace();
					}

					String[] txTrytesCurrentState = tmss.getSignedCurrentState();

					// Check if other values are to trade after this deal
					if (indictingCurrentPidObject < numberOfPIDsToBeTraded) {
						continueTrade = true;
					}

					// Prepare the message
					Message006a m006ToSend = new Message006a(this.encryptionObj, numberOfStateChanges, IsSensitive.YES, ContinueService.YES, continueTrade,
							pidToDeal, priceToDeal, txTrytesCurrentState);
					this.messageSaver.put(numberOfStateChanges, m006ToSend);
					this.sendMSG(numberOfStateChanges, m006ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);

					System.out.println(this.getPrintWithIndent(" sent buy request for PID: " + pidToDeal + " (for " + priceToDeal + "i) to partner."));
					// Wait for answer form partner and parse answer

					initialBeforeSending = System.currentTimeMillis();
					this.timeAndDataLogger.addRawData("022_" + numberOfStateChanges + "_BUYERStartSendingMSG_" + numberOfStateChanges);
					while (!this.userHasMessageUpdateByType(this.partnerUserID, numberOfStateChanges) && !this.communicationEnded && !this.timeOut) {
						// wait for new message and rebroadcast older message
						// buyer waits for answer from seller, rebroadcasts and handles the response
						this.sendMSG(numberOfStateChanges, m006ToSend.getSavedJSON().toString(), true, this.partnerUserID);
						this.broadcastLastMSG(numberOfStateChanges - 1, this.messageSaver, initialBeforeSending, this.partnerUserID);
						this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(numberOfStateChanges, m006ToSend.getSavedJSON().toString());

						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
						}
					}
					this.timeAndDataLogger.addRawData("022_" + numberOfStateChanges + "_BUYERReceivedAnswerToMSG_" + numberOfStateChanges);

					// answer from seller occurred
					if (this.userHasMessageUpdateByType(this.partnerUserID, numberOfStateChanges)) {
						this.timeAndDataLogger.setReceivedMSG(numberOfStateChanges);
						Message006b m006Received = new Message006b(this.getMessagAtIndex(this.partnerUserID, numberOfStateChanges), this.encryptionObj,
								txTrytesCurrentState);

						// Partner accepted deal
						if (m006Received.isSellerAcceptsProposal() && m006Received.isPartnerConsidersStateValid()) {

							VehicleDataObject vdo = this.vehData.getStorageOBDbyPID().get(pidToDeal);
							System.out.println(this.getPrintWithIndent(" received data from partner (" + vdo.getName() + "), PID (" + pidToDeal + "): "
									+ m006Received.getSoldData() + vdo.getUnit()));
							this.rwf.addBoughtData(m006Received.getSoldData(), pidToDeal, vdo.getName(), vdo.getUnit());
							this.timeAndDataLogger.addBoughtData(m006Received.getSoldData(), pidToDeal, vdo.getName(), vdo.getUnit());

							// Check is Signature is valid
							if (tmss.checkPartnerSignature(m006Received.getTxSignParts())) {
								System.out.println(this.getPrintWithIndent(" checked state trytes from partner, they match."));
							}
							// Partner did not accept deal
						} else {
							try {
								tmss.reversePaysPartner(priceToDeal);
							} catch (NotEnoughBalanceError e) {
								e.printStackTrace();
							}
							System.out.println(this.getPrintWithIndent(" partner did not accept proposal."));
							// TODO Build procedure if partner does not accept deal
						}

					}

					// -------------------------------------------------------------------------------------------------------------------------------------
					// Part of the Seller

				} else {

					boolean gotInitialTx = false;

					while (!gotInitialTx && !this.communicationEnded && !this.timeOut) {

						// seller waits for answer from buyer and reacts with own message
						gotInitialTx = (this.userHasMessageUpdateByType(this.partnerUserID, numberOfStateChanges));
						this.broadcastLastMSG(numberOfStateChanges - 1, this.messageSaver, initialBeforeSending, this.partnerUserID);
						this.sendMSG((numberOfStateChanges - 1), this.messageSaver.get(numberOfStateChanges - 1).getSavedJSON().toString(), false);

						// Make sure, that there is a timeOut, if answer does not occur within certain
						// boundaries.
						this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut((numberOfStateChanges - 1),
								this.messageSaver.get(numberOfStateChanges - 1).getSavedJSON().toString());

						try {
							Thread.sleep(150);
						} catch (InterruptedException e) {
						}
					}

					// answer from seller occurred, briefly always accept
					boolean acceptOffer = true;
					if (gotInitialTx) {
						this.timeAndDataLogger.addRawData("022_" + numberOfStateChanges + "_SellerReceivedMSG_" + numberOfStateChanges + "_Trade");
						System.out.println(this.getPrintWithIndent(" received an offer."));
						this.timeAndDataLogger.setReceivedMSG(numberOfStateChanges);

						// Parse incoming message
						Message006a m006Received = new Message006a(this.getMessagAtIndex(this.partnerUserID, numberOfStateChanges), this.encryptionObj);
						continueTrade = m006Received.isBuyerWantsFurtherTx();
						long offeredPrice = m006Received.getBuyerWantsToDealPIDPrice();

						// Check if seller wants to take the offer
						VehicleDataObject veDaOb = this.vehData.getStorageOBDbyPID().get(m006Received.getBuyerWantsToDealPIDNumber());
						if ((offeredPrice <= veDaOb.getPriceHighBound()) && (offeredPrice >= veDaOb.getPriceLowBound())) {
							acceptOffer = true;
						}

						// if seller accepts the offer, the seller delivers the data and returns message
						if (acceptOffer) {

							// Change state according to trade
							try {
								tmss.getsPayed(offeredPrice);
							} catch (NotEnoughBalanceError e) {
								e.printStackTrace();
							}

							String[] readyToBroadcast = { tmss.checkAndCoSignReceivedState(m006Received.getTxSignParts())[0] };
							String valueAsString = "" + veDaOb.getValue();

							// exception needed for location.
							if (veDaOb.getPID().equals("LO")) {
								valueAsString = "" + veDaOb.getValueString();
							}

							Message006b m006Send = new Message006b(this.encryptionObj, numberOfStateChanges, IsSensitive.YES, ContinueService.YES,
									tmss.isValidSignature(), acceptOffer, "", 0, readyToBroadcast, valueAsString);
							this.messageSaver.put(numberOfStateChanges, m006Send);

							this.sendMSG(numberOfStateChanges, m006Send.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);

							System.out.println(this.getPrintWithIndent(" accepted offer of " + offeredPrice + "i for PID: " + veDaOb.getPID() + "."));

							// if seller neglects the offer, a counter offer is presented.
						} else {

							String counterPID = veDaOb.getPID();
							long counterPrice = (long) veDaOb.getPriceLowBound();

							// Problem Invalid value transfer: the transfer does not require a signature.
							// String[] currentState = tmss.getSignedCurrentState();
							String[] currentState = { "ABCDEFGHIJKLMNOPQRSTUVWXYZ9" };
							Message006b m006Send = new Message006b(this.encryptionObj, numberOfStateChanges, IsSensitive.YES, ContinueService.YES,
									tmss.isValidSignature(), acceptOffer, counterPID, counterPrice, currentState, "");
							this.messageSaver.put(numberOfStateChanges, m006Send);
							this.sendMSG(numberOfStateChanges, m006Send.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);
							System.out.println(this.getPrintWithIndent(" declined offer of " + offeredPrice + "i for PID: " + veDaOb.getPID() + "."));
						}
					}
				}

				// -------------------------------------------------------------------------------------------------------------------------------------
				// Go to next PiD and break deal, if all tx have been dealt

				// During Test: Break after 1 tx
				numberOfStateChanges += 1;
				indictingCurrentPidObject += 1;

				// All PIDs Have been traded?
				if (indictingCurrentPidObject == numberOfPIDsToBeTraded) {
					continueTrade = false;
					this.broadcastLastMSG(numberOfStateChanges - 1, this.messageSaver, initialBeforeSending, this.partnerUserID);

					// if deal is over, write bought data to hard drive
					if (this.isBuyer) {
						try {
							this.rwf.writeBoughtData(this.partnerUserID);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}

			}
			this.timeAndDataLogger.addRawData("100_EndAdHocDataTrade");
		}

		// -------------------------------------------------------------------------------------------------------------------------------------
		// Part 999

		if (this.userHasMessageUpdateByType(this.partnerUserID, (this.numberOfStateChanges - 1))) {
			this.timeAndDataLogger.setReceivedMSG(this.numberOfStateChanges - 1);

			// Clear last collateral in State
			tmss.resolveLockedAmounts();

			// Prepare MultiSign Transaction
			Message999 m999ToSend = new Message999(this.encryptionObj, 999, IsSensitive.YES, ContinueService.YES, tmss.getSignedCurrentState());

			this.messageSaver.put(999, m999ToSend);
			this.sendMSG(999, m999ToSend.calcJSON(routerMaxMessageLength).toString(), false, this.partnerUserID);

			System.out.println(this.getPrintWithIndent(" sent finale MX Bundle."));

			// Wait for answer of Message999
			initialBeforeSending = System.currentTimeMillis();

			this.timeAndDataLogger.addRawData("101_WaitForFinalMSGToClearState");
			while (!this.userHasMessageUpdateByType(this.partnerUserID, 999) && !this.communicationEnded && !this.timeOut) {
				this.sendMSG(999, m999ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.broadcastLastMSG(numberOfStateChanges - 1, this.messageSaver, initialBeforeSending, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(999, m999ToSend.getSavedJSON().toString());
			}
			this.timeAndDataLogger.addRawData("102_ReceivedFinalMSGToClearState");

			// Answer of Message 999 occurred
			if (this.userHasMessageUpdateByType(this.partnerUserID, 999)) {
				this.timeAndDataLogger.setReceivedMSG(999);
				Message999 m999Received = new Message999(this.getMessagAtIndex(this.partnerUserID, 999), this.encryptionObj);
				System.out.println(this.getPrintWithIndent(" received answer to Message999."));
				this.finalBundleHash = tmss.getBundleHash();
				this.finalTrytesToSend = tmss.checkAndCoSignReceivedState(m999Received.getPartnerTrytes());
			}

			// End Cycle by sending MSG999 5 times more
			int k = 0;
			while (k < 5) {
				this.sendMSG(999, m999ToSend.getSavedJSON().toString(), true, this.partnerUserID);
				this.communicationEnded = this.timeOut = this.timeAndDataLogger.timeOut(999, m999ToSend.getSavedJSON().toString());
				k++;
			}
			this.timeAndDataLogger.setMidTime(System.currentTimeMillis());
		}

		// -------------------------------------------------------------------------------------------------------------------------------------
		// The necessary states of the multisign transaction were exchanged.
		// Now both parties wait for the multisign inputs to confirm, and broadcast the
		// multisign transaction to the tangle

		boolean inputsUnconfirmed = true;
		while (inputsUnconfirmed && !this.timeOut && !this.communicationEnded) {
			this.timeAndDataLogger.addRawData("103_EndAdHocPart");
			this.timeAndDataLogger.addRawData("104_StartWaitForConfirmationSingleSign");

			System.out.println(this.getPrintWithIndent(" found that both are confirmed is: " + this.multiSignAddrStatus.isInputsAreConfirmed()));

			long timePreCheckConfirmed = System.currentTimeMillis();
			inputsUnconfirmed = !this.multiSignAddrStatus.isInputsAreConfirmed();
			this.timeAndDataLogger.setNodeQueryMultiTxTransfer((System.currentTimeMillis() - timePreCheckConfirmed));

			if (!inputsUnconfirmed && !this.communicationEnded && !this.timeOut) {
				if (!this.isBuyer) {
					this.timeAndDataLogger.addRawData("105_SingleSignConfirmed");
					// Send trytes to free up the balances on seed
					if (tmss.isConsenusWithPartnerOverState()) {
						System.out.println(this.getPrintWithIndent(" compared both multisign transactions and they match."));
						if (tmss.isValidSignature()) {

							// Time and perform pow + send to tangle
							long timeBeforePOWMulti = System.currentTimeMillis();
							this.timeAndDataLogger.addRawData("106_StartPoWMultiSign");
							List<Transaction> txListTemp = this.iotaPreLoad.getIotaAPI().sendTrytes(this.finalTrytesToSend, this.iotaPreLoad.getDepth(),
									this.iotaPreLoad.getMwm(), null);
							this.timeAndDataLogger.setPowMultiTxTransfer((System.currentTimeMillis() - timeBeforePOWMulti));
							System.out.println(this.getPrintWithIndent(" resolved MultiSign address and sent result to tangle."));
							this.finalBundleHash = txListTemp.get(0).getBundle().toString();
						} else {
							System.out.println(this.getPrintWithIndent(" MultiSign signature is not valid."));
						}
					} else {
						System.out.println(this.getPrintWithIndent(" compared both multisign transactions and they do not match."));
					}
				}
			}
			this.timeAndDataLogger.addRawData("107_DoneBroadcastMultiSign");
			this.timeAndDataLogger.addRawData("108_StartWaitConfirmMultiSign");
			if (inputsUnconfirmed) {
				try {
					System.out.print(this.getPrintWithIndent(" found that both are confirmed is: " + this.multiSignAddrStatus.isInputsAreConfirmed()));
					System.out.println(". Next try in 10s.");
					Thread.sleep(10000);
				} catch (InterruptedException e) {
				}
			}
		}
		this.timeAndDataLogger.addRawData("109_EndWaitConfirmMultiSign");
		// -------------------------------------------------------------------------------------------------------------------------------------
		// Time and add Rating to the Partner

		long timeBeforeRating = System.currentTimeMillis();
		this.timeAndDataLogger.addRawData("110_StartRatingPartner");
		if (!this.timeOut) {
			this.timeAndDataLogger.setFullCycle(true);
			long[] rating2Partner = { 100, 100 };
			this.timeAndDataLogger.setRatedTrade(new double[] { rating2Partner[0], rating2Partner[1] });

			// Deactivated for consistent measurement
			// this.trustConfig.giveAttestation(m001Received.getPublicKey(),
			// rating2Partner);
			this.trustConfig.giveAttestation("INSERT_KEY", rating2Partner);
			this.timeAndDataLogger.setPowRatingTxTransfer((System.currentTimeMillis() - timeBeforeRating));
			System.out.println(this.getPrintWithIndent(" rated the trust of the partner positive."));
		} else {
			long[] rating2Partner = { 0, 0 };
			this.timeAndDataLogger.setRatedTrade(new double[] { rating2Partner[0], rating2Partner[1] });

			// Deactivated for consistent measurement
			// this.trustConfig.giveAttestation(m001Received.getPublicKey(),
			// rating2Partner);
			this.trustConfig.giveAttestation("INSER_KEY", rating2Partner);
			System.out.println(this.getPrintWithIndent(" rated the trust of the partner negative."));
			this.timeAndDataLogger.setPowRatingTxTransfer((System.currentTimeMillis() - timeBeforeRating));

			this.timeAndDataLogger.addRawData("111_EndRatingPartner");
			this.timeAndDataLogger.triggerWrite(this.partnerUserID, this.getReceivedHashtable());
			this.endedCycle = true;
			System.exit(0);
		}

		this.timeAndDataLogger.addRawData("111_EndRatingPartner");

		// -------------------------------------------------------------------------------------------------------------------------------------
		// Program ended, print time and stop threads

		// Set variables (e.g. Bundle Hash)
		this.timeAndDataLogger.triggerWrite(this.partnerUserID, this.getReceivedHashtable());
		this.endedCycle = true;
	}

	private void broadcastLastMSG(int i, Hashtable<Integer, RouterParentMessage> messageSaver2, double initialBeforeSending, String partnerUserID2) {

		// Method sends the last MSG again, in case this one did not reach the target.
		int previousMessage = i;
		this.sendMSG(previousMessage, messageSaver2.get(previousMessage).getSavedJSON().toString(), false);
	}

	private String[] matchedPIDs(Message001 inMessageA, Message001 inMessageB) {

		// Method checks which PIDs out of two PID-amounts match
		String[] arrayStringA = inMessageA.getPID();
		String[] arrayStringB = inMessageB.getPID();
		LinkedList<String> storeMatchedPIDs = new LinkedList<String>();

		for (int i = 0; i < arrayStringA.length; i++) {
			for (int j = 0; j < arrayStringB.length; j++) {
				if (arrayStringA[i].equals(arrayStringB[j])) {
					storeMatchedPIDs.add(arrayStringA[i]);
				}
			}
		}
		System.out.println(this.getPrintWithIndent(" calculated " + storeMatchedPIDs.size() + " matching PID pairs."));
		this.matchedPIDs = storeMatchedPIDs.toArray(new String[0]);
		return this.matchedPIDs;
	}

	private double getMaxValueMatchedPIDs(String[] inMatchedPIDs) {

		// Method calculates the Deal's maximum value based on the users PID upper price bound
		double maxValue = 0;
		for (int i = 0; i < inMatchedPIDs.length; i++) {
			for (int j = 0; j < this.vehData.getStorageObdObjects().size(); j++) {
				if (inMatchedPIDs[i].equals(this.vehData.getStorageObdObjects().get(j).getPID())) {
					maxValue = maxValue + this.vehData.getStorageObdObjects().get(j).getPriceHighBound();
				}
			}
		}
		return maxValue;
	}

	private boolean initalSettingMatch(Message001 inMessageA, Message001 inMessageB) {

		// Method checks whether the PID categories match and a trade can happen
		String[] arrayStringA = inMessageA.getPID();
		String[] arrayStringB = inMessageB.getPID();

		boolean PIDMatch = false;
		if (arrayStringA.length == 0 || arrayStringB.length == 0) {
			PIDMatch = false;
		} else {
			for (int i = 0; i < arrayStringA.length; i++) {
				for (int j = 0; j < arrayStringB.length; j++) {
					if (arrayStringA[i].equals(arrayStringB[j])) {
						PIDMatch = true;
					}
				}
			}
		}

		// Check whether the Sell / Buy configuration matches
		boolean SellBuyMatch = false;
		SellBuyMatch = (inMessageA.isBUY() != inMessageB.isBUY()) && (inMessageA.isSELL() != inMessageB.isSELL());

		if (PIDMatch && SellBuyMatch) {
			return true;
		} else {
			return false;
		}
	}

	private String getPrintWithIndent(String inText) {

		// Print console log with an indent to different multiple threads (Parties)
		int fillamount = 140;

		if (this.isBuyer) {
			fillamount = 0;
		}

		String filler = " ";
		String filledString = "";

		for (int i = 0; i < (fillamount - inText.length()); i++) {
			filledString = filledString + filler;
		}

		return filledString + this.name + inText;
	}

	private void getPrintWithIndentSingle(String inText) {

		// Print console log with an indent to different multiple threads (Parties)
		int fillamount = 140;

		if (this.isBuyer) {

			String filler = " ";
			String filledString = "";

			for (int i = 0; i < ((fillamount - inText.length()) / 2); i++) {
				filledString = filledString + filler;
			}
			System.out.println("\n" + filledString + inText + "\n");
		}
	}

	private Hashtable<String, Hashtable<Integer, Integer>> getReceivedHashtable() {

		// Method returnes the receveived MSG Hastabel based on simulation or router based test.
		return this.threadListener.getUserIdMessageIdCount();

	}

	private void sendMSG(int inNumber, String inMessage, boolean inLoopWaiting, String inUserID) {

		// method enables the sending of a MSG (forwarding to slicer) based on router or
		// local test environment

		this.msgCoutner += 1;
		msgSlicer.sendMSG(inNumber, inMessage, camComp, this.encryptionObj);

		if (!this.userHasMessageUpdateByType(inUserID, inNumber)) {
			if (inLoopWaiting) {
				try {
					Thread.sleep(150);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void sendMSG(int inNumber, String inMessage, boolean inLoopWaiting) {

		// method enables the sending of a MSG (forwarding to slicer) based on router or
		// local test environment

		this.msgCoutner += 1;
		// If the routers are not reachable, run the local simulation
		msgSlicer.sendMSG(inNumber, inMessage, camComp, this.encryptionObj);

		if (inLoopWaiting) {
			try {
				Thread.sleep(150);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public String getMessagAtIndex(String UserID, int messageIndex) {

		// Method returns the Message received from UserID at a certain index, method
		// seperates between test, and router environment
		return this.threadListener.getMessagAtIndex(UserID, messageIndex);
	}

	public boolean userHasMessageUpdateByType(String UserID, int inType) {

		// Method returns whether there was a Message update received from UserID at a
		// certain index, method separates between test, and router environment
		return this.threadListener.userHasMessageUpdateByType(UserID, inType);
	}

	public boolean hasReceivedInitalMessage() {

		// Method returns whether there was an initial Message received from any UserID,
		// method separates between test, and router environment
		return this.threadListener.hasReceivedInitalMessage();

	}

	public String getInitialMessageUserID() {

		// Method returns UserID if there was an initial Message received from any
		// UserID, method separates between test, and router environment
		return this.threadListener.getInitialMessageUserID();

	}

	public boolean isEndedCycle() {
		return endedCycle;
	}

	public String getFinalBundleHash() {
		return finalBundleHash;
	}

}
