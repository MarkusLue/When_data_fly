package routerCommunication;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class specifies the Encryption Object that helps with various en- and decryption tasks

public class EncryptionObject {

	private PublicKey publicKey, foreignPublicKey;
	private PrivateKey privateKey;
	private String sharedSecret, ownPartSharedSecret, foreignPartSharedSecret, type, first10DigitsofHashedPublicKey, ownPreMasterSecret;

	// Build Encryption Object and generate a fresh key pair.
	public EncryptionObject(String inType) {

		// Generate own part of the shared secret for AES
		this.generateOwnSharedSecret();
		this.type = inType;
		this.ownPreMasterSecret = this.getPreMasterSecret();

		// Generate RSA Key Pair
		KeyPairGenerator keyPairGenerator;
		try {
			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
			keyPairGenerator.initialize(1024);
			KeyPair pair = keyPairGenerator.generateKeyPair();
			this.privateKey = pair.getPrivate();
			this.publicKey = pair.getPublic();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		this.first10DigitsofHashedPublicKey = this.getHashedFirst10DigitsOfPublicKey();
	}

	// Build Encryption Object by passing along a private Key.
	public EncryptionObject(String inPrivateKey, String inType) {

		// Generate own part of the shared secret for AES
		this.generateOwnSharedSecret();
		this.type = inType;
		this.ownPreMasterSecret = this.getPreMasterSecret();

		try {
			// set private Key as PrivateKey Object from private key String
			Base64.Decoder byteDecoder = Base64.getDecoder();
			byte[] privateKeyInBytes = byteDecoder.decode(inPrivateKey);
			PKCS8EncodedKeySpec encodedKeySpec = new PKCS8EncodedKeySpec(privateKeyInBytes);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			this.privateKey = keyFactory.generatePrivate(encodedKeySpec);

			// set public Key as PublicKey Object from private key String
			RSAPrivateCrtKey rsaPrivateCrtKey = (RSAPrivateCrtKey) this.privateKey;
			RSAPublicKeySpec publicKeySpec = new java.security.spec.RSAPublicKeySpec(rsaPrivateCrtKey.getModulus(), rsaPrivateCrtKey.getPublicExponent());
			this.publicKey = keyFactory.generatePublic(publicKeySpec);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		this.first10DigitsofHashedPublicKey = this.getHashedFirst10DigitsOfPublicKey();
	}

	public String getPreMasterSecret() {
		
		// Calculate the random preMasterSecret
		int lengthPseudoRandomPart = 10;
		String currentTimeUnix = "" + System.currentTimeMillis();
		// Generate pseudo-random String, with flexible length (input)
		String charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		StringBuilder builder = new StringBuilder();
		while (lengthPseudoRandomPart-- != 0) {
			int charAt = (int) (Math.random() * charset.length());
			builder.append(charset.charAt(charAt));
		}
		return currentTimeUnix + builder.toString();
	}
	
	
	// RSA - Enocde a message using the object specific foreign public Key
	public String encodeByForeignPublicKeyRSA(String message) {

		try {
			Cipher cipherEncryption = Cipher.getInstance("RSA");
			cipherEncryption.init(Cipher.ENCRYPT_MODE, this.foreignPublicKey);

			byte[] cipherByte = cipherEncryption.doFinal(message.getBytes("UTF-8"));
			return Base64.getEncoder().encodeToString(cipherByte);

		} catch (Exception e) {
			return e.toString();
		}
	}

	// RSA - Decode a cipher message using the objects private key
	public String decodeRSA(String message) {
		try {
			byte[] decoderBytes = Base64.getDecoder().decode(message);
			Cipher cipherDecryption = Cipher.getInstance("RSA");
			cipherDecryption.init(Cipher.DECRYPT_MODE, this.privateKey);

			return new String(cipherDecryption.doFinal(decoderBytes), "UTF-8");
		} catch (Exception e) {
			return e.toString();
		}
	}

	// RSA - Get Public Key
	public String getPublicKey() {
		return Base64.getEncoder().encodeToString(this.publicKey.getEncoded());
	}

	// RSA - Get Private Key
	public String getPrivateKey() {
		return Base64.getEncoder().encodeToString(this.privateKey.getEncoded());
	}

	// RSA - Set Foreign Public Key
	public void setForeignPublicKey(String inForeignPublicKey) {
		try {
			Base64.Decoder rsaDecoder = Base64.getDecoder();
			byte[] byteForeignPublicKey = rsaDecoder.decode(inForeignPublicKey);
			X509EncodedKeySpec encodedKeySpec = new X509EncodedKeySpec(byteForeignPublicKey);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			this.foreignPublicKey = keyFactory.generatePublic(encodedKeySpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// RSA - Get Foreign Public Key
	public String getForeignPublicKey() {
		return Base64.getEncoder().encodeToString(this.foreignPublicKey.getEncoded());
	}

	// RSA - Check if Public and Private Key are compatible to each other
	public boolean isRSAKeyPairValid() {
		RSAPublicKey rsaPublicKey = (RSAPublicKey) this.publicKey;
		RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) this.privateKey;
		return rsaPublicKey.getModulus().equals(rsaPrivateKey.getModulus()) && BigInteger.valueOf(2)
				.modPow(rsaPublicKey.getPublicExponent().multiply(rsaPrivateKey.getPrivateExponent()).subtract(BigInteger.ONE), rsaPublicKey.getModulus())
				.equals(BigInteger.ONE);
	}

	// RSA - Sign message with object's private Key
	public String sign(String plainText) {
		try {
			Signature privSignature = Signature.getInstance("SHA256withRSA");
			privSignature.initSign(this.privateKey);
			privSignature.update(plainText.getBytes("UTF-8"));
			byte[] signature = privSignature.sign();
			return Base64.getEncoder().encodeToString(signature);
		} catch (Exception e) {
			return e.toString();
		}
	}

	// RSA - verify a signature with the object's foreign public key
	public boolean verifySignature(String signatureText, String signature) {

		try {
			Signature pubSignature = Signature.getInstance("SHA256withRSA");
			pubSignature.initVerify(this.foreignPublicKey);
			pubSignature.update(signatureText.getBytes("UTF-8"));
			byte[] signatureBytes = Base64.getDecoder().decode(signature);
			return pubSignature.verify(signatureBytes);

		} catch (Exception e) {
			return false;
		}
	}

	// AES - Encode message via AES using the shared secret.
	public String encodeAES(String message) {

		String output = "Encryption failed, see error for details.";

		try {
			byte[] aesBytes = (this.sharedSecret).getBytes("UTF-8");
			MessageDigest messageDigests = MessageDigest.getInstance("SHA-256");
			aesBytes = messageDigests.digest(aesBytes);
			aesBytes = Arrays.copyOf(aesBytes, 16);
			SecretKeySpec secretKeySpec = new SecretKeySpec(aesBytes, "AES");

			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
			byte[] encrypted = cipher.doFinal(message.getBytes());
			output = new String(Base64.getEncoder().encode(encrypted));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return output;
	}

	// AES - Decode message via AES using the shared secret.
	public String decodeAES(String message) {

		String output = "Decryption failed, see error for details.";

		try {
			byte[] aesBytes = (this.sharedSecret).getBytes("UTF-8");
			MessageDigest messageDigests = MessageDigest.getInstance("SHA-256");
			aesBytes = messageDigests.digest(aesBytes);
			aesBytes = Arrays.copyOf(aesBytes, 16);
			SecretKeySpec secretKeySpec = new SecretKeySpec(aesBytes, "AES");

			byte[] decoded = Base64.getDecoder().decode(message);
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
			byte[] decrypted = cipher.doFinal(decoded);
			output = new String(decrypted);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	private void generateOwnSharedSecret() {
		try {	
			SecretKey secretKey = KeyGenerator.getInstance("AES").generateKey();
			String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
			this.ownPartSharedSecret = encodedKey.substring(0, encodedKey.length() / 2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getOwnOwnSharedSecretPart() {
		return this.ownPartSharedSecret;
	}

	public String getSharedSecret() {
		return this.sharedSecret;
	}

	public void setSharedSecret(String inPartnerPartSharedSecret) {

		// Differentiate whether the type is buyer or seller to build shared AES key in
		// the right way
		this.foreignPartSharedSecret = inPartnerPartSharedSecret;

		if (this.type.equals("SELLER")) {
			this.sharedSecret = this.foreignPartSharedSecret + this.ownPartSharedSecret;
		} else {
			this.sharedSecret = this.ownPartSharedSecret + this.foreignPartSharedSecret;
		}
	}
	
	public boolean checkHashedFirst10DigitsToPublicKey(String in10Digits, String inPublicKey) {
		// Check the hashed 10 first digits of public key
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] digestAsHash = messageDigest.digest(inPublicKey.getBytes("UTF-8"));
			StringBuffer stringBuffer = new StringBuffer();

			for (int i = 0; i < digestAsHash.length; i++) {
				String hexAsString = Integer.toHexString(0xff & digestAsHash[i]);
				if (hexAsString.length() == 1)
					stringBuffer.append('0');
				stringBuffer.append(hexAsString);
			}
			
			if ( stringBuffer.toString().substring(0, 10).equals(in10Digits)) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		
	}

	private String getHashedFirst10DigitsOfPublicKey() {
		// Returns the hashed first 10 Digits of the public key
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] digestAsHash = messageDigest.digest(this.getPublicKey().getBytes("UTF-8"));
			StringBuffer stringBuffer = new StringBuffer();

			for (int i = 0; i < digestAsHash.length; i++) {
				String hexAsString = Integer.toHexString(0xff & digestAsHash[i]);
				if (hexAsString.length() == 1)
					stringBuffer.append('0');
				stringBuffer.append(hexAsString);
			}
			return stringBuffer.toString().substring(0, 10);

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public String getFirst10DigitsofHashedPublicKey() {
		return first10DigitsofHashedPublicKey;
	}

	public String getOwnPreMasterSecret() {
		return ownPreMasterSecret;
	}

	public void setOwnPreMasterSecret(String ownPreMasterSecret) {
		this.ownPreMasterSecret = ownPreMasterSecret;
	}

}
