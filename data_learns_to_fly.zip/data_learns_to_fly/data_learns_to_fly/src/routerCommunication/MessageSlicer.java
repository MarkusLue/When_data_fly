package routerCommunication;

import preloaderAndLogger.TimeAndDataLogger;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// This class handles the message slicing: maximal length of transmission (around 1400 characters)

import routerCommunication.messages.RouterParentMessage;


public class MessageSlicer {

	private int number;
	private String message;
	private CAMComposer camComp;
	private EncryptionObject enOb;
	private RouterParentMessage r1;
	private boolean alternater;
	private TimeAndDataLogger taDL;

	public MessageSlicer(TimeAndDataLogger inTaDL) {
		this.alternater = true;
		this.taDL = inTaDL;
	}

	// Method sends slices Messages if the 802.11p enabled Routers are used.
	public void sendMSG(int inNumber, String inMessage, CAMComposer inCamComp, EncryptionObject inEncryptionObj) {

		// Build needed Objects
		this.number = inNumber;
		this.message = inMessage;
		this.camComp = inCamComp;
		this.enOb = inEncryptionObj;
		this.r1 = new RouterParentMessage(this.message, this.enOb);
		
		if (this.r1.isMultipart()) {
			
			String[] slicedPayLoad = this.slice(this.r1.getMultiPartLength(), r1.getPayload());

			// Send sliced message: alternate 
			
			if (this.alternater) {
				for (int i = 0; i < slicedPayLoad.length; i++) {
					this.r1.setPayload(slicedPayLoad[i]);
					this.r1.setMultipartIndex(i + 1);
					
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					// Logging and Sending
					taDL.sendMSGfromType(this.number, r1.calcJSON(0).toString());
					this.camComp.sendCamToRouter(this.camComp.composeCAM(this.number, r1.calcJSON(0).toString()));
				}
				
			} else {
				for (int i = slicedPayLoad.length - 1; i >= 0; i--) {
					this.r1.setPayload(slicedPayLoad[i]);
					this.r1.setMultipartIndex(i + 1);
					
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					// Logging and Sending
					taDL.sendMSGfromType(this.number, r1.calcJSON(0).toString());
					this.camComp.sendCamToRouter(this.camComp.composeCAM(this.number, r1.calcJSON(0).toString()));
				}
			}
			
			this.alternater = !this.alternater;
			
		} else {
			// Logging and Sending
			taDL.sendMSGfromType(this.number, this.message );
			this.camComp.sendCamToRouter(this.camComp.composeCAM(this.number, this.message));
		}

	}


	// Methods handles the slicing of the String (input) into a predetermined amount of parts (inParts)
	private String[] slice(int inParts, String input) {

		int partLength = input.length() / inParts;
		String[] output = new String[inParts];

		int first = 0;
		int last = partLength;

		for (int i = 0; i < inParts; i++) {

			if (i == inParts - 1) {
				last = input.length();
			}

			output[i] = input.substring(first, last);
			first = first + partLength;
			last = last + partLength;
		}
		return output;
	}
}
