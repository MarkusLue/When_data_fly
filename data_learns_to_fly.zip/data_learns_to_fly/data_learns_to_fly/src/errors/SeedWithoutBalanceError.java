package errors;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

//Error type, describes a situation, when not enough IOTA tokens are on the seed that a transfer is initiated with

@SuppressWarnings("serial")
public class SeedWithoutBalanceError extends Exception { 
    public SeedWithoutBalanceError(String errorMessage) {
        super(errorMessage);
    }
}