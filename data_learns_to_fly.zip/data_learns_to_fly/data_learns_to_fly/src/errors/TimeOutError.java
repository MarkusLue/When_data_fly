package errors;

/**
* Part of the paper:
* "When data fly: a wireless data trading system in vehicular ad-hoc networks",
* last date modified: 11th of January 2021
**/

// Error type, describes a time out error

@SuppressWarnings("serial")
public class TimeOutError extends Exception { 
    public TimeOutError(String errorMessage) {
        super(errorMessage);   
    }
}
