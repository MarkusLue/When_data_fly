# Core Software Components, When data fly: a wireless data trading system in vehicular ad-hoc networks

Core bundle of software, that will enable the V2X communication, data trade and further features.

---

## Table of Contents


- [1. Features](#features)
- [2. Steps before running the application](#stepsbeforerunningtheapplication)
- [3. FAQ](#faq)
- [4. Disclaimer](#disclaimer)


---

## 1. Overview

The code generates two .jar files that can be run on the RSU's and vehcile's hardware.
In the current configuration, this code will automatically detect if the 802.11p enabled routers are plugged in, if they are not reachable, the program shuts down.

Please follow the next steps to make the code runnable.

---

## 2. Steps before running the application

The following steps have to be taken in order to make the code runnable.

### 2a. Recreate /src/multiTransaction/sign/AIC.java

- The <a href="https://github.com/iotaledger/iota-java" target="_blank">`"IOTA Java API Library"`</a> (in version 1.0.0-beta7, Apache-2.0 License) implements the IOTA bundle generation in a way, that a full node is queried, in order to check the balance on the bundle inputs. That means that if a value is to be moved, a connection to a node must be made during the preparation of a bundle and later again for sending the bundle to the network if the Java implementation is used. In order to save time in the short-distance communication phase, the AIC.java file changes this procedure so that the full node query is circumvented. To do so the src/main/java/org/iota/jota/IotaAPI.java file of the IOTA Java API Library has to be altered in a way, so that the node query is circumvented.

### 2b. Recreate /src/multiTransaction/AlteredIotaMultisig.java

- When this Software was created there was a <a href="https://github.com/iotaledger/iota-java/issues/218" target="_blank">`bug`</a> in the <a href="https://github.com/iotaledger/iota-java" target="_blank">`"IOTA Java API Library"`</a> (Version: 1.0.0-beta7, Apache-2.0 License). Back then it was necessary to fix this bug, therefore the class AlteredIotaMultisig.java was created in src/multiTransaction/. If a more recent version of this dependency is used the issue will already be fixed and IOTA Java API Library's Multisig.java can be used.

### 2c. Recreate classes via protocol buffers

- In order to communicate with a router running OpenC2X, a collection of Java classes generate via Google Protocol Buffers is needed. To generate these classes, running the <a href="https://github.com/protocolbuffers/protobuf/releases" target="_blank">`Google Protocol Buffer compiler`</a> (
Copyright 2008 Google Inc., distributed via <a href="https://github.com/protocolbuffers/protobuf/blob/master/LICENSE" target="_blank">`link to license`</a>) and the mandatory .proto files from <a href="https://github.com/florianklingler/OpenC2X-standalone/tree/master/common/buffers" target="_blank">`OpenC2X`</a> (License:  LGPL-3.0 License) are needed. The generated classes and packages must be inserted into the corresponding package: "/src/routerCommunication/protobuf" in order to run the code.

### 2d. Create firmware to enable IEEE 802.11a capable routers to communicate via IEEE 802.11p

- To communicate using IEEE 802.11p, we used a 802.11a enabled routers (TP-LINK TL-WDR3600) and changed its firmware using <a href="https://github.com/florianklingler/OpenC2X-embedded" target="_blank">`OpenC2X`</a> (License:  GPL-2.0 License). Instructions on how to generate this firmware can be found at OpenC2X. We set up the router supporting multiple leightweight lua libraries, in order to run a small lua script on the routers. The scripts goal is to forward the incoming messages that are to be send by the routers from a specified port (ZMQ@5556) to OpenC2X's implementation of ITS-G5's DCC.

### 3e. Build configuration files

- Build the config file (*/dataStorage/initialData_VEHICLE.txt* and *../initialData_RSU.txt*), the following fields have to be set as JSON:

```
{
"boostedPowUrl":"URL where the hardware-accelerator can be found",
"targetUrlNode":"IOTA node IP",
"seedIndex":"Index where blance can be found on the IOTA seed, can be zero",
"seed":"IOTA seed",
"routerUrl":"(local) IP where the 802.11p enable router is reachable",
"routerPort":"port where the 802.11p enable router is reachable",
"powLocal":"Boolean",
"ownRepLink":"depreciated, can be null",
"name":"Set device name",
"minWeightMagnitude":"depending on IOTA network, describes nonce calculation difficulty for PoW",
"messageRSAKey":"private key for RSA communication",
"dateAndTime":"depreciated, can be null",
}
```

---

## 3. FAQ

- **Which external libraries/dependencies are used?**

    The software found here is using the following libraries/dependencies:

    - <a href="https://github.com/iotaledger/iota-java" target="_blank">`"IOTA Java API Library"`</a>, **Version: 1.0.0-beta7**, <a href="https://opensource.org/licenses/Apache-2.0" target="_blank">`Apache-2.0 License`</a>

    - <a href="https://github.com/protocolbuffers/protobuf" target="_blank">`"Protocol Buffers - Google's data interchange format"`</a>, **Version: 3.11.1**, <a href="https://opensource.org/licenses/BSD-3-Clause" target="_blank">`3-Clause BSD License`</a>
    
    - <a href="https://github.com/bcgit/bc-java" target="_blank">`"Bouncy Castle Crypto Package For Java"`</a>, **Version: 1.64**, <a href="https://opensource.org/licenses/MIT" target="_blank">`MIT License`</a>

    - <a href="https://github.com/zeromq/jeromq" target="_blank">`"Pure Java ZeroMQ"`</a>, **Version: 0.5.1**, <a href="https://opensource.org/licenses/MPL-2.0" target="_blank">`MPL-2.0 license`</a>

    - <a href="https://github.com/stleary/JSON-java" target="_blank">`"JSON in Java"`</a>, **Version: 20190722**, <a href="https://github.com/stleary/JSON-java/blob/master/LICENSE" target="_blank">`Copyright (c) 2002 JSON.org`</a>
    
    Additionally, to recreate all parts of the code the following dependecies/projects were used:
    
    - <a href="https://github.com/florianklingler/OpenC2X-embedded" target="_blank">`"OpenC2X Embedded"`</a>, **Version: 1.5**, <a href="https://opensource.org/licenses/LGPL-2.0" target="_blank">`GPL-2.0 License`</a>
    
    - <a href="https://github.com/protocolbuffers/protobuf" target="_blank">`"Google Protocol Buffers"`</a>, **Version: 3.11.2**,  <a href="https://github.com/protocolbuffers/protobuf/blob/master/LICENSE" target="_blank">`link to license`</a>

---

## 4. Disclaimer

Use at your own risk. No guarantee for accurate, up-to-date or complete information.
The author assumes no liability for external links.
